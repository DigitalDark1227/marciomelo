import { useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import FloatingContact from './FloatingContact';
import { useTheme } from '@/lib/useTheme';

export default function Layout() {
  const { pathname } = useLocation();
  useTheme();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <div className="page-shell min-h-screen flex flex-col text-navy-100" style={{ background: 'var(--color-primary)' }}>
      <Header />
      <main className="flex-1 relative">
        <Outlet />
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
