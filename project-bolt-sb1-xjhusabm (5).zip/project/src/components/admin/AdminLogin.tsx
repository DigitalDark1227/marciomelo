import { useState } from 'react';
import { Lock, Loader2, AlertCircle } from 'lucide-react';
import { FunctionsHttpError } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';

export default function AdminLogin() {
  const { lang } = useI18n();
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('admin-login', {
        body: { password },
      });

      if (fnError) {
        const wrongPassword = fnError instanceof FunctionsHttpError && fnError.context.status === 401;
        throw new Error(
          wrongPassword
            ? (lang === 'pt' ? 'Senha incorreta.' : 'Incorrect password.')
            : (lang === 'pt' ? 'Não foi possível entrar. Tente novamente.' : 'Could not sign in. Try again.'),
        );
      }
      if (typeof data?.access_token !== 'string' || typeof data?.refresh_token !== 'string') {
        throw new Error(lang === 'pt' ? 'Resposta inválida do servidor.' : 'Invalid server response.');
      }

      const { error: sessionError } = await supabase.auth.setSession({
        access_token: data.access_token,
        refresh_token: data.refresh_token,
      });
      if (sessionError) throw sessionError;
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setPassword('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#06142b] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <img src="/Logotipo_minimalista_Marcio_Melo_(1).png" alt="Márcio Melo Aircraft Detailing Works" className="mx-auto mb-3 h-36 w-56 object-contain" />
          <h1 className="text-xl font-bold text-white">Márcio Melo</h1>
          <p className="text-xs text-gray-500 uppercase tracking-wider mt-1">Admin Panel</p>
        </div>

        <div className="rounded-2xl bg-white/5 border border-white/10 p-6 sm:p-8">
          <div className="flex items-center gap-2 mb-6">
            <Lock size={20} className="text-[#f4d000]" />
            <h2 className="text-lg font-semibold text-white">
              {lang === 'pt' ? 'Iniciar sessão' : 'Sign in'}
            </h2>
          </div>

          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-sm mb-4">
              <AlertCircle size={18} />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-gray-300 mb-1.5">
                {lang === 'pt' ? 'Senha' : 'Password'}
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                autoFocus
                className="w-full px-4 py-2.5 rounded-lg bg-white/5 border border-white/15 text-white placeholder-gray-500 focus:outline-none focus:border-[#f4d000] text-sm"
                placeholder="••••"
              />
            </div>
            <button
              type="submit"
              disabled={loading || !password}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-[#f4d000] text-[#06142b] font-semibold text-sm transition-opacity hover:opacity-90 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 size={18} className="animate-spin" />
                  {lang === 'pt' ? 'A entrar...' : 'Signing in...'}
                </>
              ) : (
                lang === 'pt' ? 'Entrar' : 'Sign in'
              )}
            </button>
          </form>

          <div className="mt-2 pt-6 border-t border-white/10 text-xs text-gray-500 text-center">
            {lang === 'pt'
              ? 'Acesso restrito ao administrador autorizado.'
              : 'Restricted to authorized administrator.'}
          </div>
        </div>
      </div>
    </div>
  );
}
