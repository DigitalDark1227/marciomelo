import { useEffect, useState } from 'react';
import { Save, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import { updateSetting } from '@/lib/api';
import { useData } from '@/lib/data';

export default function ContactsManager() {
  const { lang } = useI18n();
  const { reload } = useData();
  const [contact, setContact] = useState<Record<string, any>>({});
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    supabase.from('site_settings').select('value').eq('key', 'contact').maybeSingle().then(({ data }) => {
      if (data) setContact(data.value);
    });
  }, []);

  const save = async () => {
    setSaving(true);
    setMsg(null);
    try {
      await updateSetting('contact', contact);
      reload();
      setMsg({ type: 'success', text: lang === 'pt' ? 'Contactos guardados!' : 'Contacts saved!' });
    } catch (err: any) {
      setMsg({ type: 'error', text: err.message });
    }
    setSaving(false);
  };

  const inp = "w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000]";
  const lbl = "block text-xs text-gray-400 mb-1";

  const fields: { key: string; label: string; labelEn: string; type?: 'text' | 'textarea' }[] = [
    { key: 'whatsapp', label: 'WhatsApp', labelEn: 'WhatsApp' },
    { key: 'email', label: 'E-mail', labelEn: 'Email' },
    { key: 'phone', label: 'Telefone', labelEn: 'Phone' },
    { key: 'location_pt', label: 'Localização (PT)', labelEn: 'Location (PT)' },
    { key: 'location_en', label: 'Localização (EN)', labelEn: 'Location (EN)' },
    { key: 'location_es', label: 'Localización (ES)', labelEn: 'Location (ES)' },
    { key: 'location_fr', label: 'Localisation (FR)', labelEn: 'Location (FR)' },
    { key: 'area_pt', label: 'Área de atuação (PT)', labelEn: 'Service area (PT)' },
    { key: 'area_en', label: 'Área de atuação (EN)', labelEn: 'Service area (EN)' },
    { key: 'area_es', label: 'Área de servicio (ES)', labelEn: 'Service area (ES)' },
    { key: 'area_fr', label: 'Zone d\'intervention (FR)', labelEn: 'Service area (FR)' },
    { key: 'hours_pt', label: 'Horário (PT)', labelEn: 'Hours (PT)' },
    { key: 'hours_en', label: 'Horário (EN)', labelEn: 'Hours (EN)' },
    { key: 'hours_es', label: 'Horario (ES)', labelEn: 'Hours (ES)' },
    { key: 'hours_fr', label: 'Horaires (FR)', labelEn: 'Hours (FR)' },
    { key: 'instagram', label: 'Instagram', labelEn: 'Instagram' },
    { key: 'facebook', label: 'Facebook', labelEn: 'Facebook' },
    { key: 'linkedin', label: 'LinkedIn', labelEn: 'LinkedIn' },
    { key: 'whatsapp_msg_pt', label: 'Mensagem inicial WhatsApp (PT)', labelEn: 'WhatsApp initial message (PT)', type: 'textarea' },
    { key: 'whatsapp_msg_en', label: 'Mensagem inicial WhatsApp (EN)', labelEn: 'WhatsApp initial message (EN)', type: 'textarea' },
    { key: 'whatsapp_msg_es', label: 'Mensaje inicial WhatsApp (ES)', labelEn: 'WhatsApp initial message (ES)', type: 'textarea' },
    { key: 'whatsapp_msg_fr', label: 'Message initial WhatsApp (FR)', labelEn: 'WhatsApp initial message (FR)', type: 'textarea' },
  ];

  return (
    <div className="space-y-4">
      {msg && (
        <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${msg.type === 'success' ? 'bg-green-500/10 border border-green-500/30 text-green-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
          {msg.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}<span>{msg.text}</span>
        </div>
      )}

      <div className="rounded-xl bg-white/5 border border-white/10 p-4 sm:p-5 space-y-3">
        {fields.map((f) => (
          <div key={f.key}>
            <label className={lbl}>{lang === 'pt' ? f.label : f.labelEn}</label>
            {f.type === 'textarea' ? (
              <textarea value={contact[f.key] || ''} onChange={(e) => setContact({ ...contact, [f.key]: e.target.value })} className={inp + ' min-h-[60px]'} />
            ) : (
              <input type="text" value={contact[f.key] || ''} onChange={(e) => setContact({ ...contact, [f.key]: e.target.value })} className={inp} />
            )}
          </div>
        ))}
      </div>

      <button onClick={save} disabled={saving} className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#f4d000] text-[#0a1929] text-sm font-semibold disabled:opacity-50">
        {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} {lang === 'pt' ? 'Guardar contactos' : 'Save contacts'}
      </button>
    </div>
  );
}
