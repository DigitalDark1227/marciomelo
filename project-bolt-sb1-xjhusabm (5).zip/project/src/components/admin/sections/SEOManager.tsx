import { useEffect, useState } from 'react';
import { Save, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import { updateSetting } from '@/lib/api';
import { useData } from '@/lib/data';

export default function SEOManager() {
  const { lang } = useI18n();
  const { reload } = useData();
  const [seo, setSeo] = useState<Record<string, any>>({});
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    supabase.from('site_settings').select('value').eq('key', 'seo').maybeSingle().then(({ data }) => {
      if (data) setSeo(data.value);
    });
  }, []);

  const save = async () => {
    setSaving(true);
    setMsg(null);
    try {
      await updateSetting('seo', seo);
      reload();
      setMsg({ type: 'success', text: lang === 'pt' ? 'SEO guardado!' : 'SEO saved!' });
    } catch (err: any) {
      setMsg({ type: 'error', text: err.message });
    }
    setSaving(false);
  };

  const inp = "w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000]";
  const lbl = "block text-xs text-gray-400 mb-1";

  const pages = ['home', 'services'];
  const langs = ['pt', 'en', 'es', 'fr'];

  return (
    <div className="space-y-4">
      {msg && (
        <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${msg.type === 'success' ? 'bg-green-500/10 border border-green-500/30 text-green-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
          {msg.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}<span>{msg.text}</span>
        </div>
      )}

      {pages.map((page) => (
        <div key={page} className="rounded-xl bg-white/5 border border-white/10 p-4 sm:p-5">
          <h3 className="text-sm font-semibold text-white mb-3 capitalize">{page}</h3>
          <div className="space-y-3">
            {langs.map((l) => (
              <div key={l} className="space-y-2">
                <span className="text-xs font-medium text-[#f4d000] uppercase">{l}</span>
                <div><label className={lbl}>Title</label><input type="text" value={seo[`${page}_${l}`]?.title || ''} onChange={(e) => setSeo({ ...seo, [`${page}_${l}`]: { ...seo[`${page}_${l}`], title: e.target.value } })} className={inp} /></div>
                <div><label className={lbl}>Description</label><textarea value={seo[`${page}_${l}`]?.description || ''} onChange={(e) => setSeo({ ...seo, [`${page}_${l}`]: { ...seo[`${page}_${l}`], description: e.target.value } })} className={inp + ' min-h-[60px]'} /></div>
                <div><label className={lbl}>OG Image URL</label><input type="text" value={seo[`${page}_${l}`]?.og_image || ''} onChange={(e) => setSeo({ ...seo, [`${page}_${l}`]: { ...seo[`${page}_${l}`], og_image: e.target.value } })} className={inp} /></div>
              </div>
            ))}
          </div>
        </div>
      ))}

      <button onClick={save} disabled={saving} className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#f4d000] text-[#0a1929] text-sm font-semibold disabled:opacity-50">
        {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} {lang === 'pt' ? 'Guardar SEO' : 'Save SEO'}
      </button>
    </div>
  );
}
