import { useEffect, useState } from 'react';
import { Save, Loader2, CheckCircle, AlertCircle, RotateCcw } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import { updateSetting } from '@/lib/api';

const DEFAULTS = {
  primary_color: '#0a1929',
  accent_color: '#f4d000',
  bg_color: '#0f1f35',
  text_color: '#e8eef5',
  card_style: 'rounded',
  button_style: 'solid',
  card_radius: 12,
};

export default function AppearanceManager() {
  const { lang } = useI18n();
  const { reload } = useData();
  const [appearance, setAppearance] = useState<Record<string, any>>({});
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    supabase.from('site_settings').select('value').eq('key', 'appearance').maybeSingle().then(({ data }) => {
      if (data) setAppearance(data.value);
    });
  }, []);

  // Live preview: apply changes to CSS variables immediately
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--color-primary', appearance.primary_color || DEFAULTS.primary_color);
    root.style.setProperty('--color-accent', appearance.accent_color || DEFAULTS.accent_color);
    root.style.setProperty('--color-bg', appearance.bg_color || DEFAULTS.bg_color);
    root.style.setProperty('--color-text', appearance.text_color || DEFAULTS.text_color);
    root.style.setProperty('--card-radius', `${appearance.card_radius ?? DEFAULTS.card_radius}px`);
  }, [appearance]);

  const save = async () => {
    setSaving(true);
    setMsg(null);
    try {
      await updateSetting('appearance', appearance);
      reload();
      setMsg({ type: 'success', text: lang === 'pt' ? 'Aparência guardada e aplicada!' : 'Appearance saved and applied!' });
    } catch (err: any) {
      setMsg({ type: 'error', text: err.message });
    }
    setSaving(false);
  };

  const reset = () => {
    if (!confirm(lang === 'pt' ? 'Restaurar a identidade visual original?' : 'Restore original visual identity?')) return;
    setAppearance({ ...DEFAULTS });
  };

  const inp = "w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000]";
  const lbl = "block text-xs text-gray-400 mb-1";

  return (
    <div className="space-y-4">
      {msg && (
        <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${msg.type === 'success' ? 'bg-green-500/10 border border-green-500/30 text-green-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
          {msg.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}<span>{msg.text}</span>
        </div>
      )}

      <div className="rounded-xl bg-white/5 border border-white/10 p-4 sm:p-5 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div><label className={lbl}>{lang === 'pt' ? 'Cor principal' : 'Primary color'}</label><div className="flex items-center gap-2"><input type="color" value={appearance.primary_color || '#0a1929'} onChange={(e) => setAppearance({ ...appearance, primary_color: e.target.value })} className="w-12 h-10 rounded-lg cursor-pointer bg-transparent border border-white/15" /><input type="text" value={appearance.primary_color || ''} onChange={(e) => setAppearance({ ...appearance, primary_color: e.target.value })} className={inp} /></div></div>
          <div><label className={lbl}>{lang === 'pt' ? 'Cor de destaque' : 'Accent color'}</label><div className="flex items-center gap-2"><input type="color" value={appearance.accent_color || '#f4d000'} onChange={(e) => setAppearance({ ...appearance, accent_color: e.target.value })} className="w-12 h-10 rounded-lg cursor-pointer bg-transparent border border-white/15" /><input type="text" value={appearance.accent_color || ''} onChange={(e) => setAppearance({ ...appearance, accent_color: e.target.value })} className={inp} /></div></div>
          <div><label className={lbl}>{lang === 'pt' ? 'Cor de fundo' : 'Background color'}</label><div className="flex items-center gap-2"><input type="color" value={appearance.bg_color || '#0f1f35'} onChange={(e) => setAppearance({ ...appearance, bg_color: e.target.value })} className="w-12 h-10 rounded-lg cursor-pointer bg-transparent border border-white/15" /><input type="text" value={appearance.bg_color || ''} onChange={(e) => setAppearance({ ...appearance, bg_color: e.target.value })} className={inp} /></div></div>
          <div><label className={lbl}>{lang === 'pt' ? 'Cor do texto' : 'Text color'}</label><div className="flex items-center gap-2"><input type="color" value={appearance.text_color || '#e8eef5'} onChange={(e) => setAppearance({ ...appearance, text_color: e.target.value })} className="w-12 h-10 rounded-lg cursor-pointer bg-transparent border border-white/15" /><input type="text" value={appearance.text_color || ''} onChange={(e) => setAppearance({ ...appearance, text_color: e.target.value })} className={inp} /></div></div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div><label className={lbl}>{lang === 'pt' ? 'Estilo dos cartões' : 'Card style'}</label><select value={appearance.card_style || 'rounded'} onChange={(e) => setAppearance({ ...appearance, card_style: e.target.value })} className={inp}><option value="rounded" className="bg-[#0f1f35]">Rounded</option><option value="sharp" className="bg-[#0f1f35]">Sharp</option></select></div>
          <div><label className={lbl}>{lang === 'pt' ? 'Estilo dos botões' : 'Button style'}</label><select value={appearance.button_style || 'solid'} onChange={(e) => setAppearance({ ...appearance, button_style: e.target.value })} className={inp}><option value="solid" className="bg-[#0f1f35]">Solid</option><option value="outline" className="bg-[#0f1f35]">Outline</option></select></div>
          <div><label className={lbl}>{lang === 'pt' ? 'Arredondamento (px)' : 'Card radius (px)'}</label><input type="number" value={appearance.card_radius ?? 12} onChange={(e) => setAppearance({ ...appearance, card_radius: parseInt(e.target.value) })} className={inp} /></div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button onClick={save} disabled={saving} className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#f4d000] text-[#0a1929] text-sm font-semibold disabled:opacity-50">
          {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} {lang === 'pt' ? 'Guardar' : 'Save'}
        </button>
        <button onClick={reset} className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-white/20 text-gray-300 text-sm hover:bg-white/5">
          <RotateCcw size={16} /> {lang === 'pt' ? 'Restaurar original' : 'Restore original'}
        </button>
      </div>
    </div>
  );
}
