import { useEffect, useState } from 'react';
import { Save, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import { updateSetting } from '@/lib/api';
import { useData } from '@/lib/data';

export default function SettingsManager() {
  const { lang } = useI18n();
  const { reload } = useData();
  const [brand, setBrand] = useState<Record<string, any>>({});
  const [formConfig, setFormConfig] = useState<Record<string, any>>({});
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    Promise.all([
      supabase.from('site_settings').select('value').eq('key', 'brand').maybeSingle(),
      supabase.from('site_settings').select('value').eq('key', 'form_config').maybeSingle(),
    ]).then(([brandRes, formRes]) => {
      if (brandRes.data) setBrand(brandRes.data.value);
      if (formRes.data) setFormConfig(formRes.data.value);
    });
  }, []);

  const save = async () => {
    setSaving(true);
    setMsg(null);
    try {
      await updateSetting('brand', brand);
      await updateSetting('form_config', formConfig);
      reload();
      setMsg({ type: 'success', text: lang === 'pt' ? 'Definições guardadas!' : 'Settings saved!' });
    } catch (err: any) {
      setMsg({ type: 'error', text: err.message });
    }
    setSaving(false);
  };

  const inp = "w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#c9a227]";
  const lbl = "block text-xs text-gray-400 mb-1";

  return (
    <div className="space-y-4">
      {msg && (
        <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${msg.type === 'success' ? 'bg-green-500/10 border border-green-500/30 text-green-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
          {msg.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}<span>{msg.text}</span>
        </div>
      )}

      <div className="rounded-xl bg-white/5 border border-white/10 p-4 sm:p-5 space-y-3">
        <h3 className="text-sm font-semibold text-white">{lang === 'pt' ? 'Identidade da marca' : 'Brand identity'}</h3>
        <div><label className={lbl}>{lang === 'pt' ? 'Nome comercial' : 'Business name'}</label><input type="text" value={brand.name || ''} onChange={(e) => setBrand({ ...brand, name: e.target.value })} className={inp} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className={lbl}>Tagline (PT)</label><input type="text" value={brand.tagline_pt || ''} onChange={(e) => setBrand({ ...brand, tagline_pt: e.target.value })} className={inp} /></div>
          <div><label className={lbl}>Tagline (EN)</label><input type="text" value={brand.tagline_en || ''} onChange={(e) => setBrand({ ...brand, tagline_en: e.target.value })} className={inp} /></div>
        </div>
        <div><label className={lbl}>{lang === 'pt' ? 'Descrição (PT)' : 'Description (PT)'}</label><textarea value={brand.description_pt || ''} onChange={(e) => setBrand({ ...brand, description_pt: e.target.value })} className={inp + ' min-h-[60px]'} /></div>
        <div><label className={lbl}>Description (EN)</label><textarea value={brand.description_en || ''} onChange={(e) => setBrand({ ...brand, description_en: e.target.value })} className={inp + ' min-h-[60px]'} /></div>
        <div><label className={lbl}>Logo URL</label><input type="text" value={brand.logo_url || ''} onChange={(e) => setBrand({ ...brand, logo_url: e.target.value })} className={inp} /></div>
        <div><label className={lbl}>Favicon URL</label><input type="text" value={brand.favicon_url || ''} onChange={(e) => setBrand({ ...brand, favicon_url: e.target.value })} className={inp} /></div>
      </div>

      <div className="rounded-xl bg-white/5 border border-white/10 p-4 sm:p-5 space-y-3">
        <h3 className="text-sm font-semibold text-white">{lang === 'pt' ? 'Configuração do formulário' : 'Form configuration'}</h3>
        <div><label className={lbl}>{lang === 'pt' ? 'Campos obrigatórios (vírgula)' : 'Required fields (comma)'}</label><input type="text" value={(formConfig.required_fields || []).join(', ')} onChange={(e) => setFormConfig({ ...formConfig, required_fields: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) })} className={inp} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className={lbl}>{lang === 'pt' ? 'Categorias (PT)' : 'Categories (PT)'}</label><textarea value={(formConfig.categories_pt || []).join('\n')} onChange={(e) => setFormConfig({ ...formConfig, categories_pt: e.target.value.split('\n').filter(Boolean) })} className={inp + ' min-h-[60px]'} /></div>
          <div><label className={lbl}>Categories (EN)</label><textarea value={(formConfig.categories_en || []).join('\n')} onChange={(e) => setFormConfig({ ...formConfig, categories_en: e.target.value.split('\n').filter(Boolean) })} className={inp + ' min-h-[60px]'} /></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className={lbl}>{lang === 'pt' ? 'Mensagem de sucesso (PT)' : 'Success message (PT)'}</label><input type="text" value={formConfig.success_msg_pt || ''} onChange={(e) => setFormConfig({ ...formConfig, success_msg_pt: e.target.value })} className={inp} /></div>
          <div><label className={lbl}>Success message (EN)</label><input type="text" value={formConfig.success_msg_en || ''} onChange={(e) => setFormConfig({ ...formConfig, success_msg_en: e.target.value })} className={inp} /></div>
        </div>
        <div><label className={lbl}>{lang === 'pt' ? 'E-mail de notificação' : 'Notification email'}</label><input type="email" value={formConfig.notification_email || ''} onChange={(e) => setFormConfig({ ...formConfig, notification_email: e.target.value })} className={inp} /></div>
        <label className="flex items-center gap-2 text-xs text-gray-400"><input type="checkbox" checked={formConfig.allow_attachments ?? true} onChange={(e) => setFormConfig({ ...formConfig, allow_attachments: e.target.checked })} className="accent-[#c9a227]" />{lang === 'pt' ? 'Permitir anexos' : 'Allow attachments'}</label>
      </div>

      <button onClick={save} disabled={saving} className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#c9a227] text-[#0a1929] text-sm font-semibold disabled:opacity-50">
        {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} {lang === 'pt' ? 'Guardar definições' : 'Save settings'}
      </button>
    </div>
  );
}
