import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import {
  fetchClients, upsertClient,
  fetchAircraftModels,
  fetchQuoteServices, fetchQuotePackages,
  fetchAllQuoteNumbers, createQuote, updateQuote,
} from '@/lib/quoteApi';
import { calculateLineItem, calculateQuoteTotal, formatEUR, generateQuoteNumber, IVA_RATE, IVA_LABEL } from '@/lib/quotePricing';
import type {
  Client, AircraftModel, QuoteServiceItem, QuotePackage,
  LineItem, ExtraFee, QuoteCalcStatus,
} from '@/lib/quoteTypes';

type Step = 1 | 2 | 3 | 4 | 5;
type Category = 'aero';

interface Props {
  editingQuote?: any | null;
  onSaved: () => void;
  onCancel: () => void;
}

const PRICING_RULE_LABELS: Record<string, string> = {
  fixed: 'Preço fixo',
  hourly: 'Por hora',
  estimated_hours: 'Horas estimadas',
  dimension: 'Por dimensão',
  custom: 'Personalizado',
};

const STATUS_LABELS: Record<QuoteCalcStatus, { pt: string; color: string }> = {
  rascunho: { pt: 'Rascunho', color: '#6b7280' },
  enviado: { pt: 'Enviado ao cliente', color: '#3b82f6' },
  aguardar: { pt: 'A aguardar resposta', color: '#f59e0b' },
  aceite: { pt: 'Aceite', color: '#22c55e' },
  recusado: { pt: 'Recusado', color: '#ef4444' },
  expirado: { pt: 'Expirado', color: '#9ca3af' },
  convertido: { pt: 'Convertido em serviço', color: '#8b5cf6' },
};

export default function QuoteCalculator({ editingQuote, onSaved, onCancel }: Props) {
  const [step, setStep] = useState<Step>(editingQuote ? 5 : 1);
  const [clients, setClients] = useState<Client[]>([]);
  const [aircraftModels, setAircraftModels] = useState<AircraftModel[]>([]);
  const [services, setServices] = useState<QuoteServiceItem[]>([]);
  const [packages, setPackages] = useState<QuotePackage[]>([]);
  const [loading, setLoading] = useState(true);

  // Step 1 state
  const [clientSearch, setClientSearch] = useState('');
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [showNewClient, setShowNewClient] = useState(false);
  const [newClient, setNewClient] = useState<Partial<Client>>({});

  // Step 2 state
  const category: Category = 'aero';

  // Step 3 state
  const [modelSearch, setModelSearch] = useState('');
  const [selectedModelId, setSelectedModelId] = useState<string>('');
  const [showNewModel, setShowNewModel] = useState(false);
  const [customModel, setCustomModel] = useState<any>({});
  const [estimatedHours, setEstimatedHours] = useState(0);

  // Step 4 state
  const [selectedServiceIds, setSelectedServiceIds] = useState<Set<string>>(new Set());
  const [selectedPackageId, setSelectedPackageId] = useState<string>('');
  const [lineItems, setLineItems] = useState<LineItem[]>([]);
  const [customServices, setCustomServices] = useState<LineItem[]>([]);
  const [discount, setDiscount] = useState(0);
  const [discountPercent, setDiscountPercent] = useState(0);
  const [extraFees, setExtraFees] = useState<ExtraFee[]>([]);
  const [taxEnabled, setTaxEnabled] = useState(false);
  const taxRate = taxEnabled ? IVA_RATE : 0;
  const taxLabel = taxEnabled ? IVA_LABEL : '';

  // Step 5 state
  const [estimatedDuration, setEstimatedDuration] = useState('');
  const [clientNotes, setClientNotes] = useState('');
  const [internalNotes, setInternalNotes] = useState('');
  const [validUntil, setValidUntil] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [c, a, s, p] = await Promise.all([
          fetchClients(),
          fetchAircraftModels(),
          fetchQuoteServices(),
          fetchQuotePackages(),
        ]);
        setClients(c);
        setAircraftModels(a);
        setServices(s);
        setPackages(p);
      } catch (err) {
        console.error('Failed to load calculator data:', err);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // Load editing quote
  useEffect(() => {
    if (!editingQuote) return;
    setSelectedClient(clients.find((c) => c.id === editingQuote.client_id) || null);
    setSelectedModelId(editingQuote.model_id || '');
    setEstimatedHours(0);
    if (editingQuote.line_items) {
      setLineItems(editingQuote.line_items);
      const ids = new Set(editingQuote.line_items.filter((i: LineItem) => !i.is_custom).map((i: LineItem) => i.service_id));
      setSelectedServiceIds(ids);
    }
    setDiscount(editingQuote.discount || 0);
    setDiscountPercent(editingQuote.discount_percent || 0);
    setExtraFees(editingQuote.extra_fees || []);
    setTaxEnabled((editingQuote.tax_rate || 0) > 0);
    setEstimatedDuration(editingQuote.estimated_duration || '');
    setClientNotes(editingQuote.client_notes || '');
    setInternalNotes(editingQuote.internal_notes || '');
    setValidUntil(editingQuote.valid_until || '');
  }, [editingQuote, clients]);

  // Recalculate line items when services or estimated hours change
  const recalcLineItems = useCallback(() => {
    const items: LineItem[] = [];
    for (const svc of services) {
      if (!selectedServiceIds.has(svc.id)) continue;
      if (svc.category !== category) continue;
      const { unitPrice, subtotal, pending } = calculateLineItem(
        svc.pricing_rule, svc.price, svc.hourly_rate, svc.estimated_hours ?? estimatedHours, estimatedHours, 1
      );
      items.push({
        service_id: svc.id,
        name: svc.name,
        description: svc.description,
        quantity: 1,
        hours: svc.pricing_rule === 'estimated_hours' ? estimatedHours : svc.pricing_rule === 'hourly' ? 1 : 0,
        unit_price: unitPrice,
        subtotal,
        pricing_rule: svc.pricing_rule,
        is_custom: false,
      });
    }
    setLineItems(items);
  }, [services, selectedServiceIds, category, estimatedHours]);

  useEffect(() => {
    if (step >= 4 && !editingQuote) recalcLineItems();
  }, [recalcLineItems, step, editingQuote]);

  // Apply package
  const applyPackage = useCallback((pkgId: string) => {
    setSelectedPackageId(pkgId);
    if (!pkgId) return;
    const pkg = packages.find((p) => p.id === pkgId);
    if (!pkg) return;
    const newIds = new Set(selectedServiceIds);
    (pkg.service_ids || []).forEach((id) => newIds.add(id));
    setSelectedServiceIds(newIds);
  }, [packages, selectedServiceIds]);

  const allItems = useMemo(() => [...lineItems, ...customServices], [lineItems, customServices]);
  const totals = useMemo(
    () => calculateQuoteTotal(allItems, discount, discountPercent, extraFees, taxRate),
    [allItems, discount, discountPercent, extraFees, taxRate]
  );

  const filteredClients = useMemo(() => {
    if (!clientSearch) return clients;
    const s = clientSearch.toLowerCase();
    return clients.filter((c) =>
      c.name.toLowerCase().includes(s) ||
      c.company.toLowerCase().includes(s) ||
      c.email.toLowerCase().includes(s) ||
      c.phone.includes(s)
    );
  }, [clients, clientSearch]);

  const filteredModels = useMemo(() => {
    const models = aircraftModels;
    if (!modelSearch) return models;
    const s = modelSearch.toLowerCase();
    return models.filter((m) =>
      m.manufacturer.toLowerCase().includes(s) ||
      m.model.toLowerCase().includes(s) ||
      m.category.toLowerCase().includes(s)
    );
  }, [aircraftModels, modelSearch]);

  const selectedModel = useMemo(() => {
    return aircraftModels.find((m) => m.id === selectedModelId);
  }, [aircraftModels, selectedModelId]);

  const categoryServices = useMemo(() => services.filter((s) => s.category === category && s.is_active), [services, category]);
  const categoryPackages = useMemo(() => packages.filter((p) => p.category === category && p.is_active), [packages, category]);

  const handleSaveNewClient = async () => {
    try {
      const created = await upsertClient(newClient);
      setClients((prev) => [...prev, created].sort((a, b) => a.name.localeCompare(b.name)));
      setSelectedClient(created);
      setShowNewClient(false);
      setNewClient({});
    } catch (err) {
      console.error('Failed to create client:', err);
      alert('Erro ao criar cliente. Verifique os dados.');
    }
  };

  const handleAddCustomModel = () => {
    const label = `${customModel.manufacturer || ''} ${customModel.model || ''}`.trim();
    if (!label) return;
    setSelectedModelId('custom');
    setEstimatedHours(parseFloat(customModel.estimated_hours) || 0);
  };

  const toggleService = (id: string) => {
    const newIds = new Set(selectedServiceIds);
    if (newIds.has(id)) newIds.delete(id);
    else newIds.add(id);
    setSelectedServiceIds(newIds);
    setSelectedPackageId('');
  };

  const updateLineItem = (index: number, updates: Partial<LineItem>) => {
    setLineItems((prev) => prev.map((item, i) => {
      if (i !== index) return item;
      const updated = { ...item, ...updates };
      if (updates.unit_price !== undefined || updates.quantity !== undefined || updates.hours !== undefined) {
        updated.subtotal = updated.unit_price * (updated.hours > 0 ? updated.hours : 1) * updated.quantity;
        if (updated.pricing_rule === 'fixed' || updated.pricing_rule === 'dimension' || updated.pricing_rule === 'custom') {
          updated.subtotal = updated.unit_price * updated.quantity;
        }
      }
      return updated;
    }));
  };

  const addCustomService = () => {
    setCustomServices((prev) => [...prev, {
      service_id: `custom-${Date.now()}`,
      name: '',
      description: '',
      quantity: 1,
      hours: 0,
      unit_price: 0,
      subtotal: 0,
      pricing_rule: 'custom',
      is_custom: true,
    }]);
  };

  const updateCustomService = (index: number, updates: Partial<LineItem>) => {
    setCustomServices((prev) => prev.map((item, i) => {
      if (i !== index) return item;
      const updated = { ...item, ...updates };
      updated.subtotal = updated.unit_price * updated.quantity;
      return updated;
    }));
  };

  const removeCustomService = (index: number) => {
    setCustomServices((prev) => prev.filter((_, i) => i !== index));
  };

  const addExtraFee = () => setExtraFees((prev) => [...prev, { label: '', amount: 0 }]);
  const updateExtraFee = (index: number, updates: Partial<ExtraFee>) =>
    setExtraFees((prev) => prev.map((f, i) => (i === index ? { ...f, ...updates } : f)));
  const removeExtraFee = (index: number) => setExtraFees((prev) => prev.filter((_, i) => i !== index));

  const modelLabel = useMemo(() => {
    if (selectedModelId === 'custom') {
      return `${customModel.manufacturer || ''} ${customModel.model || ''}`.trim() || 'Modelo personalizado';
    }
    if (selectedModel) return `${selectedModel.manufacturer} ${selectedModel.model}`;
    return '';
  }, [selectedModel, selectedModelId, customModel]);

  const modelImage = useMemo(() => {
    if (selectedModelId === 'custom') return customModel.image_url || '';
    return selectedModel?.image_url || '';
  }, [selectedModel, selectedModelId, customModel]);

  const handleSave = async (status: QuoteCalcStatus) => {
    if (!selectedClient) { alert('Selecione um cliente.'); return; }
    if (!modelLabel) { alert('Selecione um modelo.'); return; }
    setSaving(true);
    try {
      const allNumbers = await fetchAllQuoteNumbers();
      const quoteNumber = editingQuote?.quote_number || generateQuoteNumber(allNumbers);
      const reg = selectedModelId === 'custom'
        ? (customModel.registration || '')
        : (selectedModel as any)?.registration || '';

      const payload: Partial<any> = {
        quote_number: quoteNumber,
        client_id: selectedClient.id,
        category,
        model_id: selectedModelId === 'custom' ? null : selectedModelId,
        model_label: modelLabel,
        registration: reg,
        model_image_url: modelImage,
        status,
        line_items: allItems,
        discount,
        discount_percent: discountPercent,
        tax_rate: taxRate,
        tax_label: taxLabel,
        extra_fees: extraFees,
        total: totals.total,
        estimated_duration: estimatedDuration,
        client_notes: clientNotes,
        internal_notes: internalNotes,
        valid_until: validUntil || null,
      };

      if (editingQuote?.id) {
        await updateQuote(editingQuote.id, payload);
        await supabase.from('quote_history').insert({
          quote_id: editingQuote.id,
          action: 'edited',
          notes: `Orçamento editado — total: ${formatEUR(totals.total)}`,
        });
      } else {
        await createQuote(payload);
      }
      onSaved();
    } catch (err) {
      console.error('Failed to save quote:', err);
      alert('Erro ao guardar orçamento. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-[#f4d000]/20 border-t-[#f4d000] rounded-full animate-spin" />
      </div>
    );
  }

  const stepLabels = ['Cliente', 'Categoria', 'Modelo', 'Serviços', 'Resumo'];

  return (
    <div className="max-w-5xl mx-auto">
      {/* Stepper */}
      <div className="flex items-center justify-between mb-8 px-2">
        {stepLabels.map((label, i) => {
          const n = (i + 1) as Step;
          const done = n < step;
          const active = n === step;
          return (
            <div key={i} className="flex items-center flex-1 last:flex-none">
              <div className="flex items-center gap-2">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                    active ? 'bg-[#f4d000] text-[#06142b]' : done ? 'bg-[#f4d000]/30 text-[#f4d000]' : 'bg-white/5 text-gray-500'
                  }`}
                >
                  {done ? '✓' : n}
                </div>
                <span className={`text-xs hidden sm:block ${active || done ? 'text-white' : 'text-gray-500'}`}>{label}</span>
              </div>
              {i < stepLabels.length - 1 && (
                <div className={`flex-1 h-px mx-2 ${done ? 'bg-[#f4d000]/40' : 'bg-white/10'}`} />
              )}
            </div>
          );
        })}
      </div>

      {/* Step 1: Client */}
      {step === 1 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white mb-2">Selecionar cliente</h3>

          {selectedClient ? (
            <div className="bg-[#0a1929] border border-white/10 rounded-xl p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-white font-semibold">{selectedClient.name}</p>
                  {selectedClient.company && <p className="text-gray-400 text-sm">{selectedClient.company}</p>}
                  <p className="text-gray-400 text-sm">{selectedClient.email}</p>
                  <p className="text-gray-400 text-sm">{selectedClient.phone}</p>
                </div>
                <button onClick={() => { setSelectedClient(null); setClientSearch(''); }} className="text-xs text-gray-400 hover:text-white">
                  Alterar
                </button>
              </div>
            </div>
          ) : (
            <>
              <input
                type="text"
                value={clientSearch}
                onChange={(e) => setClientSearch(e.target.value)}
                placeholder="Pesquisar por nome, empresa, telefone ou e-mail..."
                className="w-full bg-[#0a1929] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:border-[#f4d000]/50 outline-none"
              />

              <div className="max-h-64 overflow-y-auto space-y-2">
                {filteredClients.length === 0 && (
                  <p className="text-gray-500 text-sm text-center py-4">Nenhum cliente encontrado.</p>
                )}
                {filteredClients.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setSelectedClient(c)}
                    className="w-full text-left bg-[#0a1929] border border-white/10 rounded-xl px-4 py-3 hover:border-[#f4d000]/30 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-white text-sm font-medium">{c.name}</span>
                        {c.company && <span className="text-gray-400 text-sm ml-2">{c.company}</span>}
                      </div>
                      <span className="text-gray-500 text-xs">{c.email}</span>
                    </div>
                  </button>
                ))}
              </div>

              {!showNewClient ? (
                <button
                  onClick={() => setShowNewClient(true)}
                  className="text-sm text-[#f4d000] hover:underline"
                >
                  + Criar novo cliente
                </button>
              ) : (
                <div className="bg-[#0a1929] border border-white/10 rounded-xl p-5 space-y-3">
                  <h4 className="text-white text-sm font-semibold">Novo cliente</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input value={newClient.name || ''} onChange={(e) => setNewClient({ ...newClient, name: e.target.value })} placeholder="Nome *" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
                    <input value={newClient.company || ''} onChange={(e) => setNewClient({ ...newClient, company: e.target.value })} placeholder="Empresa" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
                    <input value={newClient.email || ''} onChange={(e) => setNewClient({ ...newClient, email: e.target.value })} placeholder="E-mail" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
                    <input value={newClient.phone || ''} onChange={(e) => setNewClient({ ...newClient, phone: e.target.value })} placeholder="Telefone" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
                    <input value={newClient.nif || ''} onChange={(e) => setNewClient({ ...newClient, nif: e.target.value })} placeholder="NIF" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
                    <input value={newClient.address || ''} onChange={(e) => setNewClient({ ...newClient, address: e.target.value })} placeholder="Morada" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
                  </div>
                  <div className="flex gap-2">
                    <button onClick={handleSaveNewClient} className="px-4 py-2 bg-[#f4d000] text-[#06142b] rounded-lg text-sm font-semibold hover:opacity-90">
                      Guardar cliente
                    </button>
                    <button onClick={() => setShowNewClient(false)} className="px-4 py-2 text-gray-400 hover:text-white text-sm">
                      Cancelar
                    </button>
                  </div>
                </div>
              )}
            </>
          )}

          <div className="flex justify-end pt-4">
            <button
              onClick={() => setStep(2)}
              disabled={!selectedClient}
              className="px-6 py-2.5 bg-[#f4d000] text-[#06142b] rounded-lg text-sm font-semibold disabled:opacity-30 hover:opacity-90"
            >
              Avançar
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Aircraft category */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="bg-[#0a1929] border border-[#1677ff]/30 rounded-xl p-6 text-center">
            <div className="text-3xl mb-2">✈</div>
            <h3 className="text-lg font-semibold text-white">Aircraft Detailing</h3>
            <p className="text-sm text-gray-400 mt-1">Todos os orçamentos são para aeronaves.</p>
          </div>
          <div className="flex justify-between pt-4">
            <button onClick={() => setStep(1)} className="px-4 py-2 text-gray-400 hover:text-white text-sm">Voltar</button>
            <button onClick={() => setStep(3)} className="px-6 py-2.5 bg-[#f4d000] text-[#06142b] rounded-lg text-sm font-semibold hover:opacity-90">Avançar</button>
          </div>
        </div>
      )}

      {/* Step 3: Model */}
      {step === 3 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white mb-2">Selecionar aeronave</h3>

          <input
            type="text"
            value={modelSearch}
            onChange={(e) => setModelSearch(e.target.value)}
            placeholder="Pesquisar por fabricante, modelo ou categoria..."
            className="w-full bg-[#0a1929] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:border-[#f4d000]/50 outline-none"
          />

          <div className="max-h-64 overflow-y-auto space-y-2">
            {filteredModels.length === 0 && !showNewModel && (
              <p className="text-gray-500 text-sm text-center py-4">Nenhum modelo encontrado.</p>
            )}
            {filteredModels.map((m) => (
              <button
                key={m.id}
                onClick={() => { setSelectedModelId(m.id); setEstimatedHours(m.estimated_hours); setShowNewModel(false); }}
                className={`w-full text-left rounded-xl px-4 py-3 border transition-all ${
                  selectedModelId === m.id ? 'border-[#f4d000] bg-[#f4d000]/10' : 'border-white/10 bg-[#0a1929] hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-white text-sm font-medium">{m.manufacturer} {m.model}</span>
                    {m.category && <span className="text-gray-400 text-sm ml-2">{m.category}</span>}
                  </div>
                  <span className="text-gray-500 text-xs">{m.estimated_hours}h estimadas</span>
                </div>
                {category === 'aero' && (m as AircraftModel).registration && (
                  <span className="text-gray-500 text-xs">Matrícula: {(m as AircraftModel).registration}</span>
                )}
              </button>
            ))}
          </div>

          {/* Selected model details */}
          {selectedModel && selectedModelId !== 'custom' && (
            <div className="bg-[#0a1929] border border-white/10 rounded-xl p-4 flex gap-4">
              {selectedModel.image_url && <img src={selectedModel.image_url} alt={modelLabel} className="w-24 h-24 rounded-lg object-cover" />}
              <div className="flex-1">
                <p className="text-white font-semibold text-sm">{modelLabel}</p>
                <p className="text-gray-400 text-xs">{selectedModel.category}</p>
                <div className="mt-2">
                  <label className="text-xs text-gray-500">Horas estimadas</label>
                  <input
                    type="number"
                    value={estimatedHours}
                    onChange={(e) => setEstimatedHours(parseFloat(e.target.value) || 0)}
                    className="w-24 bg-[#06142b] border border-white/10 rounded-lg px-2 py-1 text-sm text-white"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Custom model */}
          {!showNewModel ? (
            <button onClick={() => { setShowNewModel(true); setSelectedModelId(''); }} className="text-sm text-[#f4d000] hover:underline">
              + Adicionar modelo personalizado
            </button>
          ) : (
            <div className="bg-[#0a1929] border border-white/10 rounded-xl p-5 space-y-3">
              <h4 className="text-white text-sm font-semibold">Modelo personalizado</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input value={customModel.manufacturer || ''} onChange={(e) => setCustomModel({ ...customModel, manufacturer: e.target.value })} placeholder="Fabricante *" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
                <input value={customModel.model || ''} onChange={(e) => setCustomModel({ ...customModel, model: e.target.value })} placeholder="Modelo *" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
                {category === 'aero' && (
                  <input value={customModel.registration || ''} onChange={(e) => setCustomModel({ ...customModel, registration: e.target.value })} placeholder="Matrícula" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
                )}
                <input value={customModel.category || ''} onChange={(e) => setCustomModel({ ...customModel, category: e.target.value })} placeholder="Categoria" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
                <input type="number" value={customModel.estimated_hours || ''} onChange={(e) => setCustomModel({ ...customModel, estimated_hours: e.target.value })} placeholder="Horas estimadas" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
                <input value={customModel.image_url || ''} onChange={(e) => setCustomModel({ ...customModel, image_url: e.target.value })} placeholder="URL da imagem" className="col-span-2 bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500" />
              </div>
              <div className="flex gap-2">
                <button onClick={handleAddCustomModel} className="px-4 py-2 bg-[#f4d000] text-[#06142b] rounded-lg text-sm font-semibold hover:opacity-90">Selecionar</button>
                <button onClick={() => setShowNewModel(false)} className="px-4 py-2 text-gray-400 hover:text-white text-sm">Cancelar</button>
              </div>
            </div>
          )}

          <div className="flex justify-between pt-4">
            <button onClick={() => setStep(2)} className="px-4 py-2 text-gray-400 hover:text-white text-sm">Voltar</button>
            <button onClick={() => setStep(4)} disabled={!selectedModelId && !showNewModel} className="px-6 py-2.5 bg-[#f4d000] text-[#06142b] rounded-lg text-sm font-semibold disabled:opacity-30 hover:opacity-90">Avançar</button>
          </div>
        </div>
      )}

      {/* Step 4: Services */}
      {step === 4 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white mb-2">Selecionar serviços</h3>

          {/* Packages */}
          {categoryPackages.length > 0 && (
            <div className="bg-[#0a1929] border border-white/10 rounded-xl p-4">
              <h4 className="text-xs font-semibold text-[#f4d000] uppercase tracking-wider mb-3">Pacotes</h4>
              <div className="flex flex-wrap gap-2">
                {categoryPackages.map((pkg) => (
                  <button
                    key={pkg.id}
                    onClick={() => applyPackage(pkg.id)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      selectedPackageId === pkg.id ? 'bg-[#f4d000] text-[#06142b]' : 'bg-white/5 text-gray-300 hover:bg-white/10'
                    }`}
                  >
                    {pkg.name}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Individual services */}
          <div className="bg-[#0a1929] border border-white/10 rounded-xl p-4">
            <h4 className="text-xs font-semibold text-[#f4d000] uppercase tracking-wider mb-3">Serviços individuais</h4>
            <div className="space-y-2">
              {categoryServices.map((svc) => {
                const checked = selectedServiceIds.has(svc.id);
                return (
                  <label key={svc.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggleService(svc.id)}
                      className="w-4 h-4 accent-[#f4d000]"
                    />
                    <div className="flex-1">
                      <span className="text-white text-sm">{svc.name}</span>
                      <span className="text-gray-500 text-xs ml-2">{PRICING_RULE_LABELS[svc.pricing_rule]}</span>
                    </div>
                    {svc.price > 0 && <span className="text-gray-400 text-xs">{formatEUR(svc.price)}</span>}
                    {svc.hourly_rate > 0 && <span className="text-gray-400 text-xs">{formatEUR(svc.hourly_rate)}/h</span>}
                    {svc.price === 0 && svc.hourly_rate === 0 && <span className="text-amber-500 text-xs">Pendente</span>}
                  </label>
                );
              })}
            </div>
          </div>

          {/* Line items table */}
          {allItems.length > 0 && (
            <div className="bg-[#0a1929] border border-white/10 rounded-xl p-4">
              <h4 className="text-xs font-semibold text-[#f4d000] uppercase tracking-wider mb-3">Itens do orçamento</h4>
              {/* Desktop table */}
              <div className="hidden sm:block overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-gray-500 text-xs border-b border-white/10">
                      <th className="pb-2 pr-2">Serviço</th>
                      <th className="pb-2 px-2 text-center">Qtd</th>
                      <th className="pb-2 px-2 text-center">Horas</th>
                      <th className="pb-2 px-2 text-right">Preço unit.</th>
                      <th className="pb-2 px-2 text-right">Subtotal</th>
                      {customServices.length > 0 && <th className="pb-2"></th>}
                    </tr>
                  </thead>
                  <tbody>
                    {lineItems.map((item, i) => (
                      <tr key={`li-${i}`} className="border-b border-white/5">
                        <td className="py-2 pr-2 text-white">{item.name}</td>
                        <td className="py-2 px-2">
                          <input type="number" min="1" value={item.quantity} onChange={(e) => updateLineItem(i, { quantity: parseInt(e.target.value) || 1 })} className="w-14 bg-[#06142b] border border-white/10 rounded px-2 py-1 text-white text-xs text-center" />
                        </td>
                        <td className="py-2 px-2 text-center text-gray-400">{item.hours > 0 ? item.hours : '-'}</td>
                        <td className="py-2 px-2 text-right">
                          <input type="number" step="0.01" value={item.unit_price} onChange={(e) => updateLineItem(i, { unit_price: parseFloat(e.target.value) || 0 })} className="w-24 bg-[#06142b] border border-white/10 rounded px-2 py-1 text-white text-xs text-right" />
                        </td>
                        <td className="py-2 px-2 text-right text-white">{formatEUR(item.subtotal)}</td>
                      </tr>
                    ))}
                    {customServices.map((item, i) => (
                      <tr key={`cs-${i}`} className="border-b border-white/5">
                        <td className="py-2 pr-2">
                          <input value={item.name} onChange={(e) => updateCustomService(i, { name: e.target.value })} placeholder="Nome do serviço" className="w-full bg-[#06142b] border border-white/10 rounded px-2 py-1 text-white text-xs" />
                        </td>
                        <td className="py-2 px-2">
                          <input type="number" min="1" value={item.quantity} onChange={(e) => updateCustomService(i, { quantity: parseInt(e.target.value) || 1 })} className="w-14 bg-[#06142b] border border-white/10 rounded px-2 py-1 text-white text-xs text-center" />
                        </td>
                        <td className="py-2 px-2 text-center text-gray-400">-</td>
                        <td className="py-2 px-2 text-right">
                          <input type="number" step="0.01" value={item.unit_price} onChange={(e) => updateCustomService(i, { unit_price: parseFloat(e.target.value) || 0 })} className="w-24 bg-[#06142b] border border-white/10 rounded px-2 py-1 text-white text-xs text-right" />
                        </td>
                        <td className="py-2 px-2 text-right text-white">{formatEUR(item.subtotal)}</td>
                        <td className="py-2 px-2">
                          <button onClick={() => removeCustomService(i)} className="text-red-400 hover:text-red-300 text-xs">Remover</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {/* Mobile cards */}
              <div className="sm:hidden space-y-3">
                {lineItems.map((item, i) => (
                  <div key={`li-m-${i}`} className="bg-[#06142b] border border-white/10 rounded-lg p-3 space-y-2">
                    <p className="text-white text-sm font-medium">{item.name}</p>
                    <div className="flex items-center gap-2">
                      <div className="flex-1">
                        <label className="text-[10px] text-gray-500">Qtd</label>
                        <input type="number" min="1" value={item.quantity} onChange={(e) => updateLineItem(i, { quantity: parseInt(e.target.value) || 1 })} className="w-full bg-[#0a1929] border border-white/10 rounded px-2 py-1 text-white text-xs" />
                      </div>
                      <div className="flex-1">
                        <label className="text-[10px] text-gray-500">Preço unit.</label>
                        <input type="number" step="0.01" value={item.unit_price} onChange={(e) => updateLineItem(i, { unit_price: parseFloat(e.target.value) || 0 })} className="w-full bg-[#0a1929] border border-white/10 rounded px-2 py-1 text-white text-xs" />
                      </div>
                      <div className="text-right">
                        <label className="text-[10px] text-gray-500">Subtotal</label>
                        <p className="text-white text-sm font-semibold">{formatEUR(item.subtotal)}</p>
                      </div>
                    </div>
                  </div>
                ))}
                {customServices.map((item, i) => (
                  <div key={`cs-m-${i}`} className="bg-[#06142b] border border-white/10 rounded-lg p-3 space-y-2">
                    <input value={item.name} onChange={(e) => updateCustomService(i, { name: e.target.value })} placeholder="Nome do serviço" className="w-full bg-[#0a1929] border border-white/10 rounded px-2 py-1.5 text-white text-xs" />
                    <div className="flex items-center gap-2">
                      <div className="flex-1">
                        <label className="text-[10px] text-gray-500">Qtd</label>
                        <input type="number" min="1" value={item.quantity} onChange={(e) => updateCustomService(i, { quantity: parseInt(e.target.value) || 1 })} className="w-full bg-[#0a1929] border border-white/10 rounded px-2 py-1 text-white text-xs" />
                      </div>
                      <div className="flex-1">
                        <label className="text-[10px] text-gray-500">Preço unit.</label>
                        <input type="number" step="0.01" value={item.unit_price} onChange={(e) => updateCustomService(i, { unit_price: parseFloat(e.target.value) || 0 })} className="w-full bg-[#0a1929] border border-white/10 rounded px-2 py-1 text-white text-xs" />
                      </div>
                      <div className="text-right">
                        <label className="text-[10px] text-gray-500">Subtotal</label>
                        <p className="text-white text-sm font-semibold">{formatEUR(item.subtotal)}</p>
                      </div>
                    </div>
                    <button onClick={() => removeCustomService(i)} className="text-red-400 hover:text-red-300 text-xs">Remover</button>
                  </div>
                ))}
              </div>
              <button onClick={addCustomService} className="mt-3 text-sm text-[#f4d000] hover:underline">+ Adicionar serviço personalizado</button>
            </div>
          )}

          {/* Discounts, fees, tax */}
          <div className="bg-[#0a1929] border border-white/10 rounded-xl p-4 space-y-3">
            <h4 className="text-xs font-semibold text-[#f4d000] uppercase tracking-wider">Descontos, taxas e impostos</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-gray-500">Desconto (€)</label>
                <input type="number" step="0.01" value={discount} onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)} className="w-full bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
              </div>
              <div>
                <label className="text-xs text-gray-500">Desconto (%)</label>
                <input type="number" step="0.01" value={discountPercent} onChange={(e) => setDiscountPercent(parseFloat(e.target.value) || 0)} className="w-full bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
              </div>
              <div>
                <label className="text-xs text-gray-500">{IVA_LABEL}</label>
                <button type="button" onClick={() => setTaxEnabled((v) => !v)} className={`w-full px-3 py-2 rounded-lg text-sm border transition-colors ${taxEnabled ? 'bg-[#f4d000]/15 border-[#f4d000]/50 text-[#f4d000]' : 'bg-[#06142b] border-white/10 text-gray-400'}`}>
                  {taxEnabled ? 'Ativo' : 'Desativado'}
                </button>
              </div>
            </div>

            {/* Extra fees */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs text-gray-500">Taxas adicionais</label>
                <button onClick={addExtraFee} className="text-xs text-[#f4d000] hover:underline">+ Adicionar</button>
              </div>
              {extraFees.map((fee, i) => (
                <div key={i} className="flex gap-2 mb-2">
                  <input value={fee.label} onChange={(e) => updateExtraFee(i, { label: e.target.value })} placeholder="Descrição" className="flex-1 bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
                  <input type="number" step="0.01" value={fee.amount} onChange={(e) => updateExtraFee(i, { amount: parseFloat(e.target.value) || 0 })} placeholder="Valor (€)" className="w-28 bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
                  <button onClick={() => removeExtraFee(i)} className="text-red-400 hover:text-red-300 px-2">x</button>
                </div>
              ))}
            </div>
          </div>

          {/* Live total */}
          <div className="bg-[#f4d000]/10 border border-[#f4d000]/30 rounded-xl p-4">
            <div className="flex justify-between text-sm text-gray-300 mb-1">
              <span>Subtotal</span><span>{formatEUR(totals.subtotal)}</span>
            </div>
            {totals.discountAmount > 0 && (
              <div className="flex justify-between text-sm text-gray-300 mb-1">
                <span>Desconto</span><span>-{formatEUR(totals.discountAmount)}</span>
              </div>
            )}
            {totals.feesTotal > 0 && (
              <div className="flex justify-between text-sm text-gray-300 mb-1">
                <span>Taxas adicionais</span><span>{formatEUR(totals.feesTotal)}</span>
              </div>
            )}
            {totals.taxAmount > 0 && (
              <div className="flex justify-between text-sm text-gray-300 mb-1">
                <span>{taxLabel || 'Imposto'}</span><span>{formatEUR(totals.taxAmount)}</span>
              </div>
            )}
            <div className="flex justify-between text-lg font-bold text-white pt-2 border-t border-white/10">
              <span>Total</span><span>{formatEUR(totals.total)}</span>
            </div>
            {totals.hasPending && (
              <p className="text-amber-500 text-xs mt-2">Existem serviços sem preço definido. Defina o preço antes de finalizar.</p>
            )}
          </div>

          <div className="flex justify-between pt-4">
            <button onClick={() => setStep(3)} className="px-4 py-2 text-gray-400 hover:text-white text-sm">Voltar</button>
            <button onClick={() => setStep(5)} className="px-6 py-2.5 bg-[#f4d000] text-[#06142b] rounded-lg text-sm font-semibold hover:opacity-90">Avançar</button>
          </div>
        </div>
      )}

      {/* Step 5: Summary */}
      {step === 5 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white mb-2">Resumo do orçamento</h3>

          <div className="bg-[#0a1929] border border-white/10 rounded-xl p-5 space-y-4">
            {/* Client info */}
            {selectedClient && (
              <div>
                <h4 className="text-xs font-semibold text-[#f4d000] uppercase tracking-wider mb-2">Cliente</h4>
                <p className="text-white text-sm font-medium">{selectedClient.name}</p>
                {selectedClient.company && <p className="text-gray-400 text-sm">{selectedClient.company}</p>}
                <p className="text-gray-400 text-sm">{selectedClient.email} {selectedClient.phone && `• ${selectedClient.phone}`}</p>
              </div>
            )}

            {/* Model info */}
            <div>
              <h4 className="text-xs font-semibold text-[#f4d000] uppercase tracking-wider mb-2">Aeronave</h4>
              <div className="flex gap-4">
                {modelImage && <img src={modelImage} alt={modelLabel} className="w-20 h-20 rounded-lg object-cover" />}
                <div>
                  <p className="text-white text-sm font-medium">{modelLabel}</p>
                  {selectedModelId === 'custom' && customModel.registration && <p className="text-gray-400 text-xs">Matrícula: {customModel.registration}</p>}
                  {selectedModel && selectedModel.registration && <p className="text-gray-400 text-xs">Matrícula: {selectedModel.registration}</p>}
                  <p className="text-gray-400 text-xs">{estimatedHours}h estimadas</p>
                </div>
              </div>
            </div>

            {/* Line items summary */}
            <div>
              <h4 className="text-xs font-semibold text-[#f4d000] uppercase tracking-wider mb-2">Serviços</h4>
              <div className="hidden sm:block overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-gray-500 text-xs border-b border-white/10">
                    <th className="pb-1">Serviço</th><th className="pb-1 text-center">Qtd</th><th className="pb-1 text-right">Preço</th><th className="pb-1 text-right">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  {allItems.map((item, i) => (
                    <tr key={i} className="border-b border-white/5">
                      <td className="py-1.5 text-white">{item.name || '(sem nome)'}</td>
                      <td className="py-1.5 text-center text-gray-400">{item.quantity}</td>
                      <td className="py-1.5 text-right text-gray-400">{formatEUR(item.unit_price)}</td>
                      <td className="py-1.5 text-right text-white">{formatEUR(item.subtotal)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              </div>
              {/* Mobile summary */}
              <div className="sm:hidden space-y-2">
                {allItems.map((item, i) => (
                  <div key={`sum-m-${i}`} className="flex justify-between items-center text-sm border-b border-white/5 pb-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-white truncate">{item.name || '(sem nome)'}</p>
                      <p className="text-gray-500 text-xs">{item.quantity}x {formatEUR(item.unit_price)}</p>
                    </div>
                    <span className="text-white font-medium ml-2">{formatEUR(item.subtotal)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Totals */}
            <div className="border-t border-white/10 pt-3 space-y-1">
              <div className="flex justify-between text-sm text-gray-300"><span>Subtotal</span><span>{formatEUR(totals.subtotal)}</span></div>
              {totals.discountAmount > 0 && <div className="flex justify-between text-sm text-gray-300"><span>Desconto</span><span>-{formatEUR(totals.discountAmount)}</span></div>}
              {totals.feesTotal > 0 && <div className="flex justify-between text-sm text-gray-300"><span>Taxas</span><span>{formatEUR(totals.feesTotal)}</span></div>}
              {totals.taxAmount > 0 && <div className="flex justify-between text-sm text-gray-300"><span>{taxLabel}</span><span>{formatEUR(totals.taxAmount)}</span></div>}
              <div className="flex justify-between text-lg font-bold text-white pt-1"><span>Total</span><span>{formatEUR(totals.total)}</span></div>
            </div>

            {/* Additional fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-gray-500">Prazo estimado</label>
                <input value={estimatedDuration} onChange={(e) => setEstimatedDuration(e.target.value)} placeholder="Ex: 2 dias" className="w-full bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
              </div>
              <div>
                <label className="text-xs text-gray-500">Válido até</label>
                <input type="date" value={validUntil} onChange={(e) => setValidUntil(e.target.value)} className="w-full bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
              </div>
            </div>
            <div>
              <label className="text-xs text-gray-500">Observações para o cliente</label>
              <textarea value={clientNotes} onChange={(e) => setClientNotes(e.target.value)} rows={2} className="w-full bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            </div>
            <div>
              <label className="text-xs text-gray-500">Notas internas (visível apenas para administrador)</label>
              <textarea value={internalNotes} onChange={(e) => setInternalNotes(e.target.value)} rows={2} className="w-full bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row sm:flex-wrap gap-3 pt-2">
            <button onClick={() => setStep(4)} className="px-4 py-2.5 text-gray-400 hover:text-white text-sm">Voltar</button>
            <div className="flex flex-col sm:flex-row gap-3 flex-1 sm:justify-end">
              <button onClick={() => handleSave('rascunho')} disabled={saving} className="px-5 py-2.5 bg-white/10 text-white rounded-lg text-sm font-semibold hover:bg-white/15 disabled:opacity-50">
                {saving ? 'A guardar...' : 'Guardar rascunho'}
              </button>
              <button onClick={() => handleSave('enviado')} disabled={saving} className="px-5 py-2.5 bg-[#f4d000] text-[#06142b] rounded-lg text-sm font-semibold hover:opacity-90 disabled:opacity-50">
                {saving ? 'A criar...' : 'Criar pedido de orçamento'}
              </button>
            </div>
            <button onClick={onCancel} className="px-5 py-2.5 text-gray-400 hover:text-white text-sm">Cancelar</button>
          </div>
        </div>
      )}
    </div>
  );
}
