import { useState, useEffect } from 'react';
import {
  fetchQuoteServices, fetchQuotePackages, fetchAircraftModels,
  upsertQuoteService, deleteQuoteService,
  upsertQuotePackage, deleteQuotePackage,
  upsertAircraftModel, deleteAircraftModel,
} from '@/lib/quoteApi';
import { formatEUR } from '@/lib/quotePricing';
import type { QuoteServiceItem, QuotePackage, AircraftModel, PricingRule } from '@/lib/quoteTypes';

type Tab = 'services' | 'packages' | 'aircraft';

const PRICING_RULES: { value: PricingRule; label: string }[] = [
  { value: 'fixed', label: 'Preço fixo' },
  { value: 'hourly', label: 'Por hora' },
  { value: 'estimated_hours', label: 'Horas estimadas' },
  { value: 'dimension', label: 'Por dimensão' },
  { value: 'custom', label: 'Personalizado' },
];

export default function PricingManager() {
  const [tab, setTab] = useState<Tab>('services');
  const [services, setServices] = useState<QuoteServiceItem[]>([]);
  const [packages, setPackages] = useState<QuotePackage[]>([]);
  const [aircraft, setAircraft] = useState<AircraftModel[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [s, p, a] = await Promise.all([
          fetchQuoteServices(), fetchQuotePackages(),
          fetchAircraftModels(),
        ]);
        setServices(s); setPackages(p); setAircraft(a);
      } catch (err) { console.error(err); } finally { setLoading(false); }
    })();
  }, []);

  // === Services ===
  const saveService = async (svc: Partial<QuoteServiceItem>) => {
    try { const saved = await upsertQuoteService(svc); setServices((p) => { const i = p.findIndex((x) => x.id === saved.id); if (i >= 0) return p.map((x) => x.id === saved.id ? saved : x); return [...p, saved]; }); } catch { alert('Erro ao guardar serviço.'); }
  };
  const removeService = async (id: string) => { if (!confirm('Eliminar este serviço?')) return; try { await deleteQuoteService(id); setServices((p) => p.filter((x) => x.id !== id)); } catch { alert('Erro ao eliminar.'); } };

  // === Packages ===
  const savePackage = async (pkg: Partial<QuotePackage>) => {
    try { const saved = await upsertQuotePackage(pkg); setPackages((p) => { const i = p.findIndex((x) => x.id === saved.id); if (i >= 0) return p.map((x) => x.id === saved.id ? saved : x); return [...p, saved]; }); } catch { alert('Erro ao guardar pacote.'); }
  };
  const removePackage = async (id: string) => { if (!confirm('Eliminar este pacote?')) return; try { await deleteQuotePackage(id); setPackages((p) => p.filter((x) => x.id !== id)); } catch { alert('Erro ao eliminar.'); } };

  // === Aircraft ===
  const saveAircraft = async (m: Partial<AircraftModel>) => {
    try { const saved = await upsertAircraftModel(m); setAircraft((p) => { const i = p.findIndex((x) => x.id === saved.id); if (i >= 0) return p.map((x) => x.id === saved.id ? saved : x); return [...p, saved]; }); } catch { alert('Erro ao guardar modelo.'); }
  };
  const removeAircraft = async (id: string) => { if (!confirm('Eliminar este modelo?')) return; try { await deleteAircraftModel(id); setAircraft((p) => p.filter((x) => x.id !== id)); } catch { alert('Erro ao eliminar.'); } };

  const exportCSV = () => {
    let csv = '';
    if (tab === 'services') {
      csv = ['Categoria,Nome,Descrição,Regra,Preço,Taxa/Hora,Ativo', ...services.map((s) =>
        `"${s.category}","${s.name}","${s.description}","${s.pricing_rule}",${s.price},${s.hourly_rate},${s.is_active}`
      )].join('\n');
    } else if (tab === 'aircraft') {
      csv = ['Fabricante,Modelo,Matrícula,Categoria,Horas,Ativo', ...aircraft.map((m) =>
        `"${m.manufacturer}","${m.model}","${m.registration}","${m.category}",${m.estimated_hours},${m.is_active}`
      )].join('\n');
    }
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${tab}_${new Date().toISOString().slice(0, 10)}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-[#f4d000]/20 border-t-[#f4d000] rounded-full animate-spin" />
      </div>
    );
  }

  const tabs: { id: Tab; label: string }[] = [
    { id: 'services', label: 'Serviços' },
    { id: 'packages', label: 'Pacotes' },
    { id: 'aircraft', label: 'Aeronaves' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h3 className="text-lg font-semibold text-white">Preçário e regras de cálculo</h3>
        <button onClick={exportCSV} className="px-4 py-2 bg-white/5 text-gray-300 rounded-lg text-sm hover:bg-white/10">Exportar CSV</button>
      </div>

      <div className="flex gap-1 border-b border-white/10 overflow-x-auto">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 text-sm transition-colors whitespace-nowrap ${tab === t.id ? 'text-[#f4d000] border-b-2 border-[#f4d000]' : 'text-gray-400 hover:text-white'}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'services' && (
        <ServiceTab services={services} onSave={saveService} onDelete={removeService} />
      )}
      {tab === 'packages' && (
        <PackageTab packages={packages} services={services} onSave={savePackage} onDelete={removePackage} />
      )}
      {tab === 'aircraft' && (
        <ModelTab models={aircraft} type="aircraft" onSave={saveAircraft} onDelete={removeAircraft} />
      )}
    </div>
  );
}

function ServiceTab({ services, onSave, onDelete }: { services: QuoteServiceItem[]; onSave: (s: Partial<QuoteServiceItem>) => void; onDelete: (id: string) => void }) {
  const [editing, setEditing] = useState<Partial<QuoteServiceItem> | null>(null);

  return (
    <div className="space-y-3">
      <button onClick={() => setEditing({ category: 'aero', pricing_rule: 'fixed', is_active: true, display_order: 0, price: 0, hourly_rate: 0 })} className="text-sm text-[#f4d000] hover:underline">+ Novo serviço</button>

      {editing && (
        <div className="bg-[#0a1929] border border-white/10 rounded-xl p-4 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <select value={editing.category || 'aero'} onChange={(e) => setEditing({ ...editing, category: e.target.value as any })} className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white">
              <option value="aero">Aviation</option>
            </select>
            <input value={editing.name || ''} onChange={(e) => setEditing({ ...editing, name: e.target.value })} placeholder="Nome" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            <input value={editing.description || ''} onChange={(e) => setEditing({ ...editing, description: e.target.value })} placeholder="Descrição" className="col-span-1 sm:col-span-2 bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            <select value={editing.pricing_rule} onChange={(e) => setEditing({ ...editing, pricing_rule: e.target.value as PricingRule })} className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white">
              {PRICING_RULES.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
            </select>
            <input type="number" step="0.01" value={editing.price ?? 0} onChange={(e) => setEditing({ ...editing, price: parseFloat(e.target.value) || 0 })} placeholder="Preço (€)" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            <input type="number" step="0.01" value={editing.hourly_rate ?? 0} onChange={(e) => setEditing({ ...editing, hourly_rate: parseFloat(e.target.value) || 0 })} placeholder="Taxa/h (€)" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            <label className="flex items-center gap-2 text-sm text-white">
              <input type="checkbox" checked={editing.is_active ?? true} onChange={(e) => setEditing({ ...editing, is_active: e.target.checked })} className="accent-[#f4d000]" /> Ativo
            </label>
          </div>
          <div className="flex gap-2">
            <button onClick={() => { if (editing.name) { onSave(editing); setEditing(null); } }} className="px-4 py-2 bg-[#f4d000] text-[#06142b] rounded-lg text-sm font-semibold">Guardar</button>
            <button onClick={() => setEditing(null)} className="px-4 py-2 text-gray-400 text-sm">Cancelar</button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {services.map((s) => (
          <div key={s.id} className="bg-[#0a1929] border border-white/10 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-white text-sm font-medium">{s.name}</span>
              <span className="text-gray-500 text-xs ml-2">{s.category}</span>
              <span className="text-gray-500 text-xs ml-2">{PRICING_RULES.find((r) => r.value === s.pricing_rule)?.label}</span>
              {s.price > 0 && <span className="text-gray-400 text-xs ml-2">{formatEUR(s.price)}</span>}
              {s.hourly_rate > 0 && <span className="text-gray-400 text-xs ml-2">{formatEUR(s.hourly_rate)}/h</span>}
              {s.price === 0 && s.hourly_rate === 0 && <span className="text-amber-500 text-xs ml-2">Pendente</span>}
            </div>
            <div className="flex gap-2">
              <button onClick={() => setEditing(s)} className="text-gray-400 hover:text-white text-xs">Editar</button>
              <button onClick={() => onDelete(s.id)} className="text-red-400 hover:text-red-300 text-xs">Eliminar</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PackageTab({ packages, services, onSave, onDelete }: { packages: QuotePackage[]; services: QuoteServiceItem[]; onSave: (p: Partial<QuotePackage>) => void; onDelete: (id: string) => void }) {
  const [editing, setEditing] = useState<Partial<QuotePackage> | null>(null);

  const toggleServiceInPackage = (id: string) => {
    const current = new Set(editing?.service_ids || []);
    if (current.has(id)) current.delete(id); else current.add(id);
    setEditing({ ...editing, service_ids: Array.from(current) });
  };

  return (
    <div className="space-y-3">
      <button onClick={() => setEditing({ category: 'aero', is_active: true, display_order: 0, price: 0, service_ids: [] })} className="text-sm text-[#f4d000] hover:underline">+ Novo pacote</button>

      {editing && (
        <div className="bg-[#0a1929] border border-white/10 rounded-xl p-4 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <select value={editing.category || 'aero'} onChange={(e) => setEditing({ ...editing, category: e.target.value as any })} className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white">
              <option value="aero">Aviation</option>
            </select>
            <input value={editing.name || ''} onChange={(e) => setEditing({ ...editing, name: e.target.value })} placeholder="Nome do pacote" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            <input value={editing.description || ''} onChange={(e) => setEditing({ ...editing, description: e.target.value })} placeholder="Descrição" className="col-span-1 sm:col-span-2 bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            <input type="number" step="0.01" value={editing.price ?? 0} onChange={(e) => setEditing({ ...editing, price: parseFloat(e.target.value) || 0 })} placeholder="Preço (0 = soma dos serviços)" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
          </div>
          <div>
            <p className="text-xs text-gray-500 mb-2">Serviços incluídos:</p>
            <div className="space-y-1 max-h-40 overflow-y-auto">
              {services.filter((s) => s.category === editing.category).map((s) => (
                <label key={s.id} className="flex items-center gap-2 text-sm text-white">
                  <input type="checkbox" checked={(editing.service_ids || []).includes(s.id)} onChange={() => toggleServiceInPackage(s.id)} className="accent-[#f4d000]" />
                  {s.name}
                </label>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => { if (editing.name) { onSave(editing); setEditing(null); } }} className="px-4 py-2 bg-[#f4d000] text-[#06142b] rounded-lg text-sm font-semibold">Guardar</button>
            <button onClick={() => setEditing(null)} className="px-4 py-2 text-gray-400 text-sm">Cancelar</button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {packages.map((p) => (
          <div key={p.id} className="bg-[#0a1929] border border-white/10 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-white text-sm font-medium">{p.name}</span>
              <span className="text-gray-500 text-xs ml-2">{p.category}</span>
              <span className="text-gray-400 text-xs ml-2">{(p.service_ids || []).length} serviços</span>
              {p.price > 0 && <span className="text-gray-400 text-xs ml-2">{formatEUR(p.price)}</span>}
            </div>
            <div className="flex gap-2">
              <button onClick={() => setEditing(p)} className="text-gray-400 hover:text-white text-xs">Editar</button>
              <button onClick={() => onDelete(p.id)} className="text-red-400 hover:text-red-300 text-xs">Eliminar</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ModelTab({ models, type, onSave, onDelete }: { models: any[]; type: 'aircraft' | 'vessel'; onSave: (m: any) => void; onDelete: (id: string) => void }) {
  const [editing, setEditing] = useState<any>(null);

  return (
    <div className="space-y-3">
      <button onClick={() => setEditing({ is_active: true, display_order: 0, estimated_hours: 0 })} className="text-sm text-[#f4d000] hover:underline">+ Novo modelo</button>

      {editing && (
        <div className="bg-[#0a1929] border border-white/10 rounded-xl p-4 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input value={editing.manufacturer || ''} onChange={(e) => setEditing({ ...editing, manufacturer: e.target.value })} placeholder="Fabricante" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            <input value={editing.model || ''} onChange={(e) => setEditing({ ...editing, model: e.target.value })} placeholder="Modelo" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            {type === 'aircraft' && (
              <input value={editing.registration || ''} onChange={(e) => setEditing({ ...editing, registration: e.target.value })} placeholder="Matrícula" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            )}
            {type === 'vessel' && (
              <input type="number" step="0.1" value={editing.length_m ?? ''} onChange={(e) => setEditing({ ...editing, length_m: parseFloat(e.target.value) || 0 })} placeholder="Comprimento (m)" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            )}
            <input value={editing.category || ''} onChange={(e) => setEditing({ ...editing, category: e.target.value })} placeholder="Categoria" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            <input type="number" step="0.1" value={editing.estimated_hours ?? ''} onChange={(e) => setEditing({ ...editing, estimated_hours: parseFloat(e.target.value) || 0 })} placeholder="Horas estimadas" className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            <input value={editing.image_url || ''} onChange={(e) => setEditing({ ...editing, image_url: e.target.value })} placeholder="URL da imagem" className="col-span-1 sm:col-span-2 bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
            <label className="flex items-center gap-2 text-sm text-white">
              <input type="checkbox" checked={editing.is_active ?? true} onChange={(e) => setEditing({ ...editing, is_active: e.target.checked })} className="accent-[#f4d000]" /> Ativo
            </label>
          </div>
          <div className="flex gap-2">
            <button onClick={() => { if (editing.manufacturer && editing.model) { onSave(editing); setEditing(null); } }} className="px-4 py-2 bg-[#f4d000] text-[#06142b] rounded-lg text-sm font-semibold">Guardar</button>
            <button onClick={() => setEditing(null)} className="px-4 py-2 text-gray-400 text-sm">Cancelar</button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {models.map((m) => (
          <div key={m.id} className="bg-[#0a1929] border border-white/10 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              {m.image_url && <img src={m.image_url} alt="" className="w-12 h-12 rounded-lg object-cover" />}
              <div>
                <span className="text-white text-sm font-medium">{m.manufacturer} {m.model}</span>
                <span className="text-gray-500 text-xs ml-2">{m.category}</span>
                {type === 'aircraft' && m.registration && <span className="text-gray-500 text-xs ml-2">{m.registration}</span>}
                {type === 'vessel' && m.length_m > 0 && <span className="text-gray-500 text-xs ml-2">{m.length_m}m</span>}
                <span className="text-gray-400 text-xs ml-2">{m.estimated_hours}h</span>
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => setEditing(m)} className="text-gray-400 hover:text-white text-xs">Editar</button>
              <button onClick={() => onDelete(m.id)} className="text-red-400 hover:text-red-300 text-xs">Eliminar</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
