import { useEffect, useState } from 'react';
import { Plus, Trash2, Edit3, X, Save, Loader2, GripVertical, Eye, EyeOff, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import type { Service } from '@/lib/types';

export default function ServicesManager() {
  const { lang } = useI18n();
  const { reload: reloadSite } = useData();
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Service | null>(null);
  const [creating, setCreating] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const load = () => {
    supabase.from('services').select('*').order('display_order').then(({ data }) => {
      setServices(data || []);
      setLoading(false);
    });
  };

  useEffect(() => { load(); }, []);

  const empty: Partial<Service> = {
    category: 'aero', title_pt: '', title_en: '', title_es: '', title_fr: '', description_pt: '', description_en: '', description_es: '', description_fr: '',
    benefits_pt: [], benefits_en: [], benefits_es: [], benefits_fr: [], image_url: '', is_active: true, display_order: services.length + 1,
  };

  const save = async (svc: Partial<Service>) => {
    setMsg(null);
    if (svc.id) {
      const { error } = await supabase.from('services').update({
        category: svc.category, title_pt: svc.title_pt, title_en: svc.title_en, title_es: svc.title_es, title_fr: svc.title_fr,
        description_pt: svc.description_pt, description_en: svc.description_en, description_es: svc.description_es, description_fr: svc.description_fr,
        benefits_pt: svc.benefits_pt, benefits_en: svc.benefits_en, benefits_es: svc.benefits_es, benefits_fr: svc.benefits_fr,
        image_url: svc.image_url, is_active: svc.is_active, display_order: svc.display_order,
        updated_at: new Date().toISOString(),
      }).eq('id', svc.id);
      if (error) { setMsg({ type: 'error', text: error.message }); return; }
      setMsg({ type: 'success', text: lang === 'pt' ? 'Serviço atualizado!' : 'Service updated!' });
    } else {
      const { error } = await supabase.from('services').insert({
        category: svc.category, title_pt: svc.title_pt, title_en: svc.title_en, title_es: svc.title_es, title_fr: svc.title_fr,
        description_pt: svc.description_pt, description_en: svc.description_en, description_es: svc.description_es, description_fr: svc.description_fr,
        benefits_pt: svc.benefits_pt, benefits_en: svc.benefits_en, benefits_es: svc.benefits_es, benefits_fr: svc.benefits_fr,
        image_url: svc.image_url, is_active: svc.is_active, display_order: svc.display_order,
      });
      if (error) { setMsg({ type: 'error', text: error.message }); return; }
      setMsg({ type: 'success', text: lang === 'pt' ? 'Serviço criado!' : 'Service created!' });
    }
    setEditing(null);
    setCreating(false);
    load();
    reloadSite();
  };

  const toggle = async (svc: Service) => {
    await supabase.from('services').update({ is_active: !svc.is_active }).eq('id', svc.id);
    load();
    reloadSite();
  };

  const remove = async (id: string) => {
    if (!confirm(lang === 'pt' ? 'Eliminar este serviço?' : 'Delete this service?')) return;
    await supabase.from('services').delete().eq('id', id);
    load();
    reloadSite();
  };

  if (loading) return <div className="flex justify-center py-12"><div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      {msg && (
        <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${msg.type === 'success' ? 'bg-green-500/10 border border-green-500/30 text-green-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
          {msg.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}<span>{msg.text}</span>
        </div>
      )}

      <button onClick={() => { setCreating(true); setEditing(empty as Service); }} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#f4d000] text-[#0a1929] text-sm font-semibold">
        <Plus size={16} /> {lang === 'pt' ? 'Novo serviço' : 'New service'}
      </button>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {services.map((s) => (
          <div key={s.id} className="rounded-xl bg-white/5 border border-white/10 p-4">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-gray-400 uppercase">{s.category}</span>
                <h3 className="text-sm font-semibold text-white mt-1.5">{lang === 'pt' ? s.title_pt : s.title_en}</h3>
                <p className="text-xs text-gray-400 mt-1 line-clamp-2">{lang === 'pt' ? s.description_pt : s.description_en}</p>
              </div>
              {s.image_url && <img src={s.image_url} alt="" className="w-16 h-16 rounded-lg object-cover shrink-0" />}
            </div>
            <div className="flex items-center gap-2 mt-3">
              <button onClick={() => setEditing(s)} className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs bg-white/5 text-gray-300 hover:text-white"><Edit3 size={12} /> {lang === 'pt' ? 'Editar' : 'Edit'}</button>
              <button onClick={() => toggle(s)} className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs bg-white/5 text-gray-300 hover:text-white">
                {s.is_active ? <Eye size={12} /> : <EyeOff size={12} />} {s.is_active ? (lang === 'pt' ? 'Ativo' : 'Active') : (lang === 'pt' ? 'Inativo' : 'Inactive')}
              </button>
              <button onClick={() => remove(s.id)} className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs bg-red-500/10 text-red-300 hover:bg-red-500/20"><Trash2 size={12} /></button>
            </div>
          </div>
        ))}
      </div>

      {editing && (
        <ServiceModal svc={editing} isNew={creating} onSave={save} onClose={() => { setEditing(null); setCreating(false); }} />
      )}
    </div>
  );
}

function ServiceModal({ svc, isNew, onSave, onClose }: { svc: Partial<Service>; isNew: boolean; onSave: (s: Partial<Service>) => void; onClose: () => void }) {
  const { lang } = useI18n();
  const [form, setForm] = useState<Partial<Service>>(svc);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await onSave(form);
    setSaving(false);
  };

  const inp = "w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000]";
  const lbl = "block text-xs text-gray-400 mb-1";

  return (
    <div className="fixed inset-0 z-[100] bg-black/70 flex items-center justify-center p-4" onClick={onClose}>
      <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[#0f1f35] border border-white/10 p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-white">{isNew ? (lang === 'pt' ? 'Novo serviço' : 'New service') : (lang === 'pt' ? 'Editar serviço' : 'Edit service')}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white"><X size={20} /></button>
        </div>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl}>Categoria</label><select value={form.category} onChange={() => setForm({ ...form, category: 'aero' })} className={inp}><option value="aero" className="bg-[#0f1f35]">Aero</option></select></div>
            <div><label className={lbl}>{lang === 'pt' ? 'Ordem' : 'Order'}</label><input type="number" value={form.display_order || 1} onChange={(e) => setForm({ ...form, display_order: parseInt(e.target.value) })} className={inp} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl}>Título (PT)</label><input type="text" value={form.title_pt || ''} onChange={(e) => setForm({ ...form, title_pt: e.target.value })} className={inp} /></div>
            <div><label className={lbl}>Title (EN)</label><input type="text" value={form.title_en || ''} onChange={(e) => setForm({ ...form, title_en: e.target.value })} className={inp} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl}>Título (ES)</label><input type="text" value={form.title_es || ''} onChange={(e) => setForm({ ...form, title_es: e.target.value })} className={inp} /></div>
            <div><label className={lbl}>Titre (FR)</label><input type="text" value={form.title_fr || ''} onChange={(e) => setForm({ ...form, title_fr: e.target.value })} className={inp} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl}>Descrição (PT)</label><textarea value={form.description_pt || ''} onChange={(e) => setForm({ ...form, description_pt: e.target.value })} className={inp + ' min-h-[60px]'} /></div>
            <div><label className={lbl}>Description (EN)</label><textarea value={form.description_en || ''} onChange={(e) => setForm({ ...form, description_en: e.target.value })} className={inp + ' min-h-[60px]'} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl}>Descripción (ES)</label><textarea value={form.description_es || ''} onChange={(e) => setForm({ ...form, description_es: e.target.value })} className={inp + ' min-h-[60px]'} /></div>
            <div><label className={lbl}>Description (FR)</label><textarea value={form.description_fr || ''} onChange={(e) => setForm({ ...form, description_fr: e.target.value })} className={inp + ' min-h-[60px]'} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl}>Benefícios (PT) — um por linha</label><textarea value={(form.benefits_pt || []).join('\n')} onChange={(e) => setForm({ ...form, benefits_pt: e.target.value.split('\n').filter(Boolean) })} className={inp + ' min-h-[80px]'} /></div>
            <div><label className={lbl}>Benefits (EN) — one per line</label><textarea value={(form.benefits_en || []).join('\n')} onChange={(e) => setForm({ ...form, benefits_en: e.target.value.split('\n').filter(Boolean) })} className={inp + ' min-h-[80px]'} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl}>Beneficios (ES) — uno por línea</label><textarea value={(form.benefits_es || []).join('\n')} onChange={(e) => setForm({ ...form, benefits_es: e.target.value.split('\n').filter(Boolean) })} className={inp + ' min-h-[80px]'} /></div>
            <div><label className={lbl}>Avantages (FR) — un par ligne</label><textarea value={(form.benefits_fr || []).join('\n')} onChange={(e) => setForm({ ...form, benefits_fr: e.target.value.split('\n').filter(Boolean) })} className={inp + ' min-h-[80px]'} /></div>
          </div>
          <div><label className={lbl}>URL da imagem</label><input type="text" value={form.image_url || ''} onChange={(e) => setForm({ ...form, image_url: e.target.value })} className={inp} /></div>
          {form.image_url && <img src={form.image_url} alt="" className="w-full max-h-40 object-cover rounded-lg" />}
          <label className="flex items-center gap-2 text-xs text-gray-400"><input type="checkbox" checked={form.is_active ?? true} onChange={(e) => setForm({ ...form, is_active: e.target.checked })} className="accent-[#f4d000]" />{lang === 'pt' ? 'Ativo no site' : 'Active on site'}</label>
        </div>
        <div className="flex items-center justify-end gap-2 mt-4">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-xs border border-white/20 text-gray-300 hover:bg-white/5">{lang === 'pt' ? 'Cancelar' : 'Cancel'}</button>
          <button onClick={handleSave} disabled={saving} className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-[#f4d000] text-[#0a1929] disabled:opacity-50">{saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} {lang === 'pt' ? 'Guardar' : 'Save'}</button>
        </div>
      </div>
    </div>
  );
}
