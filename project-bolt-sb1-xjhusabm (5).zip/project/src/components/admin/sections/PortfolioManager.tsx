import { useEffect, useState } from 'react';
import { Plus, Trash2, Edit3, X, Save, Loader2, Eye, EyeOff, CheckCircle, AlertCircle, Upload } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import type { PortfolioItem, PortfolioImage } from '@/lib/types';

export default function PortfolioManager() {
  const { lang } = useI18n();
  const { reload: reloadSite } = useData();
  const [items, setItems] = useState<PortfolioItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<PortfolioItem | null>(null);
  const [creating, setCreating] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const load = () => {
    supabase.from('portfolio_items').select('*').order('display_order').then(({ data }) => {
      setItems(data || []);
      setLoading(false);
    });
  };

  useEffect(() => { load(); }, []);

  const empty: Partial<PortfolioItem> = {
    title_pt: '', title_en: '', title_es: '', title_fr: '', description_pt: '', description_en: '', description_es: '', description_fr: '',
    category: 'aero', images: [], is_published: true, display_order: items.length + 1,
  };

  const save = async (item: Partial<PortfolioItem>) => {
    setMsg(null);
    if (item.id) {
      const { error } = await supabase.from('portfolio_items').update({
        title_pt: item.title_pt, title_en: item.title_en, title_es: item.title_es, title_fr: item.title_fr,
        description_pt: item.description_pt, description_en: item.description_en, description_es: item.description_es, description_fr: item.description_fr,
        category: item.category, images: item.images, is_published: item.is_published, display_order: item.display_order,
        updated_at: new Date().toISOString(),
      }).eq('id', item.id);
      if (error) { setMsg({ type: 'error', text: error.message }); return; }
      setMsg({ type: 'success', text: lang === 'pt' ? 'Trabalho atualizado!' : 'Item updated!' });
    } else {
      const { error } = await supabase.from('portfolio_items').insert({
        title_pt: item.title_pt, title_en: item.title_en, title_es: item.title_es, title_fr: item.title_fr,
        description_pt: item.description_pt, description_en: item.description_en, description_es: item.description_es, description_fr: item.description_fr,
        category: item.category, images: item.images, is_published: item.is_published, display_order: item.display_order,
      });
      if (error) { setMsg({ type: 'error', text: error.message }); return; }
      setMsg({ type: 'success', text: lang === 'pt' ? 'Trabalho criado!' : 'Item created!' });
    }
    setEditing(null);
    setCreating(false);
    load();
    reloadSite();
  };

  const toggle = async (item: PortfolioItem) => {
    await supabase.from('portfolio_items').update({ is_published: !item.is_published }).eq('id', item.id);
    load();
    reloadSite();
  };

  const remove = async (id: string) => {
    if (!confirm(lang === 'pt' ? 'Eliminar este trabalho?' : 'Delete this item?')) return;
    await supabase.from('portfolio_items').delete().eq('id', id);
    load();
    reloadSite();
  };

  if (loading) return <div className="flex justify-center py-12"><div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      {msg && (
        <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${msg.type === 'success' ? 'bg-green-500/10 border border-green-500/30 text-green-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
          {msg.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}<span>{msg.text}</span>
        </div>
      )}

      <button onClick={() => { setCreating(true); setEditing(empty as PortfolioItem); }} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#f4d000] text-[#0a1929] text-sm font-semibold">
        <Plus size={16} /> {lang === 'pt' ? 'Novo trabalho' : 'New item'}
      </button>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {items.map((item) => (
          <div key={item.id} className="rounded-xl bg-white/5 border border-white/10 overflow-hidden">
            {item.images?.[0]?.url && <img src={item.images[0].url} alt="" className="w-full h-32 object-cover" />}
            <div className="p-3">
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-gray-400 uppercase">{item.category}</span>
              <h3 className="text-sm font-semibold text-white mt-1.5">{lang === 'pt' ? item.title_pt : item.title_en}</h3>
              <p className="text-xs text-gray-400 mt-1 line-clamp-2">{lang === 'pt' ? item.description_pt : item.description_en}</p>
              <div className="flex items-center gap-2 mt-2">
                <button onClick={() => setEditing(item)} className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-white/5 text-gray-300"><Edit3 size={12} /></button>
                <button onClick={() => toggle(item)} className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-white/5 text-gray-300">{item.is_published ? <Eye size={12} /> : <EyeOff size={12} />}</button>
                <button onClick={() => remove(item.id)} className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-red-500/10 text-red-300"><Trash2 size={12} /></button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {editing && <PortfolioModal item={editing} isNew={creating} onSave={save} onClose={() => { setEditing(null); setCreating(false); }} />}
    </div>
  );
}

function PortfolioModal({ item, isNew, onSave, onClose }: { item: Partial<PortfolioItem>; isNew: boolean; onSave: (i: Partial<PortfolioItem>) => void; onClose: () => void }) {
  const { lang } = useI18n();
  const [form, setForm] = useState<Partial<PortfolioItem>>(item);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (files: FileList) => {
    setUploading(true);
    const newImages: PortfolioImage[] = [...(form.images || [])];
    for (const file of Array.from(files)) {
      if (!file.type.startsWith('image/')) continue;
      const ext = file.name.split('.').pop();
      const fileName = `portfolio/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const { error: upErr } = await supabase.storage.from('portfolio').upload(fileName, file);
      if (upErr) { console.error(upErr); continue; }
      const { data: urlData } = supabase.storage.from('portfolio').getPublicUrl(fileName);
      newImages.push({ url: urlData.publicUrl, alt_pt: '', alt_en: '', alt_es: '', alt_fr: '' });
    }
    setForm({ ...form, images: newImages });
    setUploading(false);
  };

  const removeImage = (idx: number) => {
    setForm({ ...form, images: (form.images || []).filter((_, i) => i !== idx) });
  };

  const updateImageAlt = (idx: number, field: 'alt_pt' | 'alt_en' | 'alt_es' | 'alt_fr', value: string) => {
    const imgs = [...(form.images || [])];
    imgs[idx] = { ...imgs[idx], [field]: value };
    setForm({ ...form, images: imgs });
  };

  const handleSave = async () => { setSaving(true); await onSave(form); setSaving(false); };

  const inp = "w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000]";
  const lbl = "block text-xs text-gray-400 mb-1";

  return (
    <div className="fixed inset-0 z-[100] bg-black/70 flex items-center justify-center p-4" onClick={onClose}>
      <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[#0f1f35] border border-white/10 p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-white">{isNew ? (lang === 'pt' ? 'Novo trabalho' : 'New item') : (lang === 'pt' ? 'Editar trabalho' : 'Edit item')}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white"><X size={20} /></button>
        </div>
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-1"><label className={lbl}>Categoria</label><select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className={inp}><option value="aero" className="bg-[#0f1f35]">Aero</option></select></div>
            <div className="col-span-1"><label className={lbl}>{lang === 'pt' ? 'Ordem' : 'Order'}</label><input type="number" value={form.display_order || 1} onChange={(e) => setForm({ ...form, display_order: parseInt(e.target.value) })} className={inp} /></div>
            <div className="col-span-1 flex items-end"><label className="flex items-center gap-2 text-xs text-gray-400"><input type="checkbox" checked={form.is_published ?? true} onChange={(e) => setForm({ ...form, is_published: e.target.checked })} className="accent-[#f4d000]" />{lang === 'pt' ? 'Publicado' : 'Published'}</label></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl}>Título (PT)</label><input type="text" value={form.title_pt || ''} onChange={(e) => setForm({ ...form, title_pt: e.target.value })} className={inp} /></div>
            <div><label className={lbl}>Title (EN)</label><input type="text" value={form.title_en || ''} onChange={(e) => setForm({ ...form, title_en: e.target.value })} className={inp} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl}>Título (ES)</label><input type="text" value={form.title_es || ''} onChange={(e) => setForm({ ...form, title_es: e.target.value })} className={inp} /></div>
            <div><label className={lbl}>Titre (FR)</label><input type="text" value={form.title_fr || ''} onChange={(e) => setForm({ ...form, title_fr: e.target.value })} className={inp} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl}>Descrição (PT)</label><textarea value={form.description_pt || ''} onChange={(e) => setForm({ ...form, description_pt: e.target.value })} className={inp + ' min-h-[60px]'} /></div>
            <div><label className={lbl}>Description (EN)</label><textarea value={form.description_en || ''} onChange={(e) => setForm({ ...form, description_en: e.target.value })} className={inp + ' min-h-[60px]'} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className={lbl}>Descripción (ES)</label><textarea value={form.description_es || ''} onChange={(e) => setForm({ ...form, description_es: e.target.value })} className={inp + ' min-h-[60px]'} /></div>
            <div><label className={lbl}>Description (FR)</label><textarea value={form.description_fr || ''} onChange={(e) => setForm({ ...form, description_fr: e.target.value })} className={inp + ' min-h-[60px]'} /></div>
          </div>
          <div>
            <label className={lbl}>{lang === 'pt' ? 'Imagens' : 'Images'}</label>
            <label className="flex items-center justify-center gap-2 p-4 rounded-lg border border-dashed border-white/20 cursor-pointer hover:border-[#f4d000] transition-colors">
              <Upload size={18} className="text-gray-400" />
              <span className="text-xs text-gray-400">{uploading ? (lang === 'pt' ? 'A carregar...' : 'Uploading...') : (lang === 'pt' ? 'Clique para carregar imagens' : 'Click to upload images')}</span>
              <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => e.target.files && handleUpload(e.target.files)} />
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2">
              {(form.images || []).map((img, i) => (
                <div key={i} className="relative rounded-lg overflow-hidden">
                  <img src={img.url} alt="" className="w-full h-24 object-cover" />
                  <button onClick={() => removeImage(i)} className="absolute top-1 right-1 p-1 rounded bg-black/60 text-red-300"><X size={12} /></button>
                  <input type="text" value={img.alt_pt} onChange={(e) => updateImageAlt(i, 'alt_pt', e.target.value)} placeholder="Alt PT" className="w-full px-1 py-0.5 text-[10px] bg-white/5 text-white border-none focus:outline-none" />
                  <input type="text" value={img.alt_en} onChange={(e) => updateImageAlt(i, 'alt_en', e.target.value)} placeholder="Alt EN" className="w-full px-1 py-0.5 text-[10px] bg-white/5 text-white border-none focus:outline-none" />
                  <input type="text" value={img.alt_es || ''} onChange={(e) => updateImageAlt(i, 'alt_es' as any, e.target.value)} placeholder="Alt ES" className="w-full px-1 py-0.5 text-[10px] bg-white/5 text-white border-none focus:outline-none" />
                  <input type="text" value={img.alt_fr || ''} onChange={(e) => updateImageAlt(i, 'alt_fr' as any, e.target.value)} placeholder="Alt FR" className="w-full px-1 py-0.5 text-[10px] bg-white/5 text-white border-none focus:outline-none" />
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="flex items-center justify-end gap-2 mt-4">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-xs border border-white/20 text-gray-300 hover:bg-white/5">{lang === 'pt' ? 'Cancelar' : 'Cancel'}</button>
          <button onClick={handleSave} disabled={saving || uploading} className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-[#f4d000] text-[#0a1929] disabled:opacity-50">{saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} {lang === 'pt' ? 'Guardar' : 'Save'}</button>
        </div>
      </div>
    </div>
  );
}
