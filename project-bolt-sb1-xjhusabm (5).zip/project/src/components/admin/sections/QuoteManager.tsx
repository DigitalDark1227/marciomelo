import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import {
  fetchQuotes, fetchClients, fetchQuoteHistory,
  updateQuoteStatus, duplicateQuote, deleteQuote,
  fetchAllQuoteNumbers,
} from '@/lib/quoteApi';
import { formatEUR, generateQuoteNumber } from '@/lib/quotePricing';
import { downloadQuotePDF } from '@/lib/quotePdf';
import { useData } from '@/lib/data';
import type { Quote, Client, QuoteHistoryEntry, QuoteCalcStatus } from '@/lib/quoteTypes';
import QuoteCalculator from '@/components/admin/sections/QuoteCalculator';

const STATUS_OPTIONS: { value: QuoteCalcStatus; label: string; color: string }[] = [
  { value: 'rascunho', label: 'Rascunho', color: '#6b7280' },
  { value: 'enviado', label: 'Enviado ao cliente', color: '#3b82f6' },
  { value: 'aguardar', label: 'A aguardar resposta', color: '#f59e0b' },
  { value: 'aceite', label: 'Aceite', color: '#22c55e' },
  { value: 'recusado', label: 'Recusado', color: '#ef4444' },
  { value: 'expirado', label: 'Expirado', color: '#9ca3af' },
  { value: 'convertido', label: 'Convertido em serviço', color: '#8b5cf6' },
];

interface Props {
  onNavigate?: (section: string) => void;
}

export default function QuoteManager({ onNavigate }: Props) {
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedQuote, setSelectedQuote] = useState<Quote | null>(null);
  const [history, setHistory] = useState<QuoteHistoryEntry[]>([]);
  const [mode, setMode] = useState<'list' | 'calculator'>('list');
  const [editingQuote, setEditingQuote] = useState<any | null>(null);
  const { getSetting } = useData();

  const brand = getSetting('brand') || {};

  const load = async () => {
    setLoading(true);
    try {
      const [q, c] = await Promise.all([fetchQuotes(), fetchClients()]);
      setQuotes(q);
      setClients(c);
    } catch (err) {
      console.error('Failed to load quotes:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const clientMap = useMemo(() => {
    const map: Record<string, Client> = {};
    clients.forEach((c) => { map[c.id] = c; });
    return map;
  }, [clients]);

  const filteredQuotes = useMemo(() => {
    let result = quotes;
    if (statusFilter !== 'all') result = result.filter((q) => q.status === statusFilter);
    if (search) {
      const s = search.toLowerCase();
      result = result.filter((q) => {
        const client = clientMap[q.client_id];
        return (
          q.quote_number.toLowerCase().includes(s) ||
          q.model_label.toLowerCase().includes(s) ||
          (client?.name || '').toLowerCase().includes(s) ||
          (client?.company || '').toLowerCase().includes(s)
        );
      });
    }
    return result;
  }, [quotes, statusFilter, search, clientMap]);

  const openDetail = async (quote: Quote) => {
    setSelectedQuote(quote);
    try {
      const h = await fetchQuoteHistory(quote.id);
      setHistory(h);
    } catch { setHistory([]); }
  };

  const handleStatusChange = async (quote: Quote, newStatus: QuoteCalcStatus) => {
    try {
      await updateQuoteStatus(quote.id, quote.status, newStatus);
      setQuotes((prev) => prev.map((q) => q.id === quote.id ? { ...q, status: newStatus } : q));
      if (selectedQuote?.id === quote.id) {
        setSelectedQuote({ ...selectedQuote, status: newStatus });
        const h = await fetchQuoteHistory(quote.id);
        setHistory(h);
      }
    } catch (err) {
      console.error('Failed to update status:', err);
      alert('Erro ao alterar estado.');
    }
  };

  const handleDuplicate = async (quote: Quote) => {
    try {
      const numbers = await fetchAllQuoteNumbers();
      const newNumber = generateQuoteNumber(numbers);
      const dup = await duplicateQuote(quote.id, newNumber);
      if (dup) {
        await load();
        alert(`Orçamento duplicado: ${newNumber}`);
      }
    } catch (err) {
      console.error('Failed to duplicate:', err);
      alert('Erro ao duplicar orçamento.');
    }
  };

  const handleDelete = async (quote: Quote) => {
    if (!confirm(`Eliminar o orçamento ${quote.quote_number}?`)) return;
    try {
      await deleteQuote(quote.id);
      setQuotes((prev) => prev.filter((q) => q.id !== quote.id));
      setSelectedQuote(null);
    } catch (err) {
      console.error('Failed to delete:', err);
      alert('Erro ao eliminar orçamento.');
    }
  };

  const handleExportCSV = () => {
    const headers = ['Número', 'Cliente', 'Categoria', 'Modelo', 'Estado', 'Total', 'Data'];
    const rows = filteredQuotes.map((q) => {
      const c = clientMap[q.client_id];
      return [
        q.quote_number,
        c?.name || '',
        'Aviation',
        q.model_label,
        STATUS_OPTIONS.find((s) => s.value === q.status)?.label || q.status,
        q.total.toString(),
        new Date(q.created_at).toLocaleDateString('pt-PT'),
      ];
    });
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `orcamentos_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePDF = (quote: Quote) => {
    const client = clientMap[quote.client_id] || null;
    downloadQuotePDF(quote, client, brand);
  };

  if (mode === 'calculator') {
    return (
      <QuoteCalculator
        editingQuote={editingQuote}
        onSaved={() => { setMode('list'); setEditingQuote(null); load(); }}
        onCancel={() => { setMode('list'); setEditingQuote(null); }}
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h3 className="text-lg font-semibold text-white">Orçamentos</h3>
        <div className="flex gap-2">
          <button onClick={handleExportCSV} className="px-4 py-2 bg-white/5 text-gray-300 rounded-lg text-sm hover:bg-white/10">
            Exportar CSV
          </button>
          <button
            onClick={() => { setEditingQuote(null); setMode('calculator'); }}
            className="px-5 py-2 bg-[#f4d000] text-[#06142b] rounded-lg text-sm font-semibold hover:opacity-90 flex items-center gap-2"
          >
            + Criar novo orçamento
          </button>
        </div>
      </div>

      <div className="flex gap-3 flex-wrap">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Pesquisar por número, cliente ou modelo..."
          className="flex-1 min-w-[200px] bg-[#0a1929] border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white placeholder-gray-500"
        />
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="bg-[#0a1929] border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white"
        >
          <option value="all">Todos os estados</option>
          {STATUS_OPTIONS.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="w-8 h-8 border-2 border-[#f4d000]/20 border-t-[#f4d000] rounded-full animate-spin" />
        </div>
      ) : filteredQuotes.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          <p className="text-sm">Nenhum orçamento encontrado.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filteredQuotes.map((q) => {
            const client = clientMap[q.client_id];
            const statusInfo = STATUS_OPTIONS.find((s) => s.value === q.status);
            return (
              <div
                key={q.id}
                className="bg-[#0a1929] border border-white/10 rounded-xl p-4 hover:border-white/20 transition-colors cursor-pointer"
                onClick={() => openDetail(q)}
              >
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
                    <div>
                      <span className="text-white font-semibold text-sm">{q.quote_number}</span>
                      <span className="text-gray-500 text-sm ml-2">{q.model_label}</span>
                    </div>
                    <span
                      className="px-2 py-0.5 rounded-full text-xs font-medium"
                      style={{ background: `${statusInfo?.color || '#666'}20`, color: statusInfo?.color || '#666' }}
                    >
                      {statusInfo?.label || q.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 sm:gap-4 flex-wrap text-sm">
                    <span className="text-gray-400">{client?.name || 'Cliente não encontrado'}</span>
                    <span className="text-white font-semibold">{formatEUR(q.total)}</span>
                    <span className="text-gray-500 text-xs">{new Date(q.created_at).toLocaleDateString('pt-PT')}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Detail modal */}
      {selectedQuote && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setSelectedQuote(null)}>
          <div className="bg-[#0a1929] border border-white/10 rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-bold text-white">{selectedQuote.quote_number}</h3>
                <p className="text-gray-400 text-sm">{clientMap[selectedQuote.client_id]?.name}</p>
              </div>
              <button onClick={() => setSelectedQuote(null)} className="text-gray-400 hover:text-white">x</button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <div>
                <p className="text-xs text-gray-500 uppercase">Categoria</p>
                <p className="text-white text-sm">{'Aviation'}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 uppercase">Modelo</p>
                <p className="text-white text-sm">{selectedQuote.model_label}</p>
              </div>
              {selectedQuote.registration && (
                <div>
                  <p className="text-xs text-gray-500 uppercase">Matrícula</p>
                  <p className="text-white text-sm">{selectedQuote.registration}</p>
                </div>
              )}
              {selectedQuote.estimated_duration && (
                <div>
                  <p className="text-xs text-gray-500 uppercase">Prazo</p>
                  <p className="text-white text-sm">{selectedQuote.estimated_duration}</p>
                </div>
              )}
            </div>

            <div className="hidden sm:block overflow-x-auto mb-4">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-500 text-xs border-b border-white/10">
                  <th className="pb-2">Serviço</th><th className="pb-2 text-center">Qtd</th><th className="pb-2 text-right">Preço</th><th className="pb-2 text-right">Subtotal</th>
                </tr>
              </thead>
              <tbody>
                {(selectedQuote.line_items || []).map((item: any, i: number) => (
                  <tr key={i} className="border-b border-white/5">
                    <td className="py-2 text-white">{item.name}</td>
                    <td className="py-2 text-center text-gray-400">{item.quantity}</td>
                    <td className="py-2 text-right text-gray-400">{formatEUR(item.unit_price)}</td>
                    <td className="py-2 text-right text-white">{formatEUR(item.subtotal)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
            <div className="sm:hidden space-y-2 mb-4">
              {(selectedQuote.line_items || []).map((item: any, i: number) => (
                <div key={`m-${i}`} className="flex justify-between items-center text-sm border-b border-white/5 pb-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-white truncate">{item.name}</p>
                    <p className="text-gray-500 text-xs">{item.quantity}x {formatEUR(item.unit_price)}</p>
                  </div>
                  <span className="text-white font-medium ml-2">{formatEUR(item.subtotal)}</span>
                </div>
              ))}
            </div>

            <div className="border-t border-white/10 pt-3 space-y-1 mb-4">
              <div className="flex justify-between text-sm text-gray-300"><span>Total</span><span className="text-white font-bold">{formatEUR(selectedQuote.total)}</span></div>
            </div>

            {selectedQuote.client_notes && (
              <div className="bg-white/5 rounded-lg p-3 mb-3">
                <p className="text-xs text-gray-500 uppercase mb-1">Observações para o cliente</p>
                <p className="text-gray-300 text-sm">{selectedQuote.client_notes}</p>
              </div>
            )}
            {selectedQuote.internal_notes && (
              <div className="bg-amber-500/10 rounded-lg p-3 mb-3">
                <p className="text-xs text-amber-500 uppercase mb-1">Notas internas</p>
                <p className="text-gray-300 text-sm">{selectedQuote.internal_notes}</p>
              </div>
            )}

            {/* Status change */}
            <div className="mb-4">
              <label className="text-xs text-gray-500 uppercase mb-1 block">Estado</label>
              <select
                value={selectedQuote.status}
                onChange={(e) => handleStatusChange(selectedQuote, e.target.value as QuoteCalcStatus)}
                className="bg-[#06142b] border border-white/10 rounded-lg px-3 py-2 text-sm text-white w-full"
              >
                {STATUS_OPTIONS.map((s) => (
                  <option key={s.value} value={s.value}>{s.label}</option>
                ))}
              </select>
            </div>

            {/* History */}
            {history.length > 0 && (
              <div className="mb-4">
                <p className="text-xs text-gray-500 uppercase mb-2">Histórico</p>
                <div className="space-y-1">
                  {history.map((h) => (
                    <div key={h.id} className="text-xs text-gray-400 flex justify-between">
                      <span>{h.action.replace(/_/g, ' ')} {h.from_status && `(${h.from_status} → ${h.to_status})`}</span>
                      <span>{new Date(h.created_at).toLocaleString('pt-PT')}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-col sm:flex-row sm:flex-wrap gap-2 pt-4 border-t border-white/10">
              <button onClick={() => handlePDF(selectedQuote)} className="px-4 py-2 bg-white/10 text-white rounded-lg text-sm hover:bg-white/15">Gerar PDF</button>
              <button
                onClick={() => { setEditingQuote(selectedQuote); setMode('calculator'); setSelectedQuote(null); }}
                className="px-4 py-2 bg-white/10 text-white rounded-lg text-sm hover:bg-white/15"
              >
                Editar
              </button>
              <button onClick={() => handleDuplicate(selectedQuote)} className="px-4 py-2 bg-white/10 text-white rounded-lg text-sm hover:bg-white/15">Duplicar</button>
              {selectedQuote.status === 'aceite' && (
                <button
                  onClick={() => handleStatusChange(selectedQuote, 'convertido')}
                  className="px-4 py-2 bg-purple-500/20 text-purple-400 rounded-lg text-sm hover:bg-purple-500/30"
                >
                  Converter em serviço
                </button>
              )}
              <button onClick={() => handleDelete(selectedQuote)} className="px-4 py-2 text-red-400 hover:text-red-300 text-sm ml-auto">Eliminar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
