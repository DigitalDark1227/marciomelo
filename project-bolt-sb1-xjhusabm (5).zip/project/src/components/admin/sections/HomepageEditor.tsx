import { useEffect, useState } from 'react';
import { Save, Eye, Upload, Loader2, CheckCircle, AlertCircle, Plus, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import { LangTabs } from '@/components/admin/LangTabs';
import type { SiteContent, Language } from '@/lib/types';

export default function HomepageEditor() {
  const { lang } = useI18n();
  const { reload } = useData();
  const [content, setContent] = useState<SiteContent[]>([]);
  const [editing, setEditing] = useState<Record<string, any>>({});
  const [editLang, setEditLang] = useState<Language>('pt');
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    supabase.from('site_content').select('*').eq('section', 'homepage').order('display_order').then(({ data }) => {
      setContent(data || []);
      const edit: Record<string, any> = {};
      (data || []).forEach((c: SiteContent) => {
        edit[c.key] = { value_pt: c.value_pt, value_en: c.value_en, value_es: c.value_es || {}, value_fr: c.value_fr || {}, is_visible: c.is_visible };
      });
      setEditing(edit);
    });
  }, []);

  const updateField = (key: string, field: string, value: any) => {
    const langKey = `value_${editLang}`;
    setEditing((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        [langKey]: { ...prev[key]?.[langKey], [field]: value },
      },
    }));
  };

  const updateDifferentialsItems = (items: any[]) => {
    setEditing((prev) => ({
      ...prev,
      differentials: {
        ...prev.differentials,
        value_pt: { ...prev.differentials?.value_pt, items },
        value_en: { ...prev.differentials?.value_en, items },
        value_es: { ...prev.differentials?.value_es, items },
        value_fr: { ...prev.differentials?.value_fr, items },
      },
    }));
  };

  const addDifferentialItem = () => {
    const current = editing.differentials?.value_pt?.items || [];
    updateDifferentialsItems([...current, { icon: 'shield', title_pt: '', title_en: '', title_es: '', title_fr: '', desc_pt: '', desc_en: '', desc_es: '', desc_fr: '' }]);
  };

  const updateDifferentialItem = (index: number, field: string, value: string) => {
    const items = [...(editing.differentials?.value_pt?.items || [])];
    items[index] = { ...items[index], [field]: value };
    updateDifferentialsItems(items);
  };

  const removeDifferentialItem = (index: number) => {
    const items = (editing.differentials?.value_pt?.items || []).filter((_: any, i: number) => i !== index);
    updateDifferentialsItems(items);
  };

  const updateVisibility = (key: string, visible: boolean) => {
    setEditing((prev) => ({ ...prev, [key]: { ...prev[key], is_visible: visible } }));
  };

  const save = async (publish: boolean) => {
    setSaving(true);
    setMsg(null);
    try {
      for (const c of content) {
        const edits = editing[c.key];
        if (!edits) continue;
        const { error } = await supabase
          .from('site_content')
          .update({
            value_pt: edits.value_pt,
            value_en: edits.value_en,
            value_es: edits.value_es,
            value_fr: edits.value_fr,
            is_visible: edits.is_visible,
            is_published: publish ? true : c.is_published,
            updated_at: new Date().toISOString(),
          })
          .eq('id', c.id);
        if (error) throw error;
      }
      setMsg({ type: 'success', text: publish ? (lang === 'pt' ? 'Alterações publicadas com sucesso!' : 'Changes published!') : (lang === 'pt' ? 'Rascunho guardado!' : 'Draft saved!') });
      reload();
    } catch (err: any) {
      setMsg({ type: 'error', text: err.message || (lang === 'pt' ? 'Erro ao guardar' : 'Error saving') });
    }
    setSaving(false);
  };

  const sections: { key: string; label: string; labelEn: string; fields: { key: string; label: string; labelEn: string; type: 'text' | 'textarea' | 'image' }[] }[] = [
    { key: 'hero', label: 'Hero', labelEn: 'Hero', fields: [
      { key: 'title', label: 'Título', labelEn: 'Title', type: 'text' },
      { key: 'subtitle', label: 'Subtítulo', labelEn: 'Subtitle', type: 'text' },
      { key: 'description', label: 'Descrição', labelEn: 'Description', type: 'textarea' },
      { key: 'primary_btn', label: 'Botão principal', labelEn: 'Primary button', type: 'text' },
      { key: 'secondary_btn', label: 'Botão secundário', labelEn: 'Secondary button', type: 'text' },
      { key: 'image_url', label: 'Imagem principal', labelEn: 'Main image', type: 'image' },
    ]},
    { key: 'aero_card', label: 'Cartão Aero', labelEn: 'Aero Card', fields: [
      { key: 'title', label: 'Título', labelEn: 'Title', type: 'text' },
      { key: 'description', label: 'Descrição', labelEn: 'Description', type: 'textarea' },
      { key: 'image_url', label: 'Imagem', labelEn: 'Image', type: 'image' },
    ]},
    { key: 'differentials', label: 'Diferenciais', labelEn: 'Differentials', fields: [
      { key: 'title', label: 'Título da secção', labelEn: 'Section title', type: 'text' },
    ], hasItems: true },
    { key: 'portfolio_preview', label: 'Pré-visualização Portfólio', labelEn: 'Portfolio Preview', fields: [
      { key: 'title', label: 'Título', labelEn: 'Title', type: 'text' },
      { key: 'subtitle', label: 'Subtítulo', labelEn: 'Subtitle', type: 'text' },
      { key: 'btn_label', label: 'Texto do botão', labelEn: 'Button label', type: 'text' },
    ]},
    { key: 'cta', label: 'Chamada para ação', labelEn: 'Call to action', fields: [
      { key: 'title', label: 'Título', labelEn: 'Title', type: 'text' },
      { key: 'description', label: 'Descrição', labelEn: 'Description', type: 'textarea' },
      { key: 'btn_label', label: 'Texto do botão', labelEn: 'Button label', type: 'text' },
    ]},
    { key: 'about_summary', label: 'Resumo sobre', labelEn: 'About summary', fields: [
      { key: 'title', label: 'Título', labelEn: 'Title', type: 'text' },
      { key: 'description', label: 'Descrição', labelEn: 'Description', type: 'textarea' },
      { key: 'btn_label', label: 'Texto do botão', labelEn: 'Button label', type: 'text' },
    ]},
  ];

  const langKey = `value_${editLang}`;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <LangTabs value={editLang} onChange={setEditLang} />
        <div className="flex items-center gap-2">
          <button onClick={() => save(false)} disabled={saving} className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border border-white/20 text-gray-300 hover:bg-white/5 transition-colors disabled:opacity-50">
            {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} {lang === 'pt' ? 'Rascunho' : 'Draft'}
          </button>
          <button onClick={() => save(true)} disabled={saving} className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-[#f4d000] text-[#0a1929] disabled:opacity-50">
            {saving ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle size={14} />} {lang === 'pt' ? 'Publicar' : 'Publish'}
          </button>
        </div>
      </div>

      {msg && (
        <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${msg.type === 'success' ? 'bg-green-500/10 border border-green-500/30 text-green-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
          {msg.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
          <span>{msg.text}</span>
        </div>
      )}

      {sections.map((sec) => {
        const c = content.find((x) => x.key === sec.key);
        if (!c) return null;
        const data = editing[sec.key]?.[langKey] || {};
        return (
          <div key={sec.key} className="rounded-xl bg-white/5 border border-white/10 p-4 sm:p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-white">{lang === 'pt' ? sec.label : sec.labelEn}</h3>
              <label className="flex items-center gap-2 text-xs text-gray-400">
                <input type="checkbox" checked={editing[sec.key]?.is_visible ?? true} onChange={(e) => updateVisibility(sec.key, e.target.checked)} className="accent-[#f4d000]" />
                {lang === 'pt' ? 'Visível' : 'Visible'}
              </label>
            </div>
            <div className="space-y-3">
              {sec.fields.map((f) => (
                <div key={f.key}>
                  <label className="block text-xs text-gray-400 mb-1">{lang === 'pt' ? f.label : f.labelEn}</label>
                  {f.type === 'textarea' ? (
                    <textarea value={data[f.key] || ''} onChange={(e) => updateField(sec.key, f.key, e.target.value)} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000] min-h-[80px]" />
                  ) : f.type === 'image' ? (
                    <div className="space-y-2">
                      {data[f.key] && <img src={data[f.key]} alt="" className="w-full max-h-32 object-cover rounded-lg" />}
                      <input type="text" value={data[f.key] || ''} onChange={(e) => updateField(sec.key, f.key, e.target.value)} placeholder="URL da imagem" className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000]" />
                    </div>
                  ) : (
                    <input type="text" value={data[f.key] || ''} onChange={(e) => updateField(sec.key, f.key, e.target.value)} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000]" />
                  )}
                </div>
              ))}

              {(sec as any).hasItems && (
                <div className="mt-4 pt-4 border-t border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white">{lang === 'pt' ? 'Itens dos diferenciais' : 'Differential items'}</span>
                    <button onClick={addDifferentialItem} className="flex items-center gap-1 px-2 py-1 rounded-lg bg-[#f4d000]/10 text-[#f4d000] text-xs hover:bg-[#f4d000]/20">
                      <Plus size={12} /> {lang === 'pt' ? 'Adicionar' : 'Add'}
                    </button>
                  </div>
                  {(editing[sec.key]?.value_pt?.items || []).map((item: any, i: number) => (
                    <div key={i} className="rounded-lg bg-white/[0.03] border border-white/10 p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-gray-500">#{i + 1}</span>
                        <button onClick={() => removeDifferentialItem(i)} className="text-red-400/60 hover:text-red-400"><Trash2 size={12} /></button>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div><label className="block text-[10px] text-gray-500 mb-0.5">Ícone</label>
                          <select value={item.icon || 'shield'} onChange={(e) => updateDifferentialItem(i, 'icon', e.target.value)} className="w-full px-2 py-1.5 rounded-lg bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-[#f4d000]">
                            <option value="shield" className="bg-[#0f1f35]">Shield</option>
                            <option value="sparkles" className="bg-[#0f1f35]">Sparkles</option>
                            <option value="award" className="bg-[#0f1f35]">Award</option>
                            <option value="clock" className="bg-[#0f1f35]">Clock</option>
                          </select>
                        </div>
                        <div></div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div><label className="block text-[10px] text-gray-500 mb-0.5">Título (PT)</label><input type="text" value={item.title_pt || ''} onChange={(e) => updateDifferentialItem(i, 'title_pt', e.target.value)} className="w-full px-2 py-1.5 rounded-lg bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-[#f4d000]" /></div>
                        <div><label className="block text-[10px] text-gray-500 mb-0.5">Title (EN)</label><input type="text" value={item.title_en || ''} onChange={(e) => updateDifferentialItem(i, 'title_en', e.target.value)} className="w-full px-2 py-1.5 rounded-lg bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-[#f4d000]" /></div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div><label className="block text-[10px] text-gray-500 mb-0.5">Desc (PT)</label><textarea value={item.desc_pt || ''} onChange={(e) => updateDifferentialItem(i, 'desc_pt', e.target.value)} className="w-full px-2 py-1.5 rounded-lg bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-[#f4d000] min-h-[40px]" /></div>
                        <div><label className="block text-[10px] text-gray-500 mb-0.5">Desc (EN)</label><textarea value={item.desc_en || ''} onChange={(e) => updateDifferentialItem(i, 'desc_en', e.target.value)} className="w-full px-2 py-1.5 rounded-lg bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-[#f4d000] min-h-[40px]" /></div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div><label className="block text-[10px] text-gray-500 mb-0.5">Título (ES)</label><input type="text" value={item.title_es || ''} onChange={(e) => updateDifferentialItem(i, 'title_es', e.target.value)} className="w-full px-2 py-1.5 rounded-lg bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-[#f4d000]" /></div>
                        <div><label className="block text-[10px] text-gray-500 mb-0.5">Titre (FR)</label><input type="text" value={item.title_fr || ''} onChange={(e) => updateDifferentialItem(i, 'title_fr', e.target.value)} className="w-full px-2 py-1.5 rounded-lg bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-[#f4d000]" /></div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div><label className="block text-[10px] text-gray-500 mb-0.5">Desc (ES)</label><textarea value={item.desc_es || ''} onChange={(e) => updateDifferentialItem(i, 'desc_es', e.target.value)} className="w-full px-2 py-1.5 rounded-lg bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-[#f4d000] min-h-[40px]" /></div>
                        <div><label className="block text-[10px] text-gray-500 mb-0.5">Desc (FR)</label><textarea value={item.desc_fr || ''} onChange={(e) => updateDifferentialItem(i, 'desc_fr', e.target.value)} className="w-full px-2 py-1.5 rounded-lg bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-[#f4d000] min-h-[40px]" /></div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
