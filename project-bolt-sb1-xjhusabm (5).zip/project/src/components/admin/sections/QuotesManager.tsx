import { useEffect, useState } from 'react';
import { Search, Eye, X, Download, MessageCircle, Mail, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import type { QuoteRequest, QuoteStatus } from '@/lib/types';

const STATUSES: { value: QuoteStatus; label: string; labelEn: string; color: string }[] = [
  { value: 'novo', label: 'Novo', labelEn: 'New', color: '#3b82f6' },
  { value: 'em_analise', label: 'Em análise', labelEn: 'In analysis', color: '#f59e0b' },
  { value: 'contactado', label: 'Contactado', labelEn: 'Contacted', color: '#8b5cf6' },
  { value: 'orcamento_enviado', label: 'Orçamento enviado', labelEn: 'Quote sent', color: '#10b981' },
  { value: 'concluido', label: 'Concluído', labelEn: 'Completed', color: '#22c55e' },
  { value: 'arquivado', label: 'Arquivado', labelEn: 'Archived', color: '#6b7280' },
];

export default function QuotesManager() {
  const { lang } = useI18n();
  const [quotes, setQuotes] = useState<QuoteRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<QuoteStatus | 'all'>('all');
  const [selected, setSelected] = useState<QuoteRequest | null>(null);
  const [notes, setNotes] = useState('');
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const load = () => {
    supabase.from('quote_requests').select('*').order('created_at', { ascending: false })
      .then(({ data, error }) => {
        if (error) { console.error('Failed to load quotes:', error); }
        setQuotes(data || []);
        setLoading(false);
      })
      .catch((err) => { console.error('Failed to load quotes:', err); setLoading(false); });
  };

  useEffect(() => { load(); }, []);

  const filtered = quotes.filter((q) => {
    const matchSearch = !search || q.name.toLowerCase().includes(search.toLowerCase()) || q.email.toLowerCase().includes(search.toLowerCase()) || (q.company || '').toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || q.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const updateStatus = async (id: string, status: QuoteStatus) => {
    const { error } = await supabase.from('quote_requests').update({ status, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) { setMsg({ type: 'error', text: error.message }); return; }
    setMsg({ type: 'success', text: lang === 'pt' ? 'Estado atualizado!' : 'Status updated!' });
    load();
    setSelected((prev) => prev ? { ...prev, status } : null);
  };

  const saveNotes = async () => {
    if (!selected) return;
    const { error } = await supabase.from('quote_requests').update({ internal_notes: notes, updated_at: new Date().toISOString() }).eq('id', selected.id);
    if (error) { setMsg({ type: 'error', text: error.message }); return; }
    setMsg({ type: 'success', text: lang === 'pt' ? 'Notas guardadas!' : 'Notes saved!' });
    load();
  };

  const exportCsv = () => {
    const headers = ['Name', 'Company', 'Email', 'Phone', 'Service', 'Equipment', 'Location', 'Description', 'Status', 'Date', 'Language'];
    const rows = filtered.map((q) => [q.name, q.company, q.email, q.phone, q.service_type, q.equipment_type, q.location, q.description, q.status, q.created_at, q.language]);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${(c || '').replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `quotes-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) return <div className="flex justify-center py-12"><div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      {msg && (
        <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${msg.type === 'success' ? 'bg-green-500/10 border border-green-500/30 text-green-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
          {msg.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}<span>{msg.text}</span>
        </div>
      )}

      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder={lang === 'pt' ? 'Pesquisar...' : 'Search...'} className="w-full pl-9 pr-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000]" />
        </div>
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value as any)} className="px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000]">
          <option value="all" className="bg-[#0f1f35]">{lang === 'pt' ? 'Todos os estados' : 'All statuses'}</option>
          {STATUSES.map((s) => <option key={s.value} value={s.value} className="bg-[#0f1f35]">{lang === 'pt' ? s.label : s.labelEn}</option>)}
        </select>
        <button onClick={exportCsv} className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border border-white/20 text-gray-300 hover:bg-white/5"><Download size={14} /> CSV</button>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl bg-white/5 border border-white/10 p-8 text-center">
          <p className="text-sm text-gray-500">{lang === 'pt' ? 'Nenhum pedido encontrado.' : 'No quotes found.'}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((q) => {
            const st = STATUSES.find((s) => s.value === q.status);
            return (
              <div key={q.id} className="rounded-xl bg-white/5 border border-white/10 p-3 sm:p-4 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-white truncate">{q.name}</p>
                    <span className="text-[10px] px-2 py-0.5 rounded-full text-white shrink-0" style={{ backgroundColor: st?.color || '#6b7280' }}>{lang === 'pt' ? st?.label : st?.labelEn}</span>
                  </div>
                  <p className="text-xs text-gray-500 truncate mt-0.5">{q.service_type} — {q.email}</p>
                  <p className="text-[10px] text-gray-600 mt-0.5">{new Date(q.created_at).toLocaleString()}</p>
                </div>
                <button onClick={() => { setSelected(q); setNotes(q.internal_notes || ''); }} className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs bg-white/5 text-gray-300 hover:text-white"><Eye size={14} /> {lang === 'pt' ? 'Ver' : 'View'}</button>
              </div>
            );
          })}
        </div>
      )}

      {selected && (
        <div className="fixed inset-0 z-[100] bg-black/70 flex items-center justify-center p-4" onClick={() => setSelected(null)}>
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[#0f1f35] border border-white/10 p-5" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-white">{lang === 'pt' ? 'Detalhes do pedido' : 'Quote details'}</h3>
              <button onClick={() => setSelected(null)} className="text-gray-400 hover:text-white"><X size={20} /></button>
            </div>
            <div className="space-y-2 text-sm">
              <div className="grid grid-cols-2 gap-2">
                <div><span className="text-xs text-gray-500">{lang === 'pt' ? 'Nome' : 'Name'}</span><p className="text-white">{selected.name}</p></div>
                <div><span className="text-xs text-gray-500">{lang === 'pt' ? 'Empresa' : 'Company'}</span><p className="text-white">{selected.company || '—'}</p></div>
                <div><span className="text-xs text-gray-500">E-mail</span><p className="text-white">{selected.email}</p></div>
                <div><span className="text-xs text-gray-500">{lang === 'pt' ? 'Telefone' : 'Phone'}</span><p className="text-white">{selected.phone || '—'}</p></div>
                <div><span className="text-xs text-gray-500">{lang === 'pt' ? 'Serviço' : 'Service'}</span><p className="text-white">{selected.service_type || '—'}</p></div>
                <div><span className="text-xs text-gray-500">{lang === 'pt' ? 'Equipamento' : 'Equipment'}</span><p className="text-white">{selected.equipment_type || '—'}</p></div>
                <div><span className="text-xs text-gray-500">{lang === 'pt' ? 'Localização' : 'Location'}</span><p className="text-white">{selected.location || '—'}</p></div>
                <div><span className="text-xs text-gray-500">{lang === 'pt' ? 'Idioma' : 'Language'}</span><p className="text-white">{selected.language}</p></div>
              </div>
              <div><span className="text-xs text-gray-500">{lang === 'pt' ? 'Descrição' : 'Description'}</span><p className="text-white whitespace-pre-line">{selected.description || '—'}</p></div>
              <div><span className="text-xs text-gray-500">{lang === 'pt' ? 'Data' : 'Date'}</span><p className="text-white">{new Date(selected.created_at).toLocaleString()}</p></div>
            </div>
            <div className="mt-4">
              <label className="block text-xs text-gray-400 mb-1">{lang === 'pt' ? 'Estado' : 'Status'}</label>
              <select value={selected.status} onChange={(e) => updateStatus(selected.id, e.target.value as QuoteStatus)} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000]">
                {STATUSES.map((s) => <option key={s.value} value={s.value} className="bg-[#0f1f35]">{lang === 'pt' ? s.label : s.labelEn}</option>)}
              </select>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <a href={`mailto:${selected.email}`} className="flex items-center gap-1 px-3 py-2 rounded-lg text-xs bg-white/5 text-gray-300 hover:text-white"><Mail size={14} /> E-mail</a>
              {selected.phone && <a href={`https://wa.me/${selected.phone.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 px-3 py-2 rounded-lg text-xs bg-[#25D366]/20 text-green-300"><MessageCircle size={14} /> WhatsApp</a>}
            </div>
            <div className="mt-4">
              <label className="block text-xs text-gray-400 mb-1">{lang === 'pt' ? 'Notas internas (privadas)' : 'Internal notes (private)'}</label>
              <textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000] min-h-[80px]" />
              <button onClick={saveNotes} className="mt-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#f4d000] text-[#0a1929]">{lang === 'pt' ? 'Guardar notas' : 'Save notes'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
