import { useEffect, useState } from 'react';
import { Save, Loader2, CheckCircle, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import { LangTabs } from '@/components/admin/LangTabs';
import type { SiteContent, Language } from '@/lib/types';

const PAGES = [
  { section: 'about', label: 'Sobre a empresa', labelEn: 'About', fields: ['title', 'subtitle', 'content'] },
  { section: 'aero', label: 'Aero Detailing', labelEn: 'Aero Detailing', fields: ['title', 'subtitle', 'content'] },
  { section: 'privacy', label: 'Política de Privacidade', labelEn: 'Privacy Policy', fields: ['title', 'content'] },
  { section: 'cookies', label: 'Política de Cookies', labelEn: 'Cookies Policy', fields: ['title', 'content'] },
];

export default function PagesManager() {
  const { lang } = useI18n();
  const { reload } = useData();
  const [pageContent, setPageContent] = useState<Record<string, SiteContent>>({});
  const [editing, setEditing] = useState<Record<string, any>>({});
  const [editLang, setEditLang] = useState<Language>('pt');
  const [activePage, setActivePage] = useState(PAGES[0].section);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    const sections = PAGES.map((p) => p.section);
    supabase.from('site_content').select('*').in('section', sections).then(({ data }) => {
      const map: Record<string, SiteContent> = {};
      (data || []).forEach((c: SiteContent) => { map[`${c.section}_${c.key}`] = c; });
      setPageContent(map);
      const edit: Record<string, any> = {};
      (data || []).forEach((c: SiteContent) => {
        edit[`${c.section}_${c.key}`] = { value_pt: c.value_pt, value_en: c.value_en, value_es: c.value_es || {}, value_fr: c.value_fr || {}, is_visible: c.is_visible };
      });
      setEditing(edit);
    });
  }, []);

  const updateField = (key: string, field: string, value: any) => {
    const lk = `value_${editLang}`;
    setEditing((prev) => ({
      ...prev,
      [key]: { ...prev[key], [lk]: { ...prev[key]?.[lk], [field]: value } },
    }));
  };

  const save = async () => {
    const page = PAGES.find((p) => p.section === activePage)!;
    const contentKey = `${page.section}_main`;
    const c = pageContent[contentKey];
    const edits = editing[contentKey];
    if (!c || !edits) return;
    setSaving(true);
    setMsg(null);
    const { error } = await supabase.from('site_content').update({
      value_pt: edits.value_pt, value_en: edits.value_en, value_es: edits.value_es, value_fr: edits.value_fr, is_visible: edits.is_visible,
      updated_at: new Date().toISOString(),
    }).eq('id', c.id);
    if (error) {
      setMsg({ type: 'error', text: error.message });
    } else {
      setMsg({ type: 'success', text: lang === 'pt' ? 'Página guardada e publicada!' : 'Page saved and published!' });
      reload();
    }
    setSaving(false);
  };

  const lk = `value_${editLang}`;
  const page = PAGES.find((p) => p.section === activePage)!;
  const contentKey = `${page.section}_main`;
  const data = editing[contentKey]?.[lk] || {};

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <LangTabs value={editLang} onChange={setEditLang} />
        <button onClick={save} disabled={saving} className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-[#f4d000] text-[#0a1929] disabled:opacity-50">
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} {lang === 'pt' ? 'Guardar e publicar' : 'Save and publish'}
        </button>
      </div>

      {msg && (
        <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${msg.type === 'success' ? 'bg-green-500/10 border border-green-500/30 text-green-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
          {msg.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
          <span>{msg.text}</span>
        </div>
      )}

      <div className="flex flex-wrap gap-2">
        {PAGES.map((p) => (
          <button key={p.section} onClick={() => { setActivePage(p.section); setMsg(null); }}
            className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${activePage === p.section ? 'bg-white/10 text-white' : 'bg-white/5 text-gray-400 hover:text-white'}`}
            style={activePage === p.section ? { borderLeft: '2px solid #f4d000' } : {}}>
            {lang === 'pt' ? p.label : p.labelEn}
          </button>
        ))}
      </div>

      <div className="rounded-xl bg-white/5 border border-white/10 p-4 sm:p-5 space-y-3">
        <label className="flex items-center gap-2 text-xs text-gray-400">
          <input type="checkbox" checked={editing[contentKey]?.is_visible ?? true} onChange={(e) => setEditing((prev) => ({ ...prev, [contentKey]: { ...prev[contentKey], is_visible: e.target.checked } }))} className="accent-[#f4d000]" />
          {lang === 'pt' ? 'Secção visível no site' : 'Section visible on site'}
        </label>
        {page.fields.map((f) => (
          <div key={f}>
            <label className="block text-xs text-gray-400 mb-1 capitalize">{f}</label>
            {f === 'content' ? (
              <textarea value={data[f] || ''} onChange={(e) => updateField(contentKey, f, e.target.value)} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000] min-h-[200px]" />
            ) : (
              <input type="text" value={data[f] || ''} onChange={(e) => updateField(contentKey, f, e.target.value)} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-[#f4d000]" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
