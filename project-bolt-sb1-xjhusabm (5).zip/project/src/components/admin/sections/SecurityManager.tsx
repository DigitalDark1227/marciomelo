import { Shield, Mail } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';

export default function SecurityManager() {
  const { user } = useAuth();
  const { lang } = useI18n();

  return (
    <div className="space-y-4">
      <div className="rounded-xl bg-white/5 border border-white/10 p-4 sm:p-5">
        <div className="flex items-center gap-2 mb-4">
          <Shield size={18} className="text-[#f4d000]" />
          <h3 className="text-sm font-semibold text-white">{lang === 'pt' ? 'Informação da conta' : 'Account info'}</h3>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-300">
          <Mail size={16} className="text-gray-500" />
          <span>{user?.email}</span>
        </div>
      </div>
    </div>
  );
}
