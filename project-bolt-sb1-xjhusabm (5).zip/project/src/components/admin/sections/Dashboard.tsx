import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Inbox, FileText, Wrench, Image, ArrowRight, TrendingUp, Clock, CheckCircle2, Archive, Calculator } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';

interface Props {
  onNavigate: (section: any) => void;
}

export default function Dashboard({ onNavigate }: Props) {
  const { lang } = useI18n();
  const [stats, setStats] = useState({
    totalQuotes: 0,
    newQuotes: 0,
    inAnalysis: 0,
    quotesSent: 0,
    completed: 0,
    archived: 0,
    portfolioCount: 0,
    servicesCount: 0,
  });
  const [recentQuotes, setRecentQuotes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      supabase.from('quote_requests').select('*'),
      supabase.from('portfolio_items').select('id', { count: 'exact', head: true }),
      supabase.from('services').select('id', { count: 'exact', head: true }).eq('is_active', true),
    ]).then(([quotesRes, portfolioRes, servicesRes]) => {
      const quotes = quotesRes.data || [];
      setStats({
        totalQuotes: quotes.length,
        newQuotes: quotes.filter((q) => q.status === 'novo').length,
        inAnalysis: quotes.filter((q) => q.status === 'em_analise').length,
        quotesSent: quotes.filter((q) => q.status === 'orcamento_enviado').length,
        completed: quotes.filter((q) => q.status === 'concluido').length,
        archived: quotes.filter((q) => q.status === 'arquivado').length,
        portfolioCount: portfolioRes.count || 0,
        servicesCount: servicesRes.count || 0,
      });
      setRecentQuotes(quotes.slice(0, 5));
      setLoading(false);
    });
  }, []);

  const cards = [
    { label: lang === 'pt' ? 'Pedidos recebidos' : 'Quotes received', value: stats.totalQuotes, icon: Inbox, color: '#f4d000' },
    { label: lang === 'pt' ? 'Novos por responder' : 'New unanswered', value: stats.newQuotes, icon: Clock, color: '#3b82f6' },
    { label: lang === 'pt' ? 'Em análise' : 'In analysis', value: stats.inAnalysis, icon: TrendingUp, color: '#f59e0b' },
    { label: lang === 'pt' ? 'Orçamentos enviados' : 'Quotes sent', value: stats.quotesSent, icon: FileText, color: '#10b981' },
    { label: lang === 'pt' ? 'Concluídos' : 'Completed', value: stats.completed, icon: CheckCircle2, color: '#22c55e' },
    { label: lang === 'pt' ? 'Arquivados' : 'Archived', value: stats.archived, icon: Archive, color: '#6b7280' },
  ];

  const shortcuts = [
    { label: lang === 'pt' ? 'Editar homepage' : 'Edit homepage', section: 'homepage', icon: FileText },
    { label: lang === 'pt' ? 'Gerir serviços' : 'Manage services', section: 'services', icon: Wrench },
    { label: lang === 'pt' ? 'Gerir portfólio' : 'Manage portfolio', section: 'portfolio', icon: Image },
    { label: lang === 'pt' ? 'Ver pedidos' : 'View quotes', section: 'quotes', icon: Inbox },
    { label: lang === 'pt' ? 'Orçamentos' : 'Quotes', section: 'quotes_internal', icon: Calculator },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Create quote CTA */}
      <button
        onClick={() => onNavigate('quotes_internal')}
        className="w-full flex items-center justify-between p-5 rounded-xl bg-gradient-to-r from-[#f4d000] to-[#e0c000] text-[#06142b] hover:opacity-90 transition-opacity group"
      >
        <div className="flex items-center gap-3">
          <Calculator size={24} />
          <div className="text-left">
            <p className="text-base font-bold">{lang === 'pt' ? '+ Criar novo orçamento' : '+ Create new quote'}</p>
            <p className="text-xs opacity-80">{lang === 'pt' ? 'Calculadora interna — selecionar cliente, modelo, serviços e gerar PDF' : 'Internal calculator — select client, model, services and generate PDF'}</p>
          </div>
        </div>
        <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
      </button>

      {/* Stats cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
        {cards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div key={i} className="rounded-xl bg-white/5 border border-white/10 p-4 sm:p-5">
              <div className="flex items-center justify-between mb-2">
                <Icon size={20} style={{ color: card.color }} />
                <span className="text-2xl sm:text-3xl font-bold text-white">{card.value}</span>
              </div>
              <p className="text-xs text-gray-400">{card.label}</p>
            </div>
          );
        })}
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
        <div className="rounded-xl bg-white/5 border border-white/10 p-4 sm:p-5">
          <div className="flex items-center gap-2 mb-2">
            <Image size={18} className="text-[#f4d000]" />
            <h3 className="text-sm font-semibold text-white">{lang === 'pt' ? 'Trabalhos no portfólio' : 'Portfolio items'}</h3>
          </div>
          <p className="text-2xl font-bold text-white">{stats.portfolioCount}</p>
        </div>
        <div className="rounded-xl bg-white/5 border border-white/10 p-4 sm:p-5">
          <div className="flex items-center gap-2 mb-2">
            <Wrench size={18} className="text-[#f4d000]" />
            <h3 className="text-sm font-semibold text-white">{lang === 'pt' ? 'Serviços ativos' : 'Active services'}</h3>
          </div>
          <p className="text-2xl font-bold text-white">{stats.servicesCount}</p>
        </div>
      </div>

      {/* Shortcuts */}
      <div>
        <h3 className="text-sm font-semibold text-white mb-3">{lang === 'pt' ? 'Atalhos' : 'Shortcuts'}</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {shortcuts.map((s, i) => {
            const Icon = s.icon;
            return (
              <button
                key={i}
                onClick={() => onNavigate(s.section)}
                className="flex flex-col items-center gap-2 p-4 rounded-xl bg-white/5 border border-white/10 hover:border-[#f4d000]/50 transition-colors"
              >
                <Icon size={20} className="text-[#f4d000]" />
                <span className="text-xs text-gray-300 text-center">{s.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent quotes */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white">{lang === 'pt' ? 'Pedidos recentes' : 'Recent quotes'}</h3>
          <button onClick={() => onNavigate('quotes')} className="text-xs text-[#f4d000] hover:underline flex items-center gap-1">
            {lang === 'pt' ? 'Ver todos' : 'View all'} <ArrowRight size={12} />
          </button>
        </div>
        {recentQuotes.length === 0 ? (
          <div className="rounded-xl bg-white/5 border border-white/10 p-8 text-center">
            <Inbox size={32} className="mx-auto text-gray-600 mb-2" />
            <p className="text-sm text-gray-500">
              {lang === 'pt' ? 'Ainda não existem pedidos. Os pedidos enviados através do formulário aparecerão aqui.' : 'No quotes yet. Requests submitted through the form will appear here.'}
            </p>
          </div>
        ) : (
          <div className="rounded-xl bg-white/5 border border-white/10 overflow-hidden">
            {recentQuotes.map((q, i) => (
              <div key={q.id} className={`flex items-center justify-between p-3 sm:p-4 ${i < recentQuotes.length - 1 ? 'border-b border-white/5' : ''}`}>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-white truncate">{q.name}</p>
                  <p className="text-xs text-gray-500 truncate">{q.service_type} — {q.email}</p>
                </div>
                <span className="text-xs px-2 py-1 rounded-full bg-white/5 text-gray-400 ml-3 shrink-0">
                  {q.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* No data notice */}
      {stats.totalQuotes === 0 && stats.portfolioCount === 0 && (
        <div className="rounded-xl bg-[#f4d000]/10 border border-[#f4d000]/30 p-4">
          <p className="text-xs text-gray-300">
            {lang === 'pt'
              ? 'Bem-vindo! O site já está funcional. Use os atalhos acima para adicionar serviços, carregar trabalhos para o portfólio e gerir os pedidos que chegarão através do formulário.'
              : 'Welcome! The site is already functional. Use the shortcuts above to add services, upload portfolio work, and manage quotes that will arrive through the form.'}
          </p>
        </div>
      )}
    </div>
  );
}
