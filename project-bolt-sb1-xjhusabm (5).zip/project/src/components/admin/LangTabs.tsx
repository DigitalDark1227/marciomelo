import type { Language } from '@/lib/types';

const LANGS: { code: Language; label: string }[] = [
  { code: 'pt', label: 'PT' },
  { code: 'en', label: 'EN' },
  { code: 'es', label: 'ES' },
  { code: 'fr', label: 'FR' },
];

export function LangTabs({ value, onChange }: { value: Language; onChange: (l: Language) => void }) {
  return (
    <div className="flex items-center gap-2">
      {LANGS.map((l) => (
        <button
          key={l.code}
          onClick={() => onChange(l.code)}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            value === l.code ? 'bg-[#f4d000] text-[#0a1929]' : 'bg-white/5 text-gray-300 hover:bg-white/10'
          }`}
        >
          {l.label}
        </button>
      ))}
    </div>
  );
}
