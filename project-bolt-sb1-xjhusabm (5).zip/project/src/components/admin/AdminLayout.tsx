import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard, Home, FileText, Wrench, Image, Inbox,
  Phone, Search, Palette, Settings, Shield, LogOut, Menu, Calculator, Euro
} from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import AdminDashboard from '@/components/admin/sections/Dashboard';
import HomepageEditor from '@/components/admin/sections/HomepageEditor';
import PagesManager from '@/components/admin/sections/PagesManager';
import ServicesManager from '@/components/admin/sections/ServicesManager';
import PortfolioManager from '@/components/admin/sections/PortfolioManager';
import QuotesManager from '@/components/admin/sections/QuotesManager';
import QuoteManager from '@/components/admin/sections/QuoteManager';
import PricingManager from '@/components/admin/sections/PricingManager';
import ContactsManager from '@/components/admin/sections/ContactsManager';
import SEOManager from '@/components/admin/sections/SEOManager';
import AppearanceManager from '@/components/admin/sections/AppearanceManager';
import SettingsManager from '@/components/admin/sections/SettingsManager';
import SecurityManager from '@/components/admin/sections/SecurityManager';

type Section = 'dashboard' | 'homepage' | 'pages' | 'services' | 'portfolio' | 'quotes' | 'quotes_internal' | 'pricing' | 'contacts' | 'seo' | 'appearance' | 'settings' | 'security';

export default function AdminLayout() {
  const { signOut } = useAuth();
  const { lang } = useI18n();
  const [section, setSection] = useState<Section>('dashboard');
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems: { id: Section; label: string; labelEn: string; icon: any }[] = [
    { id: 'dashboard', label: 'Dashboard', labelEn: 'Dashboard', icon: LayoutDashboard },
    { id: 'homepage', label: 'Editar homepage', labelEn: 'Edit homepage', icon: Home },
    { id: 'pages', label: 'Páginas', labelEn: 'Pages', icon: FileText },
    { id: 'services', label: 'Serviços', labelEn: 'Services', icon: Wrench },
    { id: 'portfolio', label: 'Portfólio', labelEn: 'Portfolio', icon: Image },
    { id: 'quotes', label: 'Pedidos de orçamento', labelEn: 'Quote requests', icon: Inbox },
    { id: 'quotes_internal', label: 'Orçamentos', labelEn: 'Quotes', icon: Calculator },
    { id: 'pricing', label: 'Preçário', labelEn: 'Pricing', icon: Euro },
    { id: 'contacts', label: 'Contactos', labelEn: 'Contacts', icon: Phone },
    { id: 'seo', label: 'SEO', labelEn: 'SEO', icon: Search },
    { id: 'appearance', label: 'Aparência', labelEn: 'Appearance', icon: Palette },
    { id: 'settings', label: 'Definições', labelEn: 'Settings', icon: Settings },
    { id: 'security', label: 'Segurança', labelEn: 'Security', icon: Shield },
  ];

  const navigate = (id: Section) => {
    setSection(id);
    setMobileOpen(false);
  };

  const renderSection = () => {
    switch (section) {
      case 'dashboard': return <AdminDashboard onNavigate={navigate} />;
      case 'homepage': return <HomepageEditor />;
      case 'pages': return <PagesManager />;
      case 'services': return <ServicesManager />;
      case 'portfolio': return <PortfolioManager />;
      case 'quotes': return <QuotesManager />;
      case 'quotes_internal': return <QuoteManager onNavigate={(s) => navigate(s as Section)} />;
      case 'pricing': return <PricingManager />;
      case 'contacts': return <ContactsManager />;
      case 'seo': return <SEOManager />;
      case 'appearance': return <AppearanceManager />;
      case 'settings': return <SettingsManager />;
      case 'security': return <SecurityManager />;
      default: return <AdminDashboard onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#06142b] flex">
      {/* Sidebar — desktop */}
      <aside className="hidden lg:flex w-64 flex-col bg-[#070f1c] border-r border-white/10 fixed h-screen">
        <SidebarContent navItems={navItems} section={section} navigate={navigate} signOut={signOut} lang={lang} />
      </aside>

      {/* Sidebar — mobile drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <aside className="relative w-64 flex flex-col bg-[#070f1c] border-r border-white/10 h-full">
            <SidebarContent navItems={navItems} section={section} navigate={navigate} signOut={signOut} lang={lang} />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        {/* Top bar */}
        <header className="sticky top-0 z-30 bg-[#0a1929]/95 backdrop-blur-md border-b border-white/10 px-4 py-3 flex items-center justify-between">
          <button onClick={() => setMobileOpen(true)} className="lg:hidden p-2 text-white">
            <Menu size={22} />
          </button>
          <h2 className="text-sm font-semibold text-white flex-1 lg:flex-none">
            {navItems.find((n) => n.id === section)?.[lang === 'pt' ? 'label' : 'labelEn']}
          </h2>
          <Link
            to="/"
            className="text-xs text-gray-400 hover:text-white transition-colors flex items-center gap-1"
          >
            {lang === 'pt' ? 'Ver site' : 'View site'}
          </Link>
        </header>

        <div className="flex-1 p-4 sm:p-6 overflow-auto">
          {renderSection()}
        </div>
      </div>
    </div>
  );
}

function SidebarContent({
  navItems, section, navigate, signOut, lang
}: {
  navItems: { id: Section; label: string; labelEn: string; icon: any }[];
  section: Section;
  navigate: (id: Section) => void;
  signOut: () => Promise<void>;
  lang: 'pt' | 'en';
}) {
  return (
    <>
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center gap-2">
          <img src="/Logotipo_minimalista_Marcio_Melo_(1).png" alt="Márcio Melo Aircraft Detailing Works" className="h-16 w-36 object-contain" />
        </div>
        <p className="text-[10px] text-gray-500 uppercase tracking-wider mt-1">Admin Panel</p>
      </div>

      <nav className="flex-1 overflow-y-auto py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${
                section === item.id ? 'bg-white/5 text-white' : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
              style={section === item.id ? { borderLeft: '2px solid #f4d000' } : {}}
            >
              <Icon size={18} className={section === item.id ? 'text-[#f4d000]' : ''} />
              <span>{lang === 'pt' ? item.label : item.labelEn}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-3 border-t border-white/10">
        <button
          onClick={signOut}
          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-400 hover:text-white hover:bg-white/5 transition-colors rounded-lg"
        >
          <LogOut size={18} />
          <span>{lang === 'pt' ? 'Terminar sessão' : 'Sign out'}</span>
        </button>
      </div>
    </>
  );
}
