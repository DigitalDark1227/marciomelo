import { Link } from 'react-router-dom';
import { Instagram, Facebook, Linkedin, Mail, Phone, MapPin, Plane, ArrowUp } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import { Reveal } from '@/components/motion/Anim';
import { localizeField } from '@/lib/localize';

export default function Footer() {
  const { lang, t } = useI18n();
  const { getSetting } = useData();
  const brand = getSetting('brand') || {};
  const contact = getSetting('contact') || {};
  const accent = (getSetting('appearance') || {}).accent_color || '#f4d000';

  return (
    <footer className="relative bg-theme-primary border-t border-gold-400/15 overflow-hidden">
      {/* Top spotlight glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[200px] spotlight-gold pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 pt-14 pb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="col-span-1">
            <Reveal direction="up">
              <div className="mb-4">
                <img
                  src={brand.logo_url || '/Logotipo_minimalista_Marcio_Melo_(1).png'}
                  alt={brand.name || 'Márcio Melo Aircraft Detailing Works'}
                  className="h-18 w-40 object-contain"
                />
                {brand.tagline_pt && (
                  <p className="text-xs uppercase tracking-[0.15em] text-gold-400/80 mt-2">
                    {localizeField(brand, 'tagline', lang)}
                  </p>
                )}
              </div>
              <p className="text-sm text-navy-300 leading-relaxed max-w-xs">
                {localizeField(brand, 'description', lang)}
              </p>

              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full glass text-xs text-navy-200 mt-4 w-fit">
                <Plane size={12} style={{ color: accent }} />
                <span>Aircraft Detailing</span>
              </div>
            </Reveal>
          </div>

          {/* Quick links */}
          <div>
            <Reveal direction="up" delay={0.1}>
              <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-400 mb-4">
                {t('footer.navigation')}
              </h4>
              <ul className="space-y-3 text-sm">
                {[
                  { to: '/servicos', label: t('nav.services') },
                  { to: '/portfolio', label: t('nav.portfolio') },
                  { to: '/sobre', label: t('nav.about') },
                  { to: '/contactos', label: t('nav.contact') },
                ].map((link, i) => (
                  <li key={i}>
                    <Link
                      to={link.to}
                      className="group inline-flex items-center gap-2 text-navy-300 hover:text-white transition-colors duration-300"
                    >
                      <span
                        className="w-0 group-hover:w-3 h-px transition-all duration-300"
                        style={{ background: accent }}
                      />
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>

          {/* Contact */}
          <div>
            <Reveal direction="up" delay={0.2}>
              <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-400 mb-4">
                {t('footer.contact')}
              </h4>
              <ul className="space-y-3 text-sm">
                {contact.phone && (
                  <li>
                    <a
                      href={`tel:${contact.phone}`}
                      className="flex items-center gap-2.5 text-navy-300 hover:text-white transition-colors group"
                    >
                      <span className="w-8 h-8 rounded-lg glass flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Phone size={14} style={{ color: accent }} />
                      </span>
                      <span>{contact.phone}</span>
                    </a>
                  </li>
                )}
                {contact.email && (
                  <li>
                    <a
                      href={`mailto:${contact.email}`}
                      className="flex items-center gap-2.5 text-navy-300 hover:text-white transition-colors group"
                    >
                      <span className="w-8 h-8 rounded-lg glass flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Mail size={14} style={{ color: accent }} />
                      </span>
                      <span className="break-all">{contact.email}</span>
                    </a>
                  </li>
                )}
                {contact.location_pt && (
                  <li className="flex items-center gap-2.5 text-navy-300">
                    <span className="w-8 h-8 rounded-lg glass flex items-center justify-center">
                      <MapPin size={14} style={{ color: accent }} />
                    </span>
                    <span>{localizeField(contact, 'location', lang)}</span>
                  </li>
                )}
              </ul>
            </Reveal>
          </div>

          {/* Social */}
          <div>
            <Reveal direction="up" delay={0.3}>
              <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-400 mb-4">
                {t('footer.follow')}
              </h4>
              <div className="flex items-center gap-3">
                {contact.instagram && (
                  <a
                    href={contact.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full glass flex items-center justify-center text-navy-300 hover:text-white hover:scale-110 hover:border-gold-400/40 transition-all duration-300"
                  >
                    <Instagram size={18} />
                  </a>
                )}
                {contact.facebook && (
                  <a
                    href={contact.facebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full glass flex items-center justify-center text-navy-300 hover:text-white hover:scale-110 hover:border-gold-400/40 transition-all duration-300"
                  >
                    <Facebook size={18} />
                  </a>
                )}
                {contact.linkedin && (
                  <a
                    href={contact.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full glass flex items-center justify-center text-navy-300 hover:text-white hover:scale-110 hover:border-gold-400/40 transition-all duration-300"
                  >
                    <Linkedin size={18} />
                  </a>
                )}
              </div>

              {/* Back to top */}
              <button
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="mt-6 flex items-center gap-2 text-xs text-navy-400 hover:text-gold-400 transition-colors group"
              >
                <span>{t('footer.back_to_top')}</span>
                <span className="w-7 h-7 rounded-full glass flex items-center justify-center group-hover:-translate-y-1 transition-transform">
                  <ArrowUp size={12} style={{ color: accent }} />
                </span>
              </button>
            </Reveal>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-10 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-navy-400">
            © {new Date().getFullYear()} {brand.name || 'Márcio Melo'}. {t('footer.rights')}
          </p>
          <div className="flex items-center gap-5 text-xs">
            <Link to="/privacidade" className="text-navy-400 hover:text-navy-200 transition-colors">
              {t('footer.privacy')}
            </Link>
            <Link to="/cookies" className="text-navy-400 hover:text-navy-200 transition-colors">
              {t('footer.cookies')}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
