import { useState, useEffect } from 'react';
import { MessageCircle } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import { localizeField } from '@/lib/localize';

export default function FloatingContact() {
  const { lang } = useI18n();
  const { getSetting } = useData();
  const contact = getSetting('contact') || {};
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 400);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const whatsappNumber = (contact.whatsapp || '').replace(/\D/g, '');
  const whatsappMsg = localizeField(contact, 'whatsapp_msg', lang);
  const whatsappUrl = whatsappNumber
    ? `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMsg)}`
    : '';

  if (!whatsappUrl) return null;

  if (!show) return null;

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-3">
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="relative flex items-center justify-center w-14 h-14 rounded-full bg-[#25D366] shadow-xl hover:scale-110 transition-transform"
        aria-label="WhatsApp"
      >
        <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-50" />
        <MessageCircle size={24} className="text-white relative z-10" />
      </a>
    </div>
  );
}
