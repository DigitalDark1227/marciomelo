import { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Globe, Plane, ChevronDown } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import type { Language } from '@/lib/types';
import { Magnetic, ScrollProgress } from '@/components/motion/Anim';
import { useSEO } from '@/lib/useSEO';

export default function Header() {
  const { lang, setLang, t } = useI18n();
  const { getSetting } = useData();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);
  const location = useLocation();

  const langs: { code: Language; label: string; flag: string }[] = [
    { code: 'pt', label: 'Português', flag: 'PT' },
    { code: 'en', label: 'English', flag: 'EN' },
    { code: 'es', label: 'Español', flag: 'ES' },
    { code: 'fr', label: 'Français', flag: 'FR' },
  ];

  const brand = getSetting('brand') || {};
  const accent = (getSetting('appearance') || {}).accent_color || '#f4d000';

  useEffect(() => {
    if (brand.favicon_url) {
      const link = document.querySelector<HTMLLinkElement>("link[rel='icon']");
      if (link) link.href = brand.favicon_url;
    }
  }, [brand.favicon_url]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
    setLangOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(e.target as Node)) setLangOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  const navItems = [
    { to: '/', label: t('nav.home') },
    { to: '/servicos', label: t('nav.services') },
    { to: '/aero-detailing', label: t('nav.aero') },
    { to: '/portfolio', label: t('nav.portfolio') },
    { to: '/sobre', label: t('nav.about') },
    { to: '/contactos', label: t('nav.contact') },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path) || location.pathname.startsWith(path.replace('/servicos', '/services').replace('/sobre', '/about').replace('/contactos', '/contact'));
  };

  return (
    <>
      <ScrollProgress accent={accent} />
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'glass-strong shadow-[0_8px_32px_rgba(0,0,0,0.3)] py-0'
            : 'bg-transparent py-0'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16 sm:h-18 lg:h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center shrink-0 group">
              <img
                src={brand.logo_url || '/Logotipo_minimalista_Marcio_Melo_(1).png'}
                alt={brand.name || 'Márcio Melo Aircraft Detailing Works'}
                className="h-11 w-28 sm:h-14 sm:w-36 lg:h-16 lg:w-44 object-contain transition-transform duration-500 group-hover:scale-105"
              />
              {brand.tagline_pt && (
                <span className="hidden xl:block ml-3 text-xs uppercase tracking-[0.2em] text-navy-300 border-l border-white/10 pl-3">
                  {lang === 'pt' ? brand.tagline_pt : brand.tagline_en}
                </span>
              )}
            </Link>

            {/* Desktop nav */}
            <nav className="hidden lg:flex items-center gap-0.5">
              {navItems.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  className="relative px-3.5 py-2 text-sm font-medium transition-colors duration-300 group"
                  style={isActive(item.to) ? { color: accent } : { color: '#aabce0' }}
                >
                  <span className="relative z-10">{item.label}</span>
                  {isActive(item.to) && (
                    <span
                      className="absolute bottom-0 left-2 right-2 h-px rounded-full"
                      style={{ background: accent }}
                    />
                  )}
                  <span
                    className="absolute bottom-0 left-2 right-2 h-px rounded-full opacity-0 group-hover:opacity-50 transition-opacity duration-300"
                    style={{ background: accent }}
                  />
                </Link>
              ))}
            </nav>

            {/* Right actions */}
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="relative" ref={langRef}>
                <button
                  onClick={() => setLangOpen(!langOpen)}
                  className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-navy-200 hover:text-gold-400 transition-colors rounded-lg group"
                  aria-label="Switch language"
                >
                  <Globe size={15} className="transition-transform group-hover:rotate-180 duration-500" />
                  <span>{lang.toUpperCase()}</span>
                  <ChevronDown size={12} className={`transition-transform duration-300 ${langOpen ? 'rotate-180' : ''}`} />
                </button>
                {langOpen && (
                  <div className="absolute right-0 top-full mt-2 w-40 rounded-xl glass-strong shadow-2xl overflow-hidden z-50">
                    {langs.map((l) => (
                      <button
                        key={l.code}
                        onClick={() => { setLang(l.code); setLangOpen(false); }}
                        className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-sm transition-colors ${
                          lang === l.code ? 'text-gold-400 bg-white/5' : 'text-navy-200 hover:text-white hover:bg-white/5'
                        }`}
                      >
                        <span className="text-xs font-bold w-6">{l.flag}</span>
                        <span>{l.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <Magnetic strength={0.25} className="hidden sm:block">
                <Link
                  to="/contactos"
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-full text-navy-950 btn-shine transition-transform"
                  style={{
                    background: `linear-gradient(135deg, ${accent}, ${accent}dd)`,
                    boxShadow: `0 4px 20px ${accent}40`,
                  }}
                >
                  {t('nav.quote')}
                </Link>
              </Magnetic>

              {/* Mobile menu button */}
              <button
                onClick={() => setOpen(!open)}
                className="lg:hidden p-2 text-white relative z-50"
                aria-label="Menu"
              >
                {open ? <X size={22} /> : <Menu size={22} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile menu overlay */}
      {open && (
        <div className="lg:hidden fixed inset-0 z-40">
          <div
            className="absolute inset-0 bg-theme-primary-95 backdrop-blur-xl"
            onClick={() => setOpen(false)}
          />
          <nav className="absolute top-16 sm:top-18 left-0 right-0 px-4 py-6">
            <div className="flex flex-col gap-1">
              {navItems.map((item) => (
                <div key={item.to}>
                  <Link
                    to={item.to}
                    className={`px-4 py-3 text-base font-medium rounded-xl transition-colors ${
                      isActive(item.to) ? 'glass' : 'text-navy-200 hover:text-white'
                    }`}
                    style={isActive(item.to) ? { color: accent } : {}}
                  >
                    {item.label}
                  </Link>
                </div>
              ))}
              <div className="mt-3">
                <Link
                  to="/contactos"
                  className="flex items-center justify-center gap-2 px-5 py-3 rounded-full font-semibold text-sm text-navy-950"
                  style={{ background: `linear-gradient(135deg, ${accent}, ${accent}dd)` }}
                >
                  {t('nav.quote')}
                </Link>
              </div>

              {/* Decorative elements */}
              <div className="flex items-center justify-center gap-6 mt-6 opacity-40">
                <Plane size={20} style={{ color: accent }} />
                <div className="divider-gold w-12" />
                <Plane size={20} style={{ color: accent }} />
              </div>
            </div>
          </nav>
        </div>
      )}
    </>
  );
}
