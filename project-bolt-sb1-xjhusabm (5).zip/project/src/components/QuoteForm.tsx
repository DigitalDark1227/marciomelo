import { useState } from 'react';
import { Send, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import { supabase } from '@/lib/supabase';
import { localizeField } from '@/lib/localize';
import type { Language } from '@/lib/types';

export default function QuoteForm() {
  const { lang, t } = useI18n();
  const { getSetting } = useData();
  const formConfig = getSetting('form_config') || {};
  const accent = (getSetting('appearance') || {}).accent_color || '#f4d000';

  const categories: string[] = localizeField(formConfig, 'categories', lang) || ['Aircraft Detailing'];

  const [form, setForm] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    service_type: '',
    equipment_type: '',
    location: '',
    description: '',
  });
  const [status, setStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const requiredFields: string[] = formConfig.required_fields || ['name', 'email', 'service_type'];

  const validate = () => {
    const errs: Record<string, string> = {};
    requiredFields.forEach((field) => {
      if (!form[field as keyof typeof form]?.trim()) {
        errs[field] = t('quote.required');
      }
    });
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      errs.email = t('quote.invalid_email');
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setStatus('sending');
    const { error } = await supabase.from('quote_requests').insert({
      name: form.name,
      company: form.company,
      email: form.email,
      phone: form.phone,
      service_type: form.service_type,
      equipment_type: form.equipment_type,
      location: form.location,
      description: form.description,
      language: lang as Language,
      status: 'novo',
    });

    if (error) {
      setStatus('error');
    } else {
      setStatus('success');
      setForm({ name: '', company: '', email: '', phone: '', service_type: '', equipment_type: '', location: '', description: '' });
    }
  };

  const inputBase = "w-full px-4 py-3 rounded-xl bg-white/5 border text-white placeholder-navy-400 focus:outline-none transition-all duration-300 text-sm";
  const labelClass = "block text-xs font-medium text-navy-200 mb-2 tracking-wide";

  const inputClass = (fieldName?: string) =>
    `${inputBase} ${errors[fieldName || ''] ? 'border-red-500/50' : 'border-white/10'} focus:border-gold-400/60 focus:bg-white/[0.07]`;

  if (status === 'success') {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
        <div
          className="w-16 h-16 rounded-full flex items-center justify-center mb-5"
          style={{ background: `${accent}15`, border: `1px solid ${accent}40` }}
        >
          <CheckCircle size={32} style={{ color: accent }} />
        </div>
        <p className="text-lg font-medium text-white mb-2">
          {localizeField(formConfig, 'success_msg', lang)}
        </p>
        <button
          onClick={() => setStatus('idle')}
          className="mt-5 px-5 py-2.5 text-sm font-medium rounded-full glass text-navy-200 hover:bg-white/10 transition-colors"
        >
          {t('quote.send_another')}
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {status === 'error' && (
        <div className="flex items-center gap-2.5 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-sm">
          <AlertCircle size={18} />
          <span>{localizeField(formConfig, 'error_msg', lang)}</span>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className={labelClass}>{t('quote.name')} *</label>
          <input
            type="text"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className={inputClass('name')}
            placeholder={t('quote.placeholder_name')}
          />
          {errors.name && <p className="text-xs text-red-400 mt-1.5">{errors.name}</p>}
        </div>
        <div>
          <label className={labelClass}>{t('quote.company')}</label>
          <input
            type="text"
            value={form.company}
            onChange={(e) => setForm({ ...form, company: e.target.value })}
            className={inputClass()}
            placeholder={t('quote.placeholder_company')}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className={labelClass}>{t('quote.email')} *</label>
          <input
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className={inputClass('email')}
            placeholder="email@exemplo.com"
          />
          {errors.email && <p className="text-xs text-red-400 mt-1.5">{errors.email}</p>}
        </div>
        <div>
          <label className={labelClass}>{t('quote.phone')}</label>
          <input
            type="tel"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className={inputClass()}
            placeholder="+351 912 345 678"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className={labelClass}>{t('quote.service_type')} *</label>
          <select
            value={form.service_type}
            onChange={(e) => setForm({ ...form, service_type: e.target.value })}
            className={inputClass('service_type')}
          >
            <option value="">{t('quote.select_service')}</option>
            {categories.map((cat: string) => (
              <option key={cat} value={cat} className="bg-theme-bg">{cat}</option>
            ))}
          </select>
          {errors.service_type && <p className="text-xs text-red-400 mt-1.5">{errors.service_type}</p>}
        </div>
        <div>
          <label className={labelClass}>{t('quote.equipment_type')}</label>
          <input
            type="text"
            value={form.equipment_type}
            onChange={(e) => setForm({ ...form, equipment_type: e.target.value })}
            className={inputClass()}
            placeholder={t('quote.placeholder_equipment')}
          />
        </div>
      </div>

      <div>
        <label className={labelClass}>{t('quote.location')}</label>
        <input
          type="text"
          value={form.location}
          onChange={(e) => setForm({ ...form, location: e.target.value })}
          className={inputClass()}
          placeholder={t('quote.placeholder_location')}
        />
      </div>

      <div>
        <label className={labelClass}>{t('quote.description')}</label>
        <textarea
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          className={inputClass() + " min-h-[110px] resize-y"}
          placeholder={t('quote.placeholder_description')}
        />
      </div>

      <button
        type="submit"
        disabled={status === 'sending'}
        className="w-full flex items-center justify-center gap-2 px-6 py-4 rounded-xl font-semibold text-navy-950 btn-shine disabled:opacity-50 text-sm transition-all"
        style={{
          background: `linear-gradient(135deg, ${accent}, ${accent}cc)`,
          boxShadow: `0 8px 30px ${accent}30`,
        }}
      >
        {status === 'sending' ? (
          <>
            <Loader2 size={18} className="animate-spin" />
            {t('form.sending')}
          </>
        ) : (
          <>
            <Send size={18} />
            {t('quote.submit')}
          </>
        )}
      </button>
    </form>
  );
}
