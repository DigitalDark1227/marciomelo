export interface SiteContent {
  id: string;
  section: string;
  key: string;
  value_pt: Record<string, any>;
  value_en: Record<string, any>;
  value_es: Record<string, any>;
  value_fr: Record<string, any>;
  is_published: boolean;
  is_visible: boolean;
  display_order: number;
  updated_at: string;
}

export interface Service {
  id: string;
  category: 'aero';
  title_pt: string;
  title_en: string;
  title_es: string;
  title_fr: string;
  description_pt: string;
  description_en: string;
  description_es: string;
  description_fr: string;
  benefits_pt: string[];
  benefits_en: string[];
  benefits_es: string[];
  benefits_fr: string[];
  image_url: string;
  is_active: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export interface PortfolioImage {
  url: string;
  alt_pt: string;
  alt_en: string;
  alt_es: string;
  alt_fr: string;
}

export interface PortfolioItem {
  id: string;
  title_pt: string;
  title_en: string;
  title_es: string;
  title_fr: string;
  description_pt: string;
  description_en: string;
  description_es: string;
  description_fr: string;
  category: string;
  images: PortfolioImage[];
  is_published: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export type QuoteStatus = 'novo' | 'em_analise' | 'contactado' | 'orcamento_enviado' | 'concluido' | 'arquivado';

export interface QuoteRequest {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  service_type: string;
  equipment_type: string;
  location: string;
  description: string;
  language: string;
  status: QuoteStatus;
  attachments: any[];
  internal_notes: string;
  created_at: string;
  updated_at: string;
}

export interface SiteSettings {
  id: string;
  key: string;
  value: Record<string, any>;
  updated_at: string;
}

export type Language = 'pt' | 'en' | 'es' | 'fr';
