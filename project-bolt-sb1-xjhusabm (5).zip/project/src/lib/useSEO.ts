import { useEffect } from 'react';
import { useData } from '@/lib/data';
import { useI18n } from '@/lib/i18n';

interface SeoPageData {
  title?: string;
  description?: string;
  og_image?: string;
}

export function useSEO(page: string) {
  const { getSetting } = useData();
  const { lang } = useI18n();
  const seo = getSetting('seo') as Record<string, SeoPageData> | undefined;
  const brand = getSetting('brand') as { name?: string } | undefined;

  useEffect(() => {
    const pageData = seo?.[`${page}_${lang}`];
    const brandName = brand?.name || 'Márcio Melo';

    if (pageData?.title) {
      document.title = `${pageData.title} — ${brandName}`;
    }

    const setMeta = (name: string, content: string, attr: 'name' | 'property' = 'name') => {
      if (!content) return;
      let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${name}"]`);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    if (pageData?.description) {
      setMeta('description', pageData.description);
      setMeta('og:description', pageData.description, 'property');
      setMeta('twitter:description', pageData.description);
    }

    if (pageData?.og_image) {
      setMeta('og:image', pageData.og_image, 'property');
      setMeta('twitter:image', pageData.og_image);
    }

    setMeta('og:title', pageData?.title ? `${pageData.title} — ${brandName}` : document.title, 'property');
    setMeta('twitter:card', 'summary_large_image');
  }, [seo, brand, lang, page]);
}
