export interface Client {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  nif: string;
  address: string;
  notes: string;
  created_at: string;
  updated_at: string;
}

export interface AircraftModel {
  id: string;
  manufacturer: string;
  model: string;
  registration: string;
  category: string;
  estimated_hours: number;
  image_url: string;
  is_active: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export type PricingRule = 'fixed' | 'hourly' | 'estimated_hours' | 'dimension' | 'custom';

export interface QuoteServiceItem {
  id: string;
  category: string;
  name: string;
  description: string;
  pricing_rule: PricingRule;
  price: number;
  hourly_rate: number;
  estimated_hours?: number;
  is_active: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export interface QuotePackage {
  id: string;
  category: string;
  name: string;
  description: string;
  service_ids: string[];
  price: number;
  is_active: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export type QuoteCalcStatus =
  | 'rascunho'
  | 'enviado'
  | 'aguardar'
  | 'aceite'
  | 'recusado'
  | 'expirado'
  | 'convertido';

export interface LineItem {
  service_id: string;
  name: string;
  description: string;
  quantity: number;
  hours: number;
  unit_price: number;
  subtotal: number;
  pricing_rule: PricingRule;
  is_custom: boolean;
}

export interface ExtraFee {
  label: string;
  amount: number;
}

export interface Quote {
  id: string;
  quote_number: string;
  client_id: string;
  category: string;
  model_id: string | null;
  model_label: string;
  registration: string;
  model_image_url: string;
  status: QuoteCalcStatus;
  line_items: LineItem[];
  discount: number;
  discount_percent: number;
  tax_rate: number;
  tax_label: string;
  extra_fees: ExtraFee[];
  total: number;
  estimated_duration: string;
  client_notes: string;
  internal_notes: string;
  valid_until: string | null;
  created_at: string;
  updated_at: string;
}

export interface QuoteHistoryEntry {
  id: string;
  quote_id: string;
  action: string;
  from_status: string | null;
  to_status: string | null;
  notes: string;
  created_at: string;
}
