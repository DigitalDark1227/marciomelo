import type { Language } from '@/lib/types';

type Row = Record<string, any>;

export function localizeField(row: Row | null | undefined, field: string, lang: Language): any {
  if (!row) return '';
  const order: Language[] = [lang, 'en', 'pt'];
  for (const l of order) {
    const v = row[`${field}_${l}`];
    if (v !== undefined && v !== null && v !== '' && !(Array.isArray(v) && v.length === 0)) return v;
  }
  return '';
}

export function localizeValue(content: { value_pt?: Row; value_en?: Row; value_es?: Row; value_fr?: Row } | null | undefined, lang: Language): Row {
  if (!content) return {};
  const order: Language[] = [lang, 'en', 'pt'];
  for (const l of order) {
    const v = content[`value_${l}`];
    if (v && Object.keys(v).length > 0) return v;
  }
  return {};
}
