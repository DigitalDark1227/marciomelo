import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { Language } from '@/lib/types';

interface I18nContextValue {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string) => string;
}

export type TranslationKey = keyof typeof translations;

const translations: Record<string, { pt: string; en: string; es: string; fr: string }> = {
  'nav.home': { pt: 'Início', en: 'Home', es: 'Inicio', fr: 'Accueil' },
  'nav.services': { pt: 'Serviços', en: 'Services', es: 'Servicios', fr: 'Services' },
  'nav.aero': { pt: 'Aero Detailing', en: 'Aero Detailing', es: 'Aero Detailing', fr: 'Aero Detailing' },
  'nav.portfolio': { pt: 'Portfólio', en: 'Portfolio', es: 'Portafolio', fr: 'Portfolio' },
  'nav.about': { pt: 'Sobre', en: 'About', es: 'Acerca de', fr: 'À propos' },
  'nav.contact': { pt: 'Contactos', en: 'Contact', es: 'Contacto', fr: 'Contact' },
  'nav.quote': { pt: 'Solicitar orçamento', en: 'Request a quote', es: 'Solicitar presupuesto', fr: 'Demander un devis' },
  'footer.privacy': { pt: 'Política de Privacidade', en: 'Privacy Policy', es: 'Política de Privacidad', fr: 'Politique de confidentialité' },
  'footer.cookies': { pt: 'Política de Cookies', en: 'Cookies Policy', es: 'Política de Cookies', fr: 'Politique de cookies' },
  'footer.rights': { pt: 'Todos os direitos reservados.', en: 'All rights reserved.', es: 'Todos los derechos reservados.', fr: 'Tous droits réservés.' },
  'quote.title': { pt: 'Solicitar Orçamento', en: 'Request a Quote', es: 'Solicitar Presupuesto', fr: 'Demander un Devis' },
  'quote.name': { pt: 'Nome', en: 'Name', es: 'Nombre', fr: 'Nom' },
  'quote.company': { pt: 'Empresa (opcional)', en: 'Company (optional)', es: 'Empresa (opcional)', fr: 'Entreprise (optionnel)' },
  'quote.email': { pt: 'E-mail', en: 'Email', es: 'Correo electrónico', fr: 'E-mail' },
  'quote.phone': { pt: 'Telefone', en: 'Phone', es: 'Teléfono', fr: 'Téléphone' },
  'quote.service_type': { pt: 'Tipo de serviço', en: 'Service type', es: 'Tipo de servicio', fr: 'Type de service' },
  'quote.equipment_type': { pt: 'Tipo de equipamento', en: 'Equipment type', es: 'Tipo de equipo', fr: "Type d'équipement" },
  'quote.location': { pt: 'Localização', en: 'Location', es: 'Ubicación', fr: 'Localisation' },
  'quote.description': { pt: 'Descrição do pedido', en: 'Request description', es: 'Descripción de la solicitud', fr: 'Description de la demande' },
  'quote.attachments': { pt: 'Anexos (opcional)', en: 'Attachments (optional)', es: 'Adjuntos (opcional)', fr: 'Pièces jointes (optionnel)' },
  'quote.submit': { pt: 'Enviar pedido', en: 'Submit request', es: 'Enviar solicitud', fr: 'Envoyer la demande' },
  'quote.select_service': { pt: 'Selecione...', en: 'Select...', es: 'Seleccionar...', fr: 'Sélectionner...' },
  'quote.required': { pt: 'Campo obrigatório', en: 'Required field', es: 'Campo obligatorio', fr: 'Champ obligatoire' },
  'quote.invalid_email': { pt: 'E-mail inválido', en: 'Invalid email', es: 'Correo electrónico inválido', fr: 'E-mail invalide' },
  'form.sending': { pt: 'A enviar...', en: 'Sending...', es: 'Enviando...', fr: 'Envoi...' },
  'common.view_more': { pt: 'Saber mais', en: 'Learn more', es: 'Saber más', fr: 'En savoir plus' },
  'common.view_all': { pt: 'Ver todos', en: 'View all', es: 'Ver todos', fr: 'Voir tout' },
  'common.back': { pt: 'Voltar', en: 'Back', es: 'Volver', fr: 'Retour' },
  'portfolio.title': { pt: 'Portfólio', en: 'Portfolio', es: 'Portafolio', fr: 'Portfolio' },
  'portfolio.subtitle': { pt: 'Os nossos trabalhos recentes', en: 'Our recent work', es: 'Nuestros trabajos recientes', fr: 'Nos travaux récents' },
  'portfolio.empty': { pt: 'Em breve disponível.', en: 'Coming soon.', es: 'Próximamente disponible.', fr: 'Bientôt disponible.' },
  'services.title': { pt: 'Serviços', en: 'Services', es: 'Servicios', fr: 'Services' },
  'services.subtitle': { pt: 'O que podemos fazer por si', en: 'What we can do for you', es: 'Lo que podemos hacer por usted', fr: 'Ce que nous pouvons faire pour vous' },
  'contact.title': { pt: 'Contactos', en: 'Contact', es: 'Contacto', fr: 'Contact' },
  'contact.whatsapp': { pt: 'Falar no WhatsApp', en: 'Chat on WhatsApp', es: 'Chatear en WhatsApp', fr: 'Discuter sur WhatsApp' },
  'contact.area_label': { pt: 'Área de atuação', en: 'Service area', es: 'Área de servicio', fr: "Zone d'intervention" },
  'contact.hours_label': { pt: 'Horário', en: 'Hours', es: 'Horario', fr: 'Horaires' },
  'home.explore': { pt: 'Explorar', en: 'Explore', es: 'Explorar', fr: 'Explorer' },
  'home.differentials': { pt: 'Diferenciais', en: 'Differentiators', es: 'Diferenciales', fr: 'Atouts' },
  'home.what_we_do': { pt: 'O que fazemos', en: 'What we do', es: 'Qué hacemos', fr: 'Ce que nous faisons' },
  'home.work': { pt: 'Trabalhos', en: 'Work', es: 'Trabajos', fr: 'Réalisations' },
  'home.our_story': { pt: 'A nossa história', en: 'Our story', es: 'Nuestra historia', fr: 'Notre histoire' },
  'services.ready': { pt: 'Pronto para começar?', en: 'Ready to start?', es: '¿Listo para empezar?', fr: 'Prêt à commencer ?' },
  'services.aircraft_care': { pt: 'Cuidados de aeronaves', en: 'Aircraft care', es: 'Cuidado de aeronaves', fr: "Entretien d'aéronefs" },
  'services.our_services': { pt: 'Os nossos serviços', en: 'Our services', es: 'Nuestros servicios', fr: 'Nos services' },
  'portfolio.gallery': { pt: 'Galeria', en: 'Gallery', es: 'Galería', fr: 'Galerie' },
  'portfolio.all': { pt: 'Todos', en: 'All', es: 'Todos', fr: 'Tous' },
  'contact.get_in_touch': { pt: 'Fale connosco', en: 'Get in touch', es: 'Hable con nosotros', fr: 'Contactez-nous' },
  'contact.available': { pt: 'Estamos disponíveis para responder a todas as suas questões.', en: 'We are available to answer all your questions.', es: 'Estamos disponibles para responder a todas sus preguntas.', fr: 'Nous sommes disponibles pour répondre à toutes vos questions.' },
  'contact.info': { pt: 'Informações de contacto', en: 'Contact information', es: 'Información de contacto', fr: 'Informations de contact' },
  'about.quality': { pt: 'Qualidade', en: 'Quality', es: 'Calidad', fr: 'Qualité' },
  'about.experience': { pt: 'Experiência', en: 'Experience', es: 'Experiencia', fr: 'Expérience' },
  'about.precision': { pt: 'Precisão', en: 'Precision', es: 'Precisión', fr: 'Précision' },
  'cookies.digital_experience': { pt: 'Experiência digital', en: 'Digital experience', es: 'Experiencia digital', fr: 'Expérience numérique' },
  'privacy.transparency': { pt: 'Transparência', en: 'Transparency', es: 'Transparencia', fr: 'Transparence' },
  'footer.navigation': { pt: 'Navegação', en: 'Navigation', es: 'Navegación', fr: 'Navigation' },
  'footer.contact': { pt: 'Contacto', en: 'Contact', es: 'Contacto', fr: 'Contact' },
  'footer.follow': { pt: 'Seguir', en: 'Follow', es: 'Síguenos', fr: 'Suivez-nous' },
  'footer.back_to_top': { pt: 'Voltar ao topo', en: 'Back to top', es: 'Volver arriba', fr: 'Haut de page' },
  'quote.send_another': { pt: 'Enviar outro pedido', en: 'Send another request', es: 'Enviar otra solicitud', fr: 'Envoyer une autre demande' },
  'quote.placeholder_name': { pt: 'O seu nome', en: 'Your name', es: 'Su nombre', fr: 'Votre nom' },
  'quote.placeholder_company': { pt: 'Nome da empresa', en: 'Company name', es: 'Nombre de la empresa', fr: "Nom de l'entreprise" },
  'quote.placeholder_equipment': { pt: 'Ex: Jato privado, helicóptero...', en: 'Ex: Private jet, helicopter...', es: 'Ej: Jet privado, helicóptero...', fr: 'Ex : Jet privé, hélicoptère...' },
  'quote.placeholder_location': { pt: 'Cidade ou região', en: 'City or region', es: 'Ciudad o región', fr: 'Ville ou région' },
  'quote.placeholder_description': { pt: 'Descreva o seu pedido...', en: 'Describe your request...', es: 'Describa su solicitud...', fr: 'Décrivez votre demande...' },
};

const VALID_LANGS: Language[] = ['pt', 'en', 'es', 'fr'];

const I18nContext = createContext<I18nContextValue | undefined>(undefined);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Language>(() => {
    const saved = localStorage.getItem('lang');
    if (saved && VALID_LANGS.includes(saved as Language)) return saved as Language;
    return 'pt';
  });

  useEffect(() => {
    localStorage.setItem('lang', lang);
    document.documentElement.lang = lang === 'pt' ? 'pt-PT' : lang;
  }, [lang]);

  const setLang = (l: Language) => setLangState(l);

  const t = (key: string): string => {
    const entry = translations[key];
    if (!entry) return key;
    return entry[lang] || entry.pt;
  };

  return (
    <I18nContext.Provider value={{ lang, setLang, t }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used within I18nProvider');
  return ctx;
}
