import type { Quote, Client } from '@/lib/quoteTypes';
import { formatEUR } from '@/lib/quotePricing';

export function generateQuotePDF(quote: Quote, client: Client | null, brand: { name?: string; logo_url?: string; tagline_pt?: string; tagline_en?: string }): string {
  const items = quote.line_items || [];
  const subtotal = items.reduce((s, i) => s + i.subtotal, 0);
  const discountAmount = subtotal * (quote.discount_percent / 100) + quote.discount;
  const afterDiscount = subtotal - Math.min(discountAmount, subtotal);
  const feesTotal = (quote.extra_fees || []).reduce((s, f) => s + f.amount, 0);
  const taxAmount = (afterDiscount + feesTotal) * (quote.tax_rate / 100);

  const dateStr = new Date().toLocaleDateString('pt-PT');
  const validStr = quote.valid_until ? new Date(quote.valid_until).toLocaleDateString('pt-PT') : '';

  const rows = items.map((item) => `
    <tr>
      <td style="padding:8px 12px;border-bottom:1px solid #eee;">${item.name}${item.description ? `<br><span style="font-size:11px;color:#888;">${item.description}</span>` : ''}</td>
      <td style="padding:8px 12px;border-bottom:1px solid #eee;text-align:center;">${item.quantity}</td>
      <td style="padding:8px 12px;border-bottom:1px solid #eee;text-align:center;">${item.hours > 0 ? item.hours + 'h' : '-'}</td>
      <td style="padding:8px 12px;border-bottom:1px solid #eee;text-align:right;">${formatEUR(item.unit_price)}</td>
      <td style="padding:8px 12px;border-bottom:1px solid #eee;text-align:right;font-weight:500;">${formatEUR(item.subtotal)}</td>
    </tr>
  `).join('');

  const feeRows = (quote.extra_fees || []).map((f) => `
    <div style="display:flex;justify-content:space-between;padding:4px 0;">
      <span style="color:#666;">${f.label}</span><span>${formatEUR(f.amount)}</span>
    </div>
  `).join('');

  const html = `<!DOCTYPE html>
<html lang="pt-PT">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${quote.quote_number} - ${brand.name || 'Márcio Melo'}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #1a1a1a; background: #f5f5f5; }
  .page { max-width: 800px; margin: 0 auto; background: #fff; padding: 48px; min-height: 100vh; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 40px; border-bottom: 3px solid #f4d000; padding-bottom: 20px; }
  .brand-name { font-size: 24px; font-weight: 700; color: #06142b; }
  .brand-tagline { font-size: 12px; color: #888; margin-top: 4px; letter-spacing: 1px; text-transform: uppercase; }
  .quote-info { text-align: right; }
  .quote-number { font-size: 20px; font-weight: 700; color: #06142b; }
  .quote-date { font-size: 12px; color: #888; margin-top: 4px; }
  .section { margin-bottom: 32px; }
  .section-title { font-size: 11px; font-weight: 600; color: #f4d000; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 12px; }
  .client-info p, .model-info p { font-size: 14px; color: #333; line-height: 1.6; }
  .model-info { display: flex; gap: 20px; align-items: flex-start; }
  .model-info img { width: 120px; height: 80px; object-fit: cover; border-radius: 8px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
  th { padding: 10px 12px; text-align: left; font-size: 11px; font-weight: 600; color: #888; text-transform: uppercase; letter-spacing: 1px; border-bottom: 2px solid #06142b; }
  th.center { text-align: center; }
  th.right { text-align: right; }
  .totals { margin-left: auto; width: 300px; }
  .totals-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 14px; color: #555; }
  .totals-final { display: flex; justify-content: space-between; padding: 12px 0; font-size: 20px; font-weight: 700; color: #06142b; border-top: 2px solid #f4d000; margin-top: 8px; }
  .notes { margin-top: 32px; padding: 16px; background: #f9f9f9; border-radius: 8px; font-size: 13px; color: #555; line-height: 1.6; }
  .footer { margin-top: 48px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; font-size: 11px; color: #aaa; }
  .validity { margin-top: 16px; font-size: 13px; color: #888; }
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <div>
      ${brand.logo_url ? `<img src="${brand.logo_url}" alt="${brand.name || ''}" style="max-height:60px;margin-bottom:8px;" />` : ''}
      <div class="brand-name">${brand.name || 'Márcio Melo'}</div>
      <div class="brand-tagline">${brand.tagline_pt || 'Aircraft Detailing Works'}</div>
    </div>
    <div class="quote-info">
      <div class="quote-number">${quote.quote_number}</div>
      <div class="quote-date">Data: ${dateStr}</div>
      ${validStr ? `<div class="quote-date">Válido até: ${validStr}</div>` : ''}
    </div>
  </div>

  <div class="section">
    <div class="section-title">Cliente</div>
    <div class="client-info">
      <p style="font-weight:600;">${client?.name || '-'}</p>
      ${client?.company ? `<p>${client.company}</p>` : ''}
      ${client?.email ? `<p>${client.email}</p>` : ''}
      ${client?.phone ? `<p>${client.phone}</p>` : ''}
      ${client?.nif ? `<p>NIF: ${client.nif}</p>` : ''}
      ${client?.address ? `<p>${client.address}</p>` : ''}
    </div>
  </div>

  <div class="section">
    <div class="section-title">${quote.category === 'aero' ? 'Aeronave' : 'Embarcação'}</div>
    <div class="model-info">
      ${quote.model_image_url ? `<img src="${quote.model_image_url}" />` : ''}
      <div>
        <p style="font-weight:600;font-size:16px;">${quote.model_label}</p>
        ${quote.registration ? `<p>Matrícula: ${quote.registration}</p>` : ''}
        ${quote.estimated_duration ? `<p>Prazo estimado: ${quote.estimated_duration}</p>` : ''}
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Serviços</div>
    <table>
      <thead>
        <tr>
          <th>Descrição</th>
          <th class="center">Qtd</th>
          <th class="center">Horas</th>
          <th class="right">Preço unit.</th>
          <th class="right">Subtotal</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>

    <div class="totals">
      <div class="totals-row"><span>Subtotal</span><span>${formatEUR(subtotal)}</span></div>
      ${discountAmount > 0 ? `<div class="totals-row"><span>Desconto</span><span>-${formatEUR(Math.min(discountAmount, subtotal))}</span></div>` : ''}
      ${feeRows}
      ${taxAmount > 0 ? `<div class="totals-row"><span>${quote.tax_label || 'Imposto'}</span><span>${formatEUR(taxAmount)}</span></div>` : ''}
      <div class="totals-final"><span>Total</span><span>${formatEUR(quote.total)}</span></div>
    </div>
  </div>

  ${quote.client_notes ? `<div class="notes"><strong>Observações:</strong><br>${quote.client_notes}</div>` : ''}

  <div class="validity">
    ${validStr ? `Este orçamento é válido até ${validStr}.` : ''}
    ${quote.status === 'aceite' ? '<br><strong style="color:#22c55e;">Orçamento aceite.</strong>' : ''}
  </div>

  <div class="footer">
    ${brand.name || 'Márcio Melo'} — ${brand.tagline_pt || 'Aircraft Detailing Works'}<br>
    Documento gerado em ${dateStr}
  </div>
</div>
<script>window.print();</script>
</body>
</html>`;

  return html;
}

export function downloadQuotePDF(quote: Quote, client: Client | null, brand: { name?: string; logo_url?: string; tagline_pt?: string; tagline_en?: string }): void {
  const html = generateQuotePDF(quote, client, brand);
  const blob = new Blob([html], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const win = window.open(url, '_blank');
  if (win) {
    win.onload = () => {
      setTimeout(() => win.print(), 500);
    };
  }
}
