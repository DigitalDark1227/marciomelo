import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import type { SiteContent, Service, PortfolioItem } from '@/lib/types';
import { fetchSiteContent, fetchServices, fetchPortfolio, fetchSettings } from '@/lib/api';

interface DataContextValue {
  content: SiteContent[];
  services: Service[];
  portfolio: PortfolioItem[];
  settings: Record<string, any>;
  loading: boolean;
  reload: () => void;
  getContent: (section: string, key: string) => SiteContent | undefined;
  getSetting: (key: string) => Record<string, any> | undefined;
}

const DataContext = createContext<DataContextValue | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [content, setContent] = useState<SiteContent[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>([]);
  const [settings, setSettings] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);

  const reload = useCallback(() => {
    const timeout = new Promise<undefined>((resolve) => setTimeout(() => resolve(undefined), 4000));
    Promise.race([
      Promise.all([fetchSiteContent(), fetchServices(), fetchPortfolio(), fetchSettings()]),
      timeout,
    ])
      .then((result) => {
        if (Array.isArray(result)) {
          const [c, s, p, set] = result;
          setContent(c);
          setServices(s);
          setPortfolio(p);
          setSettings(set);
        }
      })
      .catch((err) => console.error('Data load error:', err))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  const getContent = (section: string, key: string) =>
    content.find((c) => c.section === section && c.key === key && c.is_visible);

  const getSetting = (key: string) => settings[key];

  return (
    <DataContext.Provider value={{ content, services, portfolio, settings, loading, reload, getContent, getSetting }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within DataProvider');
  return ctx;
}
