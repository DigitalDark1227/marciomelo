import { supabase } from '@/lib/supabase';
import type {
  Client,
  AircraftModel,
  QuoteServiceItem,
  QuotePackage,
  Quote,
  QuoteHistoryEntry,
  LineItem,
  ExtraFee,
} from '@/lib/quoteTypes';

// === Clients ===
export async function fetchClients(): Promise<Client[]> {
  const { data, error } = await supabase.from('clients').select('*').order('name', { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export async function upsertClient(client: Partial<Client>): Promise<Client> {
  const now = new Date().toISOString();
  if (client.id) {
    const { data, error } = await supabase
      .from('clients')
      .update({ ...client, updated_at: now })
      .eq('id', client.id)
      .select()
      .single();
    if (error) throw error;
    return data;
  }
  const { data, error } = await supabase
    .from('clients')
    .insert({ ...client, updated_at: now })
    .select()
    .single();
  if (error) throw error;
  return data;
}

// === Aircraft Models ===
export async function fetchAircraftModels(): Promise<AircraftModel[]> {
  const { data, error } = await supabase.from('aircraft_models').select('*').order('display_order', { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export async function upsertAircraftModel(model: Partial<AircraftModel>): Promise<AircraftModel> {
  const now = new Date().toISOString();
  if (model.id) {
    const { data, error } = await supabase.from('aircraft_models').update({ ...model, updated_at: now }).eq('id', model.id).select().single();
    if (error) throw error;
    return data;
  }
  const { data, error } = await supabase.from('aircraft_models').insert({ ...model, updated_at: now }).select().single();
  if (error) throw error;
  return data;
}

export async function deleteAircraftModel(id: string): Promise<void> {
  const { error } = await supabase.from('aircraft_models').delete().eq('id', id);
  if (error) throw error;
}

// === Quote Services ===
export async function fetchQuoteServices(category?: string): Promise<QuoteServiceItem[]> {
  let q = supabase.from('quote_services').select('*').order('display_order', { ascending: true });
  if (category) q = q.eq('category', category);
  const { data, error } = await q;
  if (error) throw error;
  return data ?? [];
}

export async function upsertQuoteService(service: Partial<QuoteServiceItem>): Promise<QuoteServiceItem> {
  const now = new Date().toISOString();
  if (service.id) {
    const { data, error } = await supabase.from('quote_services').update({ ...service, updated_at: now }).eq('id', service.id).select().single();
    if (error) throw error;
    return data;
  }
  const { data, error } = await supabase.from('quote_services').insert({ ...service, updated_at: now }).select().single();
  if (error) throw error;
  return data;
}

export async function deleteQuoteService(id: string): Promise<void> {
  const { error } = await supabase.from('quote_services').delete().eq('id', id);
  if (error) throw error;
}

// === Quote Packages ===
export async function fetchQuotePackages(category?: string): Promise<QuotePackage[]> {
  let q = supabase.from('quote_packages').select('*').order('display_order', { ascending: true });
  if (category) q = q.eq('category', category);
  const { data, error } = await q;
  if (error) throw error;
  return data ?? [];
}

export async function upsertQuotePackage(pkg: Partial<QuotePackage>): Promise<QuotePackage> {
  const now = new Date().toISOString();
  if (pkg.id) {
    const { data, error } = await supabase.from('quote_packages').update({ ...pkg, updated_at: now }).eq('id', pkg.id).select().single();
    if (error) throw error;
    return data;
  }
  const { data, error } = await supabase.from('quote_packages').insert({ ...pkg, updated_at: now }).select().single();
  if (error) throw error;
  return data;
}

export async function deleteQuotePackage(id: string): Promise<void> {
  const { error } = await supabase.from('quote_packages').delete().eq('id', id);
  if (error) throw error;
}

// === Quotes ===
export async function fetchQuotes(): Promise<Quote[]> {
  const { data, error } = await supabase.from('quotes').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function fetchQuote(id: string): Promise<Quote | null> {
  const { data, error } = await supabase.from('quotes').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data;
}

export async function fetchAllQuoteNumbers(): Promise<string[]> {
  const { data, error } = await supabase.from('quotes').select('quote_number');
  if (error) throw error;
  return (data ?? []).map((r: { quote_number: string }) => r.quote_number).filter(Boolean);
}

export async function createQuote(quote: Partial<Quote>): Promise<Quote> {
  const { data, error } = await supabase.from('quotes').insert(quote).select().single();
  if (error) throw error;

  await supabase.from('quote_history').insert({
    quote_id: data.id,
    action: 'created',
    to_status: data.status,
    notes: '',
  });

  return data;
}

export async function updateQuote(id: string, updates: Partial<Quote>): Promise<Quote> {
  const { data, error } = await supabase.from('quotes').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function updateQuoteStatus(id: string, fromStatus: string, toStatus: string, notes?: string): Promise<void> {
  await supabase.from('quotes').update({ status: toStatus, updated_at: new Date().toISOString() }).eq('id', id);
  await supabase.from('quote_history').insert({
    quote_id: id,
    action: 'status_changed',
    from_status: fromStatus,
    to_status: toStatus,
    notes: notes || '',
  });
}

export async function duplicateQuote(id: string, newNumber: string): Promise<Quote | null> {
  const original = await fetchQuote(id);
  if (!original) return null;
  const { id: _id, quote_number: _qn, created_at: _ca, updated_at: _ua, ...rest } = original;
  const { data, error } = await supabase
    .from('quotes')
    .insert({ ...rest, quote_number: newNumber, status: 'rascunho' })
    .select()
    .single();
  if (error) throw error;

  await supabase.from('quote_history').insert({
    quote_id: data.id,
    action: 'duplicated',
    from_status: original.status,
    to_status: 'rascunho',
    notes: `Duplicado de ${original.quote_number}`,
  });

  return data;
}

export async function deleteQuote(id: string): Promise<void> {
  const { error } = await supabase.from('quotes').delete().eq('id', id);
  if (error) throw error;
}

// === Quote History ===
export async function fetchQuoteHistory(quoteId: string): Promise<QuoteHistoryEntry[]> {
  const { data, error } = await supabase.from('quote_history').select('*').eq('quote_id', quoteId).order('created_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function addQuoteHistory(quoteId: string, action: string, notes: string): Promise<void> {
  await supabase.from('quote_history').insert({ quote_id: quoteId, action, notes });
}

export type { LineItem, ExtraFee };
