import type { PricingRule, LineItem } from '@/lib/quoteTypes';

export const IVA_RATE = 23;
export const IVA_LABEL = 'IVA 23%';

export function calculateLineItem(
  rule: PricingRule,
  price: number,
  hourlyRate: number,
  hours: number,
  estimatedHours: number,
  quantity: number
): { unitPrice: number; subtotal: number; pending: boolean } {
  switch (rule) {
    case 'fixed':
      if (price <= 0) return { unitPrice: 0, subtotal: 0, pending: true };
      return { unitPrice: price, subtotal: price * quantity, pending: false };

    case 'hourly':
      if (hourlyRate <= 0) return { unitPrice: 0, subtotal: 0, pending: true };
      return { unitPrice: hourlyRate, subtotal: hourlyRate * hours * quantity, pending: false };

    case 'estimated_hours':
      if (hourlyRate <= 0) return { unitPrice: 0, subtotal: 0, pending: true };
      return { unitPrice: hourlyRate, subtotal: hourlyRate * estimatedHours * quantity, pending: false };

    case 'dimension':
      if (price <= 0) return { unitPrice: 0, subtotal: 0, pending: true };
      return { unitPrice: price, subtotal: price * quantity, pending: false };

    case 'custom':
      if (price <= 0) return { unitPrice: 0, subtotal: 0, pending: true };
      return { unitPrice: price, subtotal: price * quantity, pending: false };

    default:
      return { unitPrice: 0, subtotal: 0, pending: true };
  }
}

export function calculateQuoteTotal(items: LineItem[], discount: number, discountPercent: number, extraFees: { label: string; amount: number }[], taxRate: number): {
  subtotal: number;
  discountAmount: number;
  afterDiscount: number;
  feesTotal: number;
  taxAmount: number;
  total: number;
  hasPending: boolean;
} {
  const subtotal = items.reduce((sum, item) => sum + item.subtotal, 0);
  const percentAmount = subtotal * (discountPercent / 100);
  const discountAmount = Math.min(discount + percentAmount, subtotal);
  const afterDiscount = subtotal - discountAmount;
  const feesTotal = extraFees.reduce((sum, f) => sum + f.amount, 0);
  const beforeTax = afterDiscount + feesTotal;
  const taxAmount = beforeTax * (taxRate / 100);
  const total = beforeTax + taxAmount;
  const hasPending = items.some((i) => i.unit_price <= 0 && !i.is_custom);

  return {
    subtotal,
    discountAmount,
    afterDiscount,
    feesTotal,
    taxAmount,
    total,
    hasPending,
  };
}

export function formatEUR(value: number): string {
  return new Intl.NumberFormat('pt-PT', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

export function generateQuoteNumber(existing: string[]): string {
  const year = new Date().getFullYear();
  const prefix = `ORC-${year}-`;
  const nums = existing
    .filter((n) => n.startsWith(prefix))
    .map((n) => parseInt(n.slice(prefix.length), 10))
    .filter((n) => !isNaN(n));
  const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
  return `${prefix}${String(next).padStart(3, '0')}`;
}
