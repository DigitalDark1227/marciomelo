import { useEffect } from 'react';
import { useData } from '@/lib/data';

interface AppearanceSettings {
  primary_color?: string;
  accent_color?: string;
  bg_color?: string;
  text_color?: string;
  card_style?: string;
  button_style?: string;
  card_radius?: number;
}

const DEFAULTS: Required<AppearanceSettings> = {
  primary_color: '#0a1929',
  accent_color: '#f4d000',
  bg_color: '#0f1f35',
  text_color: '#e8eef5',
  card_style: 'rounded',
  button_style: 'solid',
  card_radius: 12,
};

export function useTheme() {
  const { getSetting } = useData();
  const appearance = getSetting('appearance') as AppearanceSettings | undefined;

  useEffect(() => {
    const cfg = { ...DEFAULTS, ...appearance };
    const root = document.documentElement;

    root.style.setProperty('--color-primary', cfg.primary_color);
    root.style.setProperty('--color-accent', cfg.accent_color);
    root.style.setProperty('--color-bg', cfg.bg_color);
    root.style.setProperty('--color-text', cfg.text_color);
    root.style.setProperty('--card-radius', `${cfg.card_radius}px`);

    root.dataset.cardStyle = cfg.card_style;
    root.dataset.buttonStyle = cfg.button_style;
  }, [appearance]);

  return { appearance };
}
