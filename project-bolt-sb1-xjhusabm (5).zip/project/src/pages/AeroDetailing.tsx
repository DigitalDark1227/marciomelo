import { Link } from 'react-router-dom';
import { Plane, Check, ArrowRight } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import { Reveal, StaggerGroup, staggerItem, FadeIn, Magnetic, Parallax } from '@/components/motion/Anim';
import { useSEO } from '@/lib/useSEO';
import { localizeField, localizeValue } from '@/lib/localize';

export default function AeroDetailing() {
  const { lang, t } = useI18n();
  const { getContent, services, getSetting } = useData();
  useSEO('services');
  const accent = (getSetting('appearance') || {}).accent_color || '#f4d000';

  const main = getContent('aero', 'main');
  const mainData = localizeValue(main, lang);
  const aeroServices = services.filter((s) => s.category === 'aero');

  return (
    <div className="min-h-screen bg-theme-primary">
      {/* Cinematic hero */}
      <section className="relative h-[50vh] min-h-[360px] overflow-hidden grain">
        <Parallax speed={0.3}>
          <img
            src="https://images.pexels.com/photos/2245276/pexels-photo-2245276.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt=""
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </Parallax>
        <div className="absolute inset-0 cine-overlay-left" />
        <div className="absolute inset-0 cine-overlay" />

        <div className="absolute top-1/3 right-[15%] opacity-20">
          <Plane size={80} style={{ color: accent }} />
        </div>

        <div className="relative z-10 h-full flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 w-full">
            <div className="max-w-2xl">
              <FadeIn delay={0.2}>
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: `${accent}15`, border: `1px solid ${accent}30` }}
                  >
                    <Plane size={20} style={{ color: accent }} />
                  </div>
                  <span className="text-xs sm:text-sm uppercase tracking-[0.25em] text-gold-400">
                    {mainData.subtitle}
                  </span>
                </div>
              </FadeIn>
              <FadeIn delay={0.35} duration={1}>
                <h1 className="font-display text-display font-light text-white mb-5 text-balance">
                  {mainData.title}
                </h1>
              </FadeIn>
              <FadeIn delay={0.55} y={20}>
                <p className="text-base sm:text-lg text-navy-200 leading-relaxed max-w-xl font-light">
                  {mainData.content}
                </p>
              </FadeIn>
            </div>
          </div>
        </div>
      </section>

      {/* Services grid */}
      <section className="cinematic-section py-16 sm:py-22 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          <Reveal>
            <div className="mb-10">
              <span className="text-xs uppercase tracking-[0.3em] text-gold-400 block mb-2">
                {t('services.our_services')}
              </span>
              <div className="divider-gold w-24" />
            </div>
          </Reveal>

          <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
            {aeroServices.map((s) => (
              <div key={s.id}>
                <div className="group rounded-2xl overflow-hidden glass card-glow transition-transform duration-500 hover:-translate-y-2 h-full">
                  <div className="aspect-[16/10] overflow-hidden relative">
                    <img
                      src={s.image_url}
                      alt={localizeField(s, 'title', lang)}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-950/60 to-transparent" />
                  </div>
                  <div className="p-6">
                    <h3 className="font-display text-xl font-medium text-white mb-3">
                      {localizeField(s, 'title', lang)}
                    </h3>
                    <p className="text-sm text-navy-300 mb-5 leading-relaxed">
                      {localizeField(s, 'description', lang)}
                    </p>
                    <div className="space-y-2.5">
                      {(localizeField(s, 'benefits', lang) || []).map((b: string, i: number) => (
                        <div key={i} className="flex items-start gap-3">
                          <span
                            className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5"
                            style={{ background: `${accent}15`, border: `1px solid ${accent}30` }}
                          >
                            <Check size={12} style={{ color: accent }} />
                          </span>
                          <span className="text-sm text-navy-200">{b}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </StaggerGroup>

          <Reveal delay={0.2}>
            <div className="text-center mt-12">
              <Magnetic strength={0.2}>
                <Link
                  to="/contactos"
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-full font-semibold text-navy-950 text-base btn-shine transition-transform"
                  style={{
                    background: `linear-gradient(135deg, ${accent}, ${accent}cc)`,
                    boxShadow: `0 8px 30px ${accent}40`,
                  }}
                >
                  {t('nav.quote')}
                  <ArrowRight size={18} />
                </Link>
              </Magnetic>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
