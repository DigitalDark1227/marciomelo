import { useState } from 'react';
import { X, Plane } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import type { PortfolioItem, PortfolioImage } from '@/lib/types';
import { Reveal, StaggerGroup, staggerItem, FadeIn } from '@/components/motion/Anim';
import { useSEO } from '@/lib/useSEO';
import { localizeField } from '@/lib/localize';

export default function Portfolio() {
  const { lang, t } = useI18n();
  const { portfolio, getSetting } = useData();
  useSEO('services');
  const accent = (getSetting('appearance') || {}).accent_color || '#f4d000';
  const [filter, setFilter] = useState<'all' | 'aero'>('all');
  const [lightbox, setLightbox] = useState<{ item: PortfolioItem; image: PortfolioImage; index: number } | null>(null);

  const filtered = filter === 'all' ? portfolio : portfolio.filter((p) => p.category === filter);

  return (
    <div className="min-h-screen bg-theme-primary">
      {/* Header */}
      <section className="relative h-[35vh] min-h-[260px] overflow-hidden grain flex items-end">
        <div className="absolute inset-0 spotlight-gold" />
        <div className="absolute inset-0 bg-gradient-to-b from-navy-900/50 to-navy-950" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 pb-10 w-full">
          <FadeIn delay={0.15}>
            <span className="text-xs uppercase tracking-[0.3em] text-gold-400 block mb-3">
              {t('portfolio.gallery')}
            </span>
          </FadeIn>
          <FadeIn delay={0.3}>
            <h1 className="font-display text-display font-light text-white mb-2 text-balance">
              {t('portfolio.title')}
            </h1>
          </FadeIn>
          <FadeIn delay={0.45}>
            <p className="text-base text-navy-200 font-light">{t('portfolio.subtitle')}</p>
          </FadeIn>
        </div>
      </section>

      {/* Filter + Grid */}
      <section className="cinematic-section py-12 sm:py-16 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          {/* Filter pills */}
          <Reveal>
            <div className="flex items-center justify-center gap-3 mb-10">
              {(['all', 'aero'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className="relative px-5 py-2.5 rounded-full text-sm font-medium transition-colors duration-300"
                  style={
                    filter === f
                      ? { color: '#040d23', background: accent }
                      : { color: '#aabce0' }
                  }
                >
                  {filter === f ? (
                    <span className="absolute inset-0 rounded-full" style={{ background: accent, boxShadow: `0 4px 15px ${accent}40` }} />
                  ) : (
                    <span className="absolute inset-0 rounded-full glass" />
                  )}
                  <span className="relative z-10 flex items-center gap-1.5">
                    {f === 'aero' && <Plane size={14} />}
                    {f === 'all' ? t('portfolio.all') : 'Aero'}
                  </span>
                </button>
              ))}
            </div>
          </Reveal>

          {filtered.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-navy-300 text-lg">{t('portfolio.empty')}</p>
            </div>
          ) : (
            <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
              {filtered.map((item) => {
                const img = item.images?.[0];
                return (
                  <div key={item.id}>
                    <div
                      className="group relative rounded-2xl overflow-hidden glass card-glow cursor-pointer transition-transform duration-500 hover:-translate-y-2"
                      onClick={() => img && setLightbox({ item, image: img, index: 0 })}
                    >
                      <div className="aspect-[4/3] overflow-hidden relative">
                        <img
                          src={img?.url}
                          alt={localizeField(img, 'alt', lang)}
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                          loading="lazy"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                      </div>
                      <div className="absolute top-3 right-3">
                        <div className="w-9 h-9 rounded-full glass-strong flex items-center justify-center">
                          <Plane size={15} style={{ color: accent }} />
                        </div>
                      </div>
                      <div className="absolute bottom-0 left-0 right-0 p-5 translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
                        <span className="text-[10px] uppercase tracking-wider text-gold-400 block mb-1">
                          {item.category}
                        </span>
                        <h3 className="text-base font-semibold text-white mb-1">
                          {localizeField(item, 'title', lang)}
                        </h3>
                        <p className="text-xs text-navy-300 line-clamp-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                          {localizeField(item, 'description', lang)}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </StaggerGroup>
          )}
        </div>
      </section>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-[100] bg-theme-primary-95 backdrop-blur-xl flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-5 right-5 p-3 rounded-full glass text-white hover:text-gold-400 transition-colors z-10"
            onClick={() => setLightbox(null)}
          >
            <X size={22} />
          </button>

          <div
            className="max-w-4xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={lightbox.image.url}
              alt={localizeField(lightbox.image, 'alt', lang)}
              className="w-full max-h-[70vh] object-contain rounded-2xl"
            />
            <div className="mt-5 text-center">
              <span className="text-xs uppercase tracking-wider text-gold-400 block mb-2">
                {lightbox.item.category}
              </span>
              <h3 className="font-display text-2xl font-light text-white mb-2">
                {localizeField(lightbox.item, 'title', lang)}
              </h3>
              <p className="text-sm text-navy-300 max-w-lg mx-auto">
                {localizeField(lightbox.item, 'description', lang)}
              </p>
            </div>
            {lightbox.item.images.length > 1 && (
              <div className="flex justify-center gap-2 mt-5">
                {lightbox.item.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setLightbox({ ...lightbox, image: img, index: i })}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      i === lightbox.index ? 'w-6' : 'bg-white/30'
                    }`}
                    style={i === lightbox.index ? { background: accent } : {}}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
