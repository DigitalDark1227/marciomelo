import { Plane, Shield, Award, Sparkles } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import { FadeIn, Reveal, Parallax } from '@/components/motion/Anim';
import { useSEO } from '@/lib/useSEO';
import { localizeValue } from '@/lib/localize';

export default function About() {
  const { lang, t } = useI18n();
  const { getContent, getSetting } = useData();
  useSEO('services');
  const accent = (getSetting('appearance') || {}).accent_color || '#f4d000';

  const main = getContent('about', 'main');
  const data = localizeValue(main, lang);

  return (
    <div className="min-h-screen bg-theme-primary">
      {/* Cinematic hero */}
      <section className="relative h-[50vh] min-h-[360px] overflow-hidden grain">
        <Parallax speed={0.3}>
          <img
            src="https://images.pexels.com/photos/20562278/pexels-photo-20562278.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt=""
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </Parallax>
        <div className="absolute inset-0 cine-overlay-left" />
        <div className="absolute inset-0 cine-overlay" />

        <div className="absolute top-1/4 right-[15%] opacity-15">
          <Plane size={70} style={{ color: accent }} />
        </div>
        <div className="absolute bottom-1/4 right-[25%] opacity-15">
          <Plane size={60} style={{ color: accent }} />
        </div>

        <div className="relative z-10 h-full flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 w-full">
            <div className="max-w-2xl">
              <FadeIn delay={0.2}>
                <span className="text-xs sm:text-sm uppercase tracking-[0.3em] text-gold-400 block mb-4">
                  {data.subtitle}
                </span>
              </FadeIn>
              <FadeIn delay={0.35} duration={1}>
                <h1 className="font-display text-display font-light text-white mb-6 text-balance">
                  {data.title}
                </h1>
              </FadeIn>
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="cinematic-section relative py-16 sm:py-22 px-4 sm:px-6">
        <div className="max-w-3xl mx-auto">
          <Reveal>
            <div className="flex items-center gap-3 mb-8">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center"
                style={{ background: `${accent}15`, border: `1px solid ${accent}30` }}
              >
                <Sparkles size={20} style={{ color: accent }} />
              </div>
              <div className="divider-gold flex-1" />
            </div>
          </Reveal>

          <div className="space-y-6">
            {(data.content || '').split('\n\n').map((para: string, i: number) => (
              <Reveal key={i} delay={i * 0.1}>
                <p className="text-base sm:text-lg text-navy-200 leading-relaxed font-light">
                  {para}
                </p>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.3}>
            <div className="grid grid-cols-3 gap-3 sm:gap-4 mt-12 pt-8 border-t border-white/10">
              {[
                { icon: Shield, label: t('about.quality') },
                { icon: Award, label: t('about.experience') },
                { icon: Sparkles, label: t('about.precision') },
              ].map((item, i) => (
                <div key={i} className="text-center">
                  <div
                    className="w-12 h-12 rounded-xl mx-auto flex items-center justify-center mb-3"
                    style={{ background: `${accent}15`, border: `1px solid ${accent}30` }}
                  >
                    <item.icon size={22} style={{ color: accent }} />
                  </div>
                  <span className="text-xs sm:text-sm text-navy-200">{item.label}</span>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
