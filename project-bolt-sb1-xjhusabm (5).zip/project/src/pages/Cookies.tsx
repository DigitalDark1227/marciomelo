import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import { localizeValue } from '@/lib/localize';
import { FadeIn, Reveal } from '@/components/motion/Anim';

export default function Cookies() {
  const { lang, t } = useI18n();
  const { getContent } = useData();
  const main = getContent('cookies', 'main');
  const data = localizeValue(main, lang);

  return (
    <div className="page-shell min-h-screen pt-14 sm:pt-16 lg:pt-20">
      <section className="relative overflow-hidden border-b border-white/10 px-4 py-16 sm:px-6 sm:py-24">
        <div className="absolute inset-0 spotlight-gold pointer-events-none" />
        <div className="relative mx-auto max-w-5xl">
          <FadeIn>
            <span className="mb-4 block text-xs uppercase tracking-[0.3em] text-gold-400">
              {t('cookies.digital_experience')}
            </span>
          </FadeIn>
          <FadeIn delay={0.12}>
            <h1 className="max-w-3xl font-display text-display font-light text-white text-balance">
              {data.title || 'Política de Cookies'}
            </h1>
          </FadeIn>
          <div className="editorial-rule mt-7" />
        </div>
      </section>
      <section className="px-4 py-14 sm:px-6 sm:py-24">
        <div className="mx-auto max-w-3xl rounded-3xl border border-white/10 bg-white/[0.03] p-6 shadow-2xl backdrop-blur-xl sm:p-10 lg:p-14">
          <div className="space-y-6">
            {(data.content || '').split('\n\n').map((para: string, i: number) => (
              <Reveal key={i} delay={i * 0.04}>
                <p className="text-sm leading-8 text-navy-200 sm:text-base">{para}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
