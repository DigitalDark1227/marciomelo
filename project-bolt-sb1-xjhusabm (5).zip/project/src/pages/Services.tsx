import { Link } from 'react-router-dom';
import { Plane, ArrowRight, Check } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import type { Service } from '@/lib/types';
import { Reveal, StaggerGroup, staggerItem, FadeIn, Magnetic, Parallax } from '@/components/motion/Anim';
import { useSEO } from '@/lib/useSEO';
import { localizeField } from '@/lib/localize';

export default function Services() {
  const { lang, t } = useI18n();
  const { services, getSetting } = useData();
  useSEO('services');
  const accent = (getSetting('appearance') || {}).accent_color || '#1677ff';
  const aeroServices = services.filter((s) => s.category === 'aero');

  return (
    <div className="min-h-screen bg-theme-primary">
      <section className="relative h-[40vh] min-h-[280px] overflow-hidden grain">
        <Parallax speed={0.3}>
          <img src="https://images.pexels.com/photos/2245276/pexels-photo-2245276.jpeg?auto=compress&cs=tinysrgb&w=1920" alt="Aircraft detailing" className="w-full h-full object-cover" loading="lazy" />
        </Parallax>
        <div className="absolute inset-0 cine-overlay" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center px-4">
            <FadeIn delay={0.15}><Plane size={28} style={{ color: accent }} className="mx-auto mb-4" /></FadeIn>
            <FadeIn delay={0.3}><h1 className="font-display text-display font-light text-white mb-3 text-balance">{t('services.title')}</h1></FadeIn>
            <FadeIn delay={0.45}><p className="text-base text-navy-200 max-w-xl mx-auto font-light">{t('services.subtitle')}</p></FadeIn>
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-22 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          <Reveal>
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${accent}15`, border: `1px solid ${accent}30` }}><Plane size={20} style={{ color: accent }} /></div>
              <div><span className="text-xs uppercase tracking-[0.2em] text-gold-400 block">{t('services.aircraft_care')}</span><h2 className="font-display text-2xl sm:text-3xl font-light text-white">{t('nav.aero')}</h2></div>
            </div>
          </Reveal>
          <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
            {aeroServices.map((s: Service) => (
              <div key={s.id}>
                <div className="group rounded-2xl overflow-hidden glass card-glow transition-transform duration-500 hover:-translate-y-2">
                  <div className="aspect-[16/10] overflow-hidden relative"><img src={s.image_url} alt={localizeField(s, 'title', lang)} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" /><div className="absolute inset-0 bg-gradient-to-t from-navy-950/60 to-transparent" /></div>
                  <div className="p-6 sm:p-8">
                    <h3 className="font-display text-xl sm:text-2xl font-medium text-white mb-3">{localizeField(s, 'title', lang)}</h3>
                    <p className="text-sm text-navy-300 mb-5 leading-relaxed">{localizeField(s, 'description', lang)}</p>
                    <div className="space-y-2.5 mb-6">{(localizeField(s, 'benefits', lang) || []).map((b: string, i: number) => <div key={i} className="flex items-start gap-3"><span className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5" style={{ background: `${accent}15`, border: `1px solid ${accent}30` }}><Check size={12} style={{ color: accent }} /></span><span className="text-sm text-navy-200">{b}</span></div>)}</div>
                    <Link to="/contactos" className="inline-flex items-center gap-2 text-sm font-medium text-gold-400 hover:gap-3 transition-all">{t('nav.quote')}<ArrowRight size={14} /></Link>
                  </div>
                </div>
              </div>
            ))}
          </StaggerGroup>
        </div>
      </section>

      <section className="cinematic-section relative py-16 sm:py-20 px-4 sm:px-6 bg-theme-bg overflow-hidden"><div className="absolute inset-0 spotlight-gold pointer-events-none" /><div className="relative text-center"><Reveal><p className="text-sm text-navy-200 mb-6">{t('services.ready')}</p><Magnetic strength={0.2}><Link to="/contactos" className="inline-flex items-center gap-2 px-8 py-4 rounded-full font-semibold text-navy-950 text-base btn-shine transition-transform" style={{ background: `linear-gradient(135deg, ${accent}, ${accent}cc)`, boxShadow: `0 8px 30px ${accent}40` }}>{t('nav.quote')}<ArrowRight size={18} /></Link></Magnetic></Reveal></div></section>
    </div>
  );
}
