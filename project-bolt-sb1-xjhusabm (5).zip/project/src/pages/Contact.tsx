import { Mail, Phone, MapPin, Clock, MessageCircle, Plane } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import QuoteForm from '@/components/QuoteForm';
import { Reveal, FadeIn } from '@/components/motion/Anim';
import { useSEO } from '@/lib/useSEO';
import { localizeField } from '@/lib/localize';

export default function Contact() {
  const { lang, t } = useI18n();
  const { getSetting } = useData();
  useSEO('services');
  const contact = getSetting('contact') || {};
  const accent = (getSetting('appearance') || {}).accent_color || '#f4d000';

  const whatsappNumber = (contact.whatsapp || '').replace(/\D/g, '');
  const whatsappMsg = localizeField(contact, 'whatsapp_msg', lang);
  const whatsappUrl = whatsappNumber ? `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMsg)}` : '';

  return (
    <div className="min-h-screen bg-theme-primary">
      {/* Header */}
      <section className="relative h-[30vh] min-h-[220px] overflow-hidden grain flex items-end">
        <div className="absolute inset-0 spotlight-gold" />
        <div className="absolute inset-0 bg-gradient-to-b from-navy-900/30 to-navy-950" />

        <div className="absolute top-1/3 left-[10%] opacity-10">
          <Plane size={50} style={{ color: accent }} />
        </div>
        <div className="absolute top-1/4 right-[10%] opacity-10">
          <Plane size={50} style={{ color: accent }} />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 pb-10 w-full">
          <FadeIn delay={0.15}>
            <span className="text-xs uppercase tracking-[0.3em] text-gold-400 block mb-3">
              {t('contact.get_in_touch')}
            </span>
          </FadeIn>
          <FadeIn delay={0.3}>
            <h1 className="font-display text-display font-light text-white mb-2 text-balance">
              {t('contact.title')}
            </h1>
          </FadeIn>
          <FadeIn delay={0.45}>
            <p className="text-base text-navy-200 font-light max-w-xl">
              {t('contact.available')}
            </p>
          </FadeIn>
        </div>
      </section>

      {/* Content */}
      <section className="cinematic-section py-16 sm:py-22 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 lg:gap-10">
            {/* Contact info — 2 cols */}
            <div className="lg:col-span-2 space-y-5">
              <Reveal>
                <div className="glass rounded-2xl p-6 sm:p-8 card-glow">
                  <h2 className="font-display text-xl font-medium text-white mb-6">
                    {t('contact.info')}
                  </h2>
                  <div className="space-y-4">
                    {contact.phone && (
                      <a
                        href={`tel:${contact.phone}`}
                        className="flex items-center gap-3.5 text-sm text-navy-200 hover:text-white transition-colors group"
                      >
                        <span
                          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-110"
                          style={{ background: `${accent}15`, border: `1px solid ${accent}30` }}
                        >
                          <Phone size={16} style={{ color: accent }} />
                        </span>
                        <span>{contact.phone}</span>
                      </a>
                    )}
                    {contact.email && (
                      <a
                        href={`mailto:${contact.email}`}
                        className="flex items-center gap-3.5 text-sm text-navy-200 hover:text-white transition-colors group"
                      >
                        <span
                          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-110"
                          style={{ background: `${accent}15`, border: `1px solid ${accent}30` }}
                        >
                          <Mail size={16} style={{ color: accent }} />
                        </span>
                        <span className="break-all">{contact.email}</span>
                      </a>
                    )}
                    {contact.location_pt && (
                      <div className="flex items-center gap-3.5 text-sm text-navy-200">
                        <span
                          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                          style={{ background: `${accent}15`, border: `1px solid ${accent}30` }}
                        >
                          <MapPin size={16} style={{ color: accent }} />
                        </span>
                        <span>{localizeField(contact, 'location', lang)}</span>
                      </div>
                    )}
                    {contact.hours_pt && (
                      <div className="flex items-center gap-3.5 text-sm text-navy-200">
                        <span
                          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                          style={{ background: `${accent}15`, border: `1px solid ${accent}30` }}
                        >
                          <Clock size={16} style={{ color: accent }} />
                        </span>
                        <span>{localizeField(contact, 'hours', lang)}</span>
                      </div>
                    )}
                  </div>
                </div>
              </Reveal>

              <Reveal delay={0.1}>
                <div className="glass rounded-2xl p-6 sm:p-8 card-glow">
                  <h2 className="font-display text-xl font-medium text-white mb-3">
                    {t('contact.area_label')}
                  </h2>
                  <p className="text-sm text-navy-300 leading-relaxed">
                    {localizeField(contact, 'area', lang)}
                  </p>
                </div>
              </Reveal>

              {whatsappUrl && (
                <Reveal delay={0.2}>
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2.5 px-6 py-4 rounded-2xl bg-[#25D366] text-white font-semibold text-sm transition-all hover:scale-[1.02] btn-shine"
                  >
                    <MessageCircle size={20} />
                    {t('contact.whatsapp')}
                  </a>
                </Reveal>
              )}

              <Reveal delay={0.3}>
                <div className="grid grid-cols-2 gap-3 sm:gap-4">
                  <div className="glass rounded-xl p-5 flex flex-col items-center text-center card-glow">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center mb-2"
                      style={{ background: `${accent}15` }}
                    >
                      <Plane size={20} style={{ color: accent }} />
                    </div>
                    <span className="text-xs text-navy-200">Aero Detailing</span>
                  </div>
                  <div className="glass rounded-xl p-5 flex flex-col items-center text-center card-glow">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center mb-2"
                      style={{ background: `${accent}15` }}
                    >
                      <Plane size={20} style={{ color: accent }} />
                    </div>
                    <span className="text-xs text-navy-200">Aircraft Detailing</span>
                  </div>
                </div>
              </Reveal>
            </div>

            {/* Quote form — 3 cols */}
            <div className="lg:col-span-3">
              <Reveal direction="left">
                <div className="glass rounded-2xl p-6 sm:p-8 card-glow relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 spotlight-gold pointer-events-none" />
                  <div className="relative">
                    <h2 className="font-display text-2xl font-medium text-white mb-6">
                      {t('quote.title')}
                    </h2>
                    <QuoteForm />
                  </div>
                </div>
              </Reveal>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
