import { Link } from 'react-router-dom';
import { ArrowRight, Shield, Sparkles, Award, Clock, Plane, ChevronDown } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { useData } from '@/lib/data';
import type { SiteContent, Service, PortfolioItem } from '@/lib/types';
import { Reveal, StaggerGroup, staggerItem, FadeIn, Parallax, Magnetic } from '@/components/motion/Anim';
import { useSEO } from '@/lib/useSEO';
import { localizeField, localizeValue } from '@/lib/localize';

const iconMap: Record<string, any> = { shield: Shield, sparkles: Sparkles, award: Award, clock: Clock };

export default function Home() {
  const { lang, t } = useI18n();
  const { getContent, services, portfolio, getSetting } = useData();
  useSEO('home');
  const accent = (getSetting('appearance') || {}).accent_color || '#f4d000';

  const hero = getContent('homepage', 'hero');
  const heroData = localizeValue(hero, lang);
  const aeroCard = getContent('homepage', 'aero_card');
  const aeroData = localizeValue(aeroCard, lang);
  const diffs = getContent('homepage', 'differentials');
  const diffsData = diffs ? localizeValue(diffs, lang) : { items: [] };
  const portfolioPreview = getContent('homepage', 'portfolio_preview');
  const ppData = localizeValue(portfolioPreview, lang);
  const cta = getContent('homepage', 'cta');
  const ctaData = localizeValue(cta, lang);
  const aboutSummary = getContent('homepage', 'about_summary');
  const aboutData = localizeValue(aboutSummary, lang);

  const aeroServices = services.filter((s) => s.category === 'aero').slice(0, 3);
  const featuredPortfolio = portfolio.slice(0, 4);

  return (
    <div>
      {/* ===== CINEMATIC HERO ===== */}
      <section className="relative h-screen min-h-[600px] overflow-hidden grain">
        <div className="absolute inset-0">
          <img
            src={heroData.image_url || 'https://images.pexels.com/photos/20425755/pexels-photo-20425755.jpeg?auto=compress&cs=tinysrgb&w=1920'}
            alt="Márcio Melo Aircraft Detailing Works"
            className="w-full h-full object-cover"
            fetchPriority="high"
          />
        </div>

        <div className="absolute inset-0 cine-overlay-left" />
        <div className="absolute inset-0 cine-overlay" />

        <div className="relative z-10 h-full flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 w-full">
            <div className="max-w-2xl">
              <FadeIn delay={0.2}>
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass mb-5">
                  <Plane size={14} style={{ color: accent }} />
                  <div className="w-px h-3 bg-white/20" />
                  <span className="text-xs font-medium tracking-[0.15em] text-white/90 uppercase">
                    {heroData.subtitle || 'Aircraft Detailing Works'}
                  </span>
                </div>
              </FadeIn>

              <FadeIn delay={0.35} duration={1}>
                <h1 className="font-display text-hero font-light text-white mb-4 text-balance">
                  {heroData.title || 'Márcio Melo'}
                </h1>
              </FadeIn>

              <FadeIn delay={0.55} y={20}>
                <p className="text-base sm:text-lg text-navy-100/80 leading-relaxed mb-8 max-w-xl font-light">
                  {heroData.description}
                </p>
              </FadeIn>

              <FadeIn delay={0.7} y={20}>
                <div className="flex flex-wrap gap-4">
                  <Magnetic strength={0.2}>
                    <Link
                      to="/contactos"
                      className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full font-semibold text-navy-950 text-sm sm:text-base btn-shine transition-transform"
                      style={{
                        background: `linear-gradient(135deg, ${accent}, ${accent}cc)`,
                        boxShadow: `0 8px 30px ${accent}40`,
                      }}
                    >
                      {heroData.primary_btn || t('nav.quote')}
                      <ArrowRight size={18} />
                    </Link>
                  </Magnetic>
                  <Link
                    to="/servicos"
                    className="inline-flex items-center px-7 py-3.5 rounded-full font-semibold text-white/90 glass text-sm sm:text-base hover:bg-white/10 transition-all duration-300 hover:border-white/30"
                  >
                    {heroData.secondary_btn || t('nav.services')}
                  </Link>
                </div>
              </FadeIn>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2">
          <span className="text-[10px] uppercase tracking-[0.3em] text-white/40">
            {t('home.explore')}
          </span>
          <ChevronDown size={20} className="text-white/50" />
        </div>
      </section>

      {/* ===== AIRCRAFT DETAILING FEATURE ===== */}
      <section className="cinematic-section relative py-16 sm:py-22 px-4 sm:px-6 bg-theme-primary">
        <div className="max-w-7xl mx-auto">
          <Reveal direction="left">
            <Link
              to="/aero-detailing"
              className="group relative block overflow-hidden rounded-2xl sm:rounded-3xl aspect-[4/3] sm:aspect-[21/9] card-glow"
            >
              <Parallax speed={0.1}>
                <img
                  src={aeroData.image_url}
                  alt={aeroData.title || 'Aircraft detailing'}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />
              </Parallax>
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/50 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-r from-navy-950/70 to-transparent" />
              <div className="absolute top-6 right-6 w-14 h-14 rounded-full glass-strong flex items-center justify-center">
                <Plane size={24} style={{ color: accent }} />
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-10">
                <span className="text-xs uppercase tracking-[0.2em] text-gold-400 mb-2 block">Aircraft Detailing</span>
                <h3 className="font-display text-2xl sm:text-4xl font-medium text-white mb-2">{aeroData.title}</h3>
                <p className="text-sm text-navy-200 mb-4 line-clamp-2 max-w-xl">{aeroData.description}</p>
                <span className="inline-flex items-center gap-2 text-sm font-medium text-gold-400 group-hover:gap-3 transition-all duration-300">
                  {t('common.view_more')} <ArrowRight size={16} />
                </span>
              </div>
            </Link>
          </Reveal>
        </div>
      </section>

      {/* ===== DIFFERENTIALS ===== */}
      {diffs?.is_visible && (
        <section className="cinematic-section relative py-16 sm:py-22 px-4 sm:px-6 bg-theme-bg overflow-hidden">
          <div className="absolute inset-0 spotlight-gold pointer-events-none" />

          <div className="relative max-w-7xl mx-auto">
            <Reveal>
              <div className="text-center mb-12">
                <span className="text-xs uppercase tracking-[0.3em] text-gold-400 mb-3 block">
                  {t('home.differentials')}
                </span>
                <h2 className="font-display text-section font-light text-white text-balance">
                  {diffsData.title}
                </h2>
                <div className="divider-gold w-24 mx-auto mt-4" />
              </div>
            </Reveal>

            <StaggerGroup className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {(diffsData.items || []).map((item: any, i: number) => {
                const Icon = iconMap[item.icon] || Shield;
                return (
                  <div key={i}>
                    <div className="group relative h-full p-6 sm:p-8 rounded-2xl glass card-glow transition-transform duration-500 hover:-translate-y-2">
                      <span className="absolute top-4 right-5 font-display text-4xl text-white/5 font-light">
                        0{i + 1}
                      </span>
                      <div
                        className="w-14 h-14 rounded-xl flex items-center justify-center mb-5 transition-transform duration-500 group-hover:scale-110"
                        style={{
                          background: `linear-gradient(135deg, ${accent}20, ${accent}10)`,
                          border: `1px solid ${accent}30`,
                        }}
                      >
                        <Icon size={24} style={{ color: accent }} />
                      </div>
                      <h3 className="text-sm sm:text-base font-semibold text-white mb-2">
                        {localizeField(item, 'title', lang)}
                      </h3>
                      <p className="text-xs sm:text-sm text-navy-300 leading-relaxed">
                        {localizeField(item, 'desc', lang)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </StaggerGroup>
          </div>
        </section>
      )}

      {/* ===== SERVICES PREVIEW ===== */}
      {aeroServices.length > 0 && (
        <section className="cinematic-section relative py-16 sm:py-22 px-4 sm:px-6 bg-theme-primary">
          <div className="max-w-7xl mx-auto">
            <Reveal>
              <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
                <div>
                  <span className="text-xs uppercase tracking-[0.3em] text-gold-400 mb-3 block">
                    {t('home.what_we_do')}
                  </span>
                  <h2 className="font-display text-section font-light text-white">
                    {t('services.title')}
                  </h2>
                </div>
                <Link
                  to="/servicos"
                  className="inline-flex items-center gap-2 text-sm font-medium text-gold-400 hover:gap-3 transition-all"
                >
                  {t('common.view_all')}
                  <ArrowRight size={16} />
                </Link>
              </div>
            </Reveal>

            <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
              {aeroServices.slice(0, 6).map((s: Service) => (
                <div key={s.id}>
                  <Link
                    to="/aero-detailing"
                    className="group block rounded-2xl overflow-hidden glass card-glow transition-transform duration-500 hover:-translate-y-1.5"
                  >
                    <div className="aspect-[16/10] overflow-hidden relative">
                      <img
                        src={s.image_url}
                        alt={localizeField(s, 'title', lang)}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-navy-950/80 to-transparent" />
                      <div className="absolute top-3 left-3">
                        <div className="w-8 h-8 rounded-lg glass-strong flex items-center justify-center">
                          <Plane size={14} style={{ color: accent }} />
                        </div>
                      </div>
                    </div>
                    <div className="p-5">
                      <h3 className="text-base font-semibold text-white mb-2">
                        {localizeField(s, 'title', lang)}
                      </h3>
                      <p className="text-sm text-navy-300 line-clamp-2">
                        {localizeField(s, 'description', lang)}
                      </p>
                    </div>
                  </Link>
                </div>
              ))}
            </StaggerGroup>
          </div>
        </section>
      )}

      {/* ===== PORTFOLIO PREVIEW ===== */}
      {portfolioPreview?.is_visible && featuredPortfolio.length > 0 && (
        <section className="cinematic-section relative py-16 sm:py-22 px-4 sm:px-6 bg-theme-bg overflow-hidden">
          <div className="absolute top-1/2 left-0 w-full spotlight-teal pointer-events-none" />

          <div className="relative max-w-7xl mx-auto">
            <Reveal>
              <div className="text-center mb-10">
                <span className="text-xs uppercase tracking-[0.3em] text-gold-400 mb-3 block">
                  {t('home.work')}
                </span>
                <h2 className="font-display text-section font-light text-white mb-2">
                  {ppData.title}
                </h2>
                <p className="text-sm text-navy-300">{ppData.subtitle}</p>
                <div className="divider-gold w-24 mx-auto mt-4" />
              </div>
            </Reveal>

            <StaggerGroup className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
              {featuredPortfolio.map((p: PortfolioItem) => {
                const img = p.images?.[0];
                return (
                  <div key={p.id}>
                    <Link
                      to="/portfolio"
                      className="group relative block overflow-hidden rounded-xl sm:rounded-2xl aspect-square card-glow"
                    >
                      <img
                        src={img?.url}
                        alt={localizeField(img, 'alt', lang)}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                      <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
                        <div className="flex items-center gap-2 mb-1 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                          <Plane size={12} style={{ color: accent }} />
                          <span className="text-[10px] uppercase tracking-wider text-gold-400">
                            {p.category}
                          </span>
                        </div>
                        <p className="text-sm font-medium text-white opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                          {localizeField(p, 'title', lang)}
                        </p>
                      </div>
                    </Link>
                  </div>
                );
              })}
            </StaggerGroup>

            <Reveal delay={0.2}>
              <div className="text-center mt-10">
                <Link
                  to="/portfolio"
                  className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full font-semibold text-sm glass hover:bg-white/10 hover:border-gold-400/30 text-white transition-all duration-300"
                >
                  {ppData.btn_label}
                  <ArrowRight size={16} />
                </Link>
              </div>
            </Reveal>
          </div>
        </section>
      )}

      {/* ===== ABOUT SUMMARY ===== */}
      {aboutSummary?.is_visible && (
        <section className="cinematic-section relative py-16 sm:py-22 px-4 sm:px-6 bg-theme-primary">
          <div className="max-w-4xl mx-auto text-center">
            <Reveal>
              <span className="text-xs uppercase tracking-[0.3em] text-gold-400 mb-3 block">
                {t('home.our_story')}
              </span>
              <h2 className="font-display text-section font-light text-white mb-5 text-balance">
                {aboutData.title}
              </h2>
              <p className="text-base text-navy-200 leading-relaxed mb-6 font-light max-w-2xl mx-auto">
                {aboutData.description}
              </p>
              <Link
                to="/sobre"
                className="inline-flex items-center gap-2 text-sm font-medium text-gold-400 hover:gap-3 transition-all"
              >
                {aboutData.btn_label}
                <ArrowRight size={16} />
              </Link>
            </Reveal>
          </div>
        </section>
      )}

      {/* ===== CTA ===== */}
      {cta?.is_visible && (
        <section className="cinematic-section relative py-20 sm:py-30 px-4 sm:px-6 bg-theme-bg overflow-hidden">
          <div className="absolute inset-0 spotlight-gold pointer-events-none" />

          <div className="absolute top-10 left-[10%] opacity-10">
            <Plane size={60} style={{ color: accent }} />
          </div>

          <div className="relative max-w-4xl mx-auto text-center">
            <Reveal>
              <h2 className="font-display text-display font-light text-white mb-5 text-balance">
                {ctaData.title}
              </h2>
              <p className="text-base sm:text-lg text-navy-200 mb-10 max-w-2xl mx-auto font-light">
                {ctaData.description}
              </p>
              <Magnetic strength={0.2}>
                <Link
                  to="/contactos"
                  className="inline-flex items-center gap-2 px-9 py-4 rounded-full font-semibold text-navy-950 text-base btn-shine transition-transform"
                  style={{
                    background: `linear-gradient(135deg, ${accent}, ${accent}cc)`,
                    boxShadow: `0 10px 40px ${accent}40`,
                  }}
                >
                  {ctaData.btn_label}
                  <ArrowRight size={20} />
                </Link>
              </Magnetic>
            </Reveal>
          </div>
        </section>
      )}
    </div>
  );
}
