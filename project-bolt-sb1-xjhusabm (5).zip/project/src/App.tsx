import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { I18nProvider } from '@/lib/i18n';
import { AuthProvider } from '@/lib/auth';
import { DataProvider } from '@/lib/data';
import ErrorBoundary from '@/components/ErrorBoundary';
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import Services from '@/pages/Services';
import AeroDetailing from '@/pages/AeroDetailing';
import Portfolio from '@/pages/Portfolio';
import About from '@/pages/About';
import Contact from '@/pages/Contact';
import Privacy from '@/pages/Privacy';
import Cookies from '@/pages/Cookies';
import Admin from '@/pages/Admin';

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <I18nProvider>
          <DataProvider>
            <BrowserRouter>
              <Routes>
                <Route path="/admin" element={<Admin />} />
                <Route path="/" element={<Layout />}>
                  <Route index element={<Home />} />
                  <Route path="servicos" element={<Services />} />
                  <Route path="services" element={<Services />} />
                  <Route path="aero-detailing" element={<AeroDetailing />} />
                  <Route path="portfolio" element={<Portfolio />} />
                  <Route path="sobre" element={<About />} />
                  <Route path="about" element={<About />} />
                  <Route path="contactos" element={<Contact />} />
                  <Route path="contact" element={<Contact />} />
                  <Route path="privacidade" element={<Privacy />} />
                  <Route path="privacy" element={<Privacy />} />
                  <Route path="cookies" element={<Cookies />} />
                </Route>
              </Routes>
            </BrowserRouter>
          </DataProvider>
        </I18nProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
