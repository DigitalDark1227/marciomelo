/*
# Add Spanish and French language support

1. Changes
- Adds `value_es` and `value_fr` JSONB columns to `site_content` (defaults to '{}'::jsonb)
- Adds `title_es`, `description_es`, `benefits_es`, `title_fr`, `description_fr`, `benefits_fr` columns to `services`
- Adds `title_es`, `description_es`, `title_fr`, `description_fr` columns to `portfolio_items`
- Copies existing EN values into ES/FR as defaults where the value is missing, so the site has content in all languages immediately

2. Security
- No RLS or policy changes. Existing policies cover all columns automatically.
- Existing grants (SELECT to anon, CRUD to authenticated) cover the new columns implicitly.

3. Important Notes
- All new columns are nullable / have defaults so existing rows and queries are unaffected.
- The frontend will fall back to EN then PT for any ES/FR field that is empty.
*/

-- site_content: add ES and FR value columns
ALTER TABLE site_content ADD COLUMN IF NOT EXISTS value_es jsonb DEFAULT '{}';
ALTER TABLE site_content ADD COLUMN IF NOT EXISTS value_fr jsonb DEFAULT '{}';

-- services: add ES and FR columns
ALTER TABLE services ADD COLUMN IF NOT EXISTS title_es text DEFAULT '';
ALTER TABLE services ADD COLUMN IF NOT EXISTS description_es text DEFAULT '';
ALTER TABLE services ADD COLUMN IF NOT EXISTS benefits_es jsonb DEFAULT '[]';
ALTER TABLE services ADD COLUMN IF NOT EXISTS title_fr text DEFAULT '';
ALTER TABLE services ADD COLUMN IF NOT EXISTS description_fr text DEFAULT '';
ALTER TABLE services ADD COLUMN IF NOT EXISTS benefits_fr jsonb DEFAULT '[]';

-- portfolio_items: add ES and FR columns
ALTER TABLE portfolio_items ADD COLUMN IF NOT EXISTS title_es text DEFAULT '';
ALTER TABLE portfolio_items ADD COLUMN IF NOT EXISTS description_es text DEFAULT '';
ALTER TABLE portfolio_items ADD COLUMN IF NOT EXISTS title_fr text DEFAULT '';
ALTER TABLE portfolio_items ADD COLUMN IF NOT EXISTS description_fr text DEFAULT '';

-- Backfill ES/FR site_content from EN where empty
UPDATE site_content SET value_es = value_en WHERE value_es = '{}'::jsonb;
UPDATE site_content SET value_fr = value_en WHERE value_fr = '{}'::jsonb;

-- Backfill ES/FR services from EN
UPDATE services SET title_es = title_en WHERE title_es = '';
UPDATE services SET description_es = description_en WHERE description_es = '';
UPDATE services SET benefits_es = benefits_en WHERE benefits_es = '[]'::jsonb;
UPDATE services SET title_fr = title_en WHERE title_fr = '';
UPDATE services SET description_fr = description_en WHERE description_fr = '';
UPDATE services SET benefits_fr = benefits_en WHERE benefits_fr = '[]'::jsonb;

-- Backfill ES/FR portfolio from EN
UPDATE portfolio_items SET title_es = title_en WHERE title_es = '';
UPDATE portfolio_items SET description_es = description_en WHERE description_es = '';
UPDATE portfolio_items SET title_fr = title_en WHERE title_fr = '';
UPDATE portfolio_items SET description_fr = description_en WHERE description_fr = '';
