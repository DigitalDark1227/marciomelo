-- Specific aircraft model photos (brand/model-specific where available)

-- Embraer Phenom 100
UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/33742620/pexels-photo-33742620.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'Embraer' AND model LIKE 'Phenom%' AND (image_url IS NULL OR image_url = '');

-- HondaJet
UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/27552122/pexels-photo-27552122.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'Honda Aircraft' AND (image_url IS NULL OR image_url = '');

-- Pilatus PC-12
UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/15019497/pexels-photo-15019497.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'Pilatus' AND model LIKE 'PC-12%' AND (image_url IS NULL OR image_url = '');

-- Cirrus
UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/14609253/pexels-photo-14609253.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'Cirrus' AND (image_url IS NULL OR image_url = '');

-- Robinson helicopters
UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/40487980/pexels-photo-40487980.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'Robinson' AND (image_url IS NULL OR image_url = '');

-- Bell 206
UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/37597196/pexels-photo-37597196.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'Bell' AND model = '206' AND (image_url IS NULL OR image_url = '');

-- Bell others
UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/38038452/pexels-photo-38038452.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'Bell' AND model != '206' AND (image_url IS NULL OR image_url = '');

-- Diamond DA42 / DA62
UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/30773881/pexels-photo-30773881.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'Diamond' AND model IN ('DA40','DA42') AND (image_url IS NULL OR image_url = '');

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/18943850/pexels-photo-18943850.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'Diamond' AND model = 'DA62' AND (image_url IS NULL OR image_url = '');

-- Bombardier Global Express
UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/11935296/pexels-photo-11935296.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'Bombardier' AND model LIKE 'Global%' AND (image_url IS NULL OR image_url = '');

-- Dassault Falcon
UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/11935301/pexels-photo-11935301.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'Dassault Falcon' AND (image_url IS NULL OR image_url = '');

-- ATR turboprop
UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/34868849/pexels-photo-34868849.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE manufacturer = 'ATR' AND (image_url IS NULL OR image_url = '');
