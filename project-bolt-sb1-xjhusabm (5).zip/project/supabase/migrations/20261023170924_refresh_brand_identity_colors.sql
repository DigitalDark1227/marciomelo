/*
# Refresh brand identity colors and logo

1. Appearance
- Set the saved accent color to the vivid yellow used by the supplied logo.
- Set the saved primary/background colors to a deep aviation blue.

2. Brand
- Store the supplied local logo path so public and administrative brand areas use the same mark.

3. Safety
- Update only existing JSON settings; no tables or user records are removed.
*/

UPDATE site_settings
SET value = value || '{"accent_color":"#f4d000","primary_color":"#06142b","bg_color":"#0b2450","text_color":"#f7f9fc"}'::jsonb,
    updated_at = now()
WHERE key = 'appearance';

UPDATE site_settings
SET value = value || '{"logo_url":"/logo.png"}'::jsonb,
    updated_at = now()
WHERE key = 'brand';