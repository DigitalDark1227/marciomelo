/*
# Create portfolio storage bucket

1. Storage
- Create 'portfolio' bucket (public, for portfolio images uploaded by admin)
2. Security
- Public read access for anon/authenticated
- Write access only for authenticated (admin)
*/

INSERT INTO storage.buckets (id, name, public) VALUES ('portfolio', 'portfolio', true) ON CONFLICT (id) DO NOTHING;

-- Public read
CREATE POLICY "public_read_portfolio_bucket" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'portfolio');

-- Authenticated write
DROP POLICY IF EXISTS "admin_write_portfolio_bucket" ON storage.objects;
CREATE POLICY "admin_write_portfolio_bucket" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'portfolio');

DROP POLICY IF EXISTS "admin_update_portfolio_bucket" ON storage.objects;
CREATE POLICY "admin_update_portfolio_bucket" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'portfolio');

DROP POLICY IF EXISTS "admin_delete_portfolio_bucket" ON storage.objects;
CREATE POLICY "admin_delete_portfolio_bucket" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'portfolio');
