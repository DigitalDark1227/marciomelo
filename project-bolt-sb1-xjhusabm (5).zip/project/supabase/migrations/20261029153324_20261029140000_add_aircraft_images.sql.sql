-- Assign representative photos to each aircraft model based on its size class.
-- Each size class gets a fitting stock photo.

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/19766183/pexels-photo-19766183.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE size_class = 'midsize_jet' AND (image_url IS NULL OR image_url = '');

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/34779895/pexels-photo-34779895.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE size_class = 'super_midsize' AND (image_url IS NULL OR image_url = '');

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/28281980/pexels-photo-28281980.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE size_class = 'heavy_jet' AND (image_url IS NULL OR image_url = '');

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/37304250/pexels-photo-37304250.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE size_class = 'long_range' AND (image_url IS NULL OR image_url = '');

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/40107470/pexels-photo-40107470.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE size_class = 'light_jet' AND (image_url IS NULL OR image_url = '');

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/32328934/pexels-photo-32328934.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE size_class = 'turboprop' AND (image_url IS NULL OR image_url = '');

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/6789976/pexels-photo-6789976.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE size_class = 'piston_light' AND (image_url IS NULL OR image_url = '');

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/35979815/pexels-photo-35979815.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE size_class = 'helicopter_light' AND (image_url IS NULL OR image_url = '');

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/11727188/pexels-photo-11727188.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE size_class = 'helicopter_medium' AND (image_url IS NULL OR image_url = '');

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/35979809/pexels-photo-35979809.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE size_class = 'helicopter_heavy' AND (image_url IS NULL OR image_url = '');

UPDATE aircraft_models SET image_url = 'https://images.pexels.com/photos/34002376/pexels-photo-34002376.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE size_class = 'vip_large' AND (image_url IS NULL OR image_url = '');
