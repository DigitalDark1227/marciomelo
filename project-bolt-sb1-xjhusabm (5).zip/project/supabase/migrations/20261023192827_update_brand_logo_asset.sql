/*
# Update brand logo asset

1. Modified settings
- `site_settings.value` for the `brand` entry now points to the newly supplied transparent logo asset.

2. User impact
- Public branding and administrative branding use the new logo path while preserving all existing brand text and settings.

3. Data safety
- This migration updates one JSON setting only.
- No tables, columns, user records, policies, or permissions are removed or changed.
*/

UPDATE site_settings
SET value = value || '{"logo_url":"/Marcio_melo_logo.PNG"}'::jsonb,
    updated_at = now()
WHERE key = 'brand';