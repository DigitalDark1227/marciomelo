/*
# Quote Calculator Tables

Creates the full database schema for the internal quote calculator system.

## 1. New Tables

### clients
Stores client profiles used in quotes.
- id (uuid, PK)
- name, company, email, phone, nif, address (text)
- notes (text — internal notes about the client)
- created_at, updated_at

### aircraft_models
Catalog of aircraft for quoting.
- id (uuid, PK)
- manufacturer, model (text)
- registration (text — tail number, optional)
- category (text — e.g. "Light Jet", "Turboprop", "Single Engine")
- estimated_hours (numeric — default labor hours for a standard detail)
- image_url (text)
- is_active (boolean)
- display_order (int)
- created_at, updated_at

### vessel_models
Catalog of vessels for quoting.
- id (uuid, PK)
- manufacturer, model (text)
- length_m (numeric — length in meters)
- category (text — e.g. "Motor Yacht", "Sailboat", "RIB")
- estimated_hours (numeric)
- image_url (text)
- is_active (boolean)
- display_order (int)
- created_at, updated_at

### quote_services
Service catalog for the quote calculator (separate from public `services`).
- id (uuid, PK)
- category (text — 'aero' or 'marine')
- name (text)
- description (text)
- pricing_rule (text — 'fixed', 'hourly', 'estimated_hours', 'dimension', 'custom')
- price (numeric — base price; meaning depends on pricing_rule)
- hourly_rate (numeric — used when pricing_rule is 'hourly' or 'estimated_hours')
- is_active (boolean)
- display_order (int)
- created_at, updated_at

### quote_packages
Bundled service packages (Bronze, Silver, Gold, etc.).
- id (uuid, PK)
- category (text — 'aero' or 'marine')
- name (text)
- description (text)
- service_ids (jsonb — array of quote_services IDs included)
- price (numeric — package total price; 0 means "sum of included services")
- is_active (boolean)
- display_order (int)
- created_at, updated_at

### quotes
The main quote document.
- id (uuid, PK)
- quote_number (text — unique, e.g. "ORC-2026-001")
- client_id (uuid, FK to clients)
- category (text — 'aero' or 'marine')
- model_id (uuid — references aircraft_models or vessel_models depending on category)
- model_label (text — cached manufacturer + model string at time of quoting)
- registration (text — cached, when applicable)
- model_image_url (text — cached)
- status (text — 'rascunho', 'enviado', 'aguardar', 'aceite', 'recusado', 'expirado', 'convertido')
- line_items (jsonb — array of {service_id, name, description, quantity, hours, unit_price, subtotal, pricing_rule, is_custom})
- discount (numeric — flat discount in EUR)
- discount_percent (numeric — percentage discount, 0-100)
- tax_rate (numeric — percentage, e.g. 23 for IVA)
- tax_label (text — e.g. "IVA 23%")
- extra_fees (jsonb — array of {label, amount})
- total (numeric — final total in EUR, cached at save time)
- estimated_duration (text — e.g. "2 dias")
- client_notes (text — notes visible to the client)
- internal_notes (text — notes visible only to admin)
- valid_until (date — quote expiry)
- created_at, updated_at

### quote_history
Audit trail of status changes and edits to quotes.
- id (uuid, PK)
- quote_id (uuid, FK to quotes, ON DELETE CASCADE)
- action (text — e.g. 'created', 'edited', 'status_changed', 'duplicated', 'pdf_generated')
- from_status, to_status (text — for status changes)
- notes (text)
- created_at

## 2. Security
All tables have RLS enabled.
Grants and policies are scoped to `authenticated` only — the admin panel requires sign-in.
The public website does not access any of these tables.
*/

-- === clients ===
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT '',
  company text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  nif text NOT NULL DEFAULT '',
  address text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON clients TO authenticated;
DROP POLICY IF EXISTS "select_clients" ON clients;
CREATE POLICY "select_clients" ON clients FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_clients" ON clients;
CREATE POLICY "insert_clients" ON clients FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_clients" ON clients;
CREATE POLICY "update_clients" ON clients FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_clients" ON clients;
CREATE POLICY "delete_clients" ON clients FOR DELETE TO authenticated USING (true);

-- === aircraft_models ===
CREATE TABLE IF NOT EXISTS aircraft_models (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  manufacturer text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  registration text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT '',
  estimated_hours numeric NOT NULL DEFAULT 0,
  image_url text NOT NULL DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  display_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE aircraft_models ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON aircraft_models TO authenticated;
DROP POLICY IF EXISTS "select_aircraft_models" ON aircraft_models;
CREATE POLICY "select_aircraft_models" ON aircraft_models FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_aircraft_models" ON aircraft_models;
CREATE POLICY "insert_aircraft_models" ON aircraft_models FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_aircraft_models" ON aircraft_models;
CREATE POLICY "update_aircraft_models" ON aircraft_models FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_aircraft_models" ON aircraft_models;
CREATE POLICY "delete_aircraft_models" ON aircraft_models FOR DELETE TO authenticated USING (true);

-- === vessel_models ===
CREATE TABLE IF NOT EXISTS vessel_models (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  manufacturer text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  length_m numeric NOT NULL DEFAULT 0,
  category text NOT NULL DEFAULT '',
  estimated_hours numeric NOT NULL DEFAULT 0,
  image_url text NOT NULL DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  display_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE vessel_models ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON vessel_models TO authenticated;
DROP POLICY IF EXISTS "select_vessel_models" ON vessel_models;
CREATE POLICY "select_vessel_models" ON vessel_models FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_vessel_models" ON vessel_models;
CREATE POLICY "insert_vessel_models" ON vessel_models FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_vessel_models" ON vessel_models;
CREATE POLICY "update_vessel_models" ON vessel_models FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_vessel_models" ON vessel_models;
CREATE POLICY "delete_vessel_models" ON vessel_models FOR DELETE TO authenticated USING (true);

-- === quote_services ===
CREATE TABLE IF NOT EXISTS quote_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL DEFAULT 'aero',
  name text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  pricing_rule text NOT NULL DEFAULT 'fixed',
  price numeric NOT NULL DEFAULT 0,
  hourly_rate numeric NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  display_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE quote_services ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON quote_services TO authenticated;
DROP POLICY IF EXISTS "select_quote_services" ON quote_services;
CREATE POLICY "select_quote_services" ON quote_services FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_quote_services" ON quote_services;
CREATE POLICY "insert_quote_services" ON quote_services FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_quote_services" ON quote_services;
CREATE POLICY "update_quote_services" ON quote_services FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_quote_services" ON quote_services;
CREATE POLICY "delete_quote_services" ON quote_services FOR DELETE TO authenticated USING (true);

-- === quote_packages ===
CREATE TABLE IF NOT EXISTS quote_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL DEFAULT 'aero',
  name text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  service_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  price numeric NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  display_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE quote_packages ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON quote_packages TO authenticated;
DROP POLICY IF EXISTS "select_quote_packages" ON quote_packages;
CREATE POLICY "select_quote_packages" ON quote_packages FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_quote_packages" ON quote_packages;
CREATE POLICY "insert_quote_packages" ON quote_packages FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_quote_packages" ON quote_packages;
CREATE POLICY "update_quote_packages" ON quote_packages FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_quote_packages" ON quote_packages;
CREATE POLICY "delete_quote_packages" ON quote_packages FOR DELETE TO authenticated USING (true);

-- === quotes ===
CREATE TABLE IF NOT EXISTS quotes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quote_number text UNIQUE NOT NULL DEFAULT '',
  client_id uuid REFERENCES clients(id) ON DELETE SET NULL,
  category text NOT NULL DEFAULT 'aero',
  model_id uuid,
  model_label text NOT NULL DEFAULT '',
  registration text NOT NULL DEFAULT '',
  model_image_url text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'rascunho',
  line_items jsonb NOT NULL DEFAULT '[]'::jsonb,
  discount numeric NOT NULL DEFAULT 0,
  discount_percent numeric NOT NULL DEFAULT 0,
  tax_rate numeric NOT NULL DEFAULT 0,
  tax_label text NOT NULL DEFAULT '',
  extra_fees jsonb NOT NULL DEFAULT '[]'::jsonb,
  total numeric NOT NULL DEFAULT 0,
  estimated_duration text NOT NULL DEFAULT '',
  client_notes text NOT NULL DEFAULT '',
  internal_notes text NOT NULL DEFAULT '',
  valid_until date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE quotes ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON quotes TO authenticated;
DROP POLICY IF EXISTS "select_quotes" ON quotes;
CREATE POLICY "select_quotes" ON quotes FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_quotes" ON quotes;
CREATE POLICY "insert_quotes" ON quotes FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_quotes" ON quotes;
CREATE POLICY "update_quotes" ON quotes FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_quotes" ON quotes;
CREATE POLICY "delete_quotes" ON quotes FOR DELETE TO authenticated USING (true);

-- === quote_history ===
CREATE TABLE IF NOT EXISTS quote_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quote_id uuid REFERENCES quotes(id) ON DELETE CASCADE,
  action text NOT NULL DEFAULT '',
  from_status text,
  to_status text,
  notes text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE quote_history ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON quote_history TO authenticated;
DROP POLICY IF EXISTS "select_quote_history" ON quote_history;
CREATE POLICY "select_quote_history" ON quote_history FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_quote_history" ON quote_history;
CREATE POLICY "insert_quote_history" ON quote_history FOR INSERT TO authenticated WITH CHECK (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_quotes_client ON quotes(client_id);
CREATE INDEX IF NOT EXISTS idx_quotes_status ON quotes(status);
CREATE INDEX IF NOT EXISTS idx_quotes_number ON quotes(quote_number);
CREATE INDEX IF NOT EXISTS idx_quote_history_quote ON quote_history(quote_id);
CREATE INDEX IF NOT EXISTS idx_quote_services_category ON quote_services(category);
CREATE INDEX IF NOT EXISTS idx_quote_packages_category ON quote_packages(category);

-- === Seed default aero services ===
INSERT INTO quote_services (category, name, description, pricing_rule, price, hourly_rate, is_active, display_order)
VALUES
  ('aero', 'Exterior Wash', 'Lavagem exterior completa da aeronave', 'fixed', 0, 0, true, 1),
  ('aero', 'One-Step Polish', 'Polimento em uma etapa para restaurar o brilho', 'hourly', 0, 75, true, 2),
  ('aero', 'Wax Protection', 'Aplicação de cera protetora', 'fixed', 0, 0, true, 3),
  ('aero', 'Spray Ceramic', 'Aplicação de coating cerâmico spray', 'fixed', 0, 0, true, 4),
  ('aero', 'Full Ceramic Coating', 'Coating cerâmico completo', 'estimated_hours', 0, 90, true, 5),
  ('aero', 'Brightwork Polishing', 'Polimento de superfícies metálicas', 'hourly', 0, 80, true, 6),
  ('aero', 'De-Ice Boot Treatment', 'Tratamento de botas anti-gelo', 'fixed', 0, 0, true, 7),
  ('aero', 'Carpet Extraction', 'Extração e limpeza de carpetes', 'hourly', 0, 65, true, 8),
  ('aero', 'Leather Cleaning', 'Limpeza e hidratação de couro', 'hourly', 0, 70, true, 9)
ON CONFLICT DO NOTHING;

-- === Seed default marine services ===
INSERT INTO quote_services (category, name, description, pricing_rule, price, hourly_rate, is_active, display_order)
VALUES
  ('marine', 'Hull Wash', 'Lavagem do casco', 'fixed', 0, 0, true, 1),
  ('marine', 'Hull Polish', 'Polimento do casco', 'hourly', 0, 70, true, 2),
  ('marine', 'Anti-Fouling Treatment', 'Tratamento anti-fouling', 'estimated_hours', 0, 85, true, 3),
  ('marine', 'Deck Cleaning', 'Limpeza do convés', 'hourly', 0, 60, true, 4),
  ('marine', 'Teak Restoration', 'Restauro de teca', 'hourly', 0, 75, true, 5),
  ('marine', 'Isinglass Cleaning', 'Limpeza de cristais e isinglass', 'fixed', 0, 0, true, 6),
  ('marine', 'Upholstery Cleaning', 'Limpeza de estofos', 'hourly', 0, 65, true, 7),
  ('marine', 'Ceramic Coating', 'Coating cerâmico náutico', 'estimated_hours', 0, 95, true, 8),
  ('marine', 'Interior Detailing', 'Detailing interior completo', 'hourly', 0, 70, true, 9)
ON CONFLICT DO NOTHING;

-- === Seed default packages ===
INSERT INTO quote_packages (category, name, description, service_ids, price, is_active, display_order)
VALUES
  ('aero', 'Bronze', 'Pacote essencial', '[]'::jsonb, 0, true, 1),
  ('aero', 'Silver', 'Pacote intermédio', '[]'::jsonb, 0, true, 2),
  ('aero', 'Gold', 'Pacote avançado', '[]'::jsonb, 0, true, 3),
  ('aero', 'Platinum', 'Pacote premium', '[]'::jsonb, 0, true, 4),
  ('aero', 'Shiny Jet', 'Pacote completo premium', '[]'::jsonb, 0, true, 5),
  ('marine', 'Bronze', 'Pacote essencial náutico', '[]'::jsonb, 0, true, 1),
  ('marine', 'Silver', 'Pacote intermédio náutico', '[]'::jsonb, 0, true, 2),
  ('marine', 'Gold', 'Pacote avançado náutico', '[]'::jsonb, 0, true, 3),
  ('marine', 'Platinum', 'Pacote premium náutico', '[]'::jsonb, 0, true, 4)
ON CONFLICT DO NOTHING;
