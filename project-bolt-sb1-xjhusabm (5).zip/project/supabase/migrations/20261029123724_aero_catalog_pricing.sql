/*
# Aircraft catalog, EUR pricing and detailing packages

Extends the existing quote calculator with a structured aircraft catalog and an editable EUR price book for aircraft services. Existing quotes, clients, aircraft rows and generic quote services are kept untouched.

## 1. Changes to existing tables
- aircraft_models: adds `size_class` (links to a size class) and `price_factor` (multiplier applied to base service prices). Adds a unique manufacturer + model pair so the same model cannot be entered twice. Sets the size class of the existing Cessna 172P row.

## 2. New tables
- aircraft_size_classes: the 11 editable size classes with their initial price factor (configuration values, not official prices).
- aero_services: aircraft services with identifier (code), English name, description, category, base price in EUR (empty when not yet defined), optional estimated minutes, custom-quote flag and active flag.
- aero_service_prices: optional per-model overrides. A fixed price takes priority over the automatic calculation. A disabled row hides the service for that model.
- aero_packages: detailing packages with optional fixed price override and an inspection flag (used for ceramic packages).
- aero_package_services: services included in each package.

## 3. Seeded data
- Manufacturers and models from the agreed catalog, with category and size class.
- The 18 aircraft services. Only the base prices provided by the business are set; the others stay empty until priced.
- The five packages with their included services. Package prices are calculated from the services unless an override is set.

## 4. Security
- Row level security is enabled on every new table.
- Anyone (visitors included) can read the catalog and prices.
- Only signed-in administrators can create, change or delete data.
- Money columns use two decimal places and cannot be negative.

## 5. Notes
- Seeds use ON CONFLICT DO NOTHING so the migration can be re-run safely.
*/

-- Size classes
CREATE TABLE IF NOT EXISTS aircraft_size_classes (
  code text PRIMARY KEY,
  label text NOT NULL,
  price_factor numeric(6,3) NOT NULL CHECK (price_factor > 0),
  display_order int NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE aircraft_size_classes ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON aircraft_size_classes TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON aircraft_size_classes TO authenticated;
DROP POLICY IF EXISTS "select_size_classes" ON aircraft_size_classes;
CREATE POLICY "select_size_classes" ON aircraft_size_classes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_size_classes" ON aircraft_size_classes;
CREATE POLICY "insert_size_classes" ON aircraft_size_classes FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_size_classes" ON aircraft_size_classes;
CREATE POLICY "update_size_classes" ON aircraft_size_classes FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_size_classes" ON aircraft_size_classes;
CREATE POLICY "delete_size_classes" ON aircraft_size_classes FOR DELETE TO authenticated USING (true);

INSERT INTO aircraft_size_classes (code, label, price_factor, display_order) VALUES
  ('piston_light', 'Avião ligeiro a pistão', 0.800, 1),
  ('turboprop', 'Turboélice', 1.000, 2),
  ('light_jet', 'Jato ligeiro', 1.200, 3),
  ('midsize_jet', 'Jato médio', 1.400, 4),
  ('super_midsize', 'Super midsize', 1.600, 5),
  ('heavy_jet', 'Jato de grande porte', 1.800, 6),
  ('long_range', 'Jato de longo alcance', 2.200, 7),
  ('vip_large', 'Aeronave VIP de grande porte', 2.500, 8),
  ('helicopter_light', 'Helicóptero ligeiro', 0.700, 9),
  ('helicopter_medium', 'Helicóptero médio', 0.950, 10),
  ('helicopter_heavy', 'Helicóptero pesado', 1.200, 11)
ON CONFLICT (code) DO NOTHING;

-- Aircraft models: new columns and uniqueness
ALTER TABLE aircraft_models ADD COLUMN IF NOT EXISTS size_class text REFERENCES aircraft_size_classes(code);
ALTER TABLE aircraft_models ADD COLUMN IF NOT EXISTS price_factor numeric(6,3) NOT NULL DEFAULT 1 CHECK (price_factor > 0);
UPDATE aircraft_models SET size_class = 'piston_light' WHERE size_class IS NULL AND model = '172P Skyhawk';
CREATE UNIQUE INDEX IF NOT EXISTS aircraft_models_manufacturer_model_key ON aircraft_models (manufacturer, model);
GRANT SELECT ON aircraft_models TO anon;
DROP POLICY IF EXISTS "anon_select_aircraft_models" ON aircraft_models;
CREATE POLICY "anon_select_aircraft_models" ON aircraft_models FOR SELECT TO anon USING (true);

-- Aircraft services
CREATE TABLE IF NOT EXISTS aero_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT 'Outros',
  base_price numeric(10,2) CHECK (base_price IS NULL OR base_price >= 0),
  estimated_minutes int CHECK (estimated_minutes IS NULL OR estimated_minutes >= 0),
  custom_quote boolean NOT NULL DEFAULT false,
  is_active boolean NOT NULL DEFAULT true,
  display_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE aero_services ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON aero_services TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON aero_services TO authenticated;
DROP POLICY IF EXISTS "select_aero_services" ON aero_services;
CREATE POLICY "select_aero_services" ON aero_services FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_aero_services" ON aero_services;
CREATE POLICY "insert_aero_services" ON aero_services FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_aero_services" ON aero_services;
CREATE POLICY "update_aero_services" ON aero_services FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_aero_services" ON aero_services;
CREATE POLICY "delete_aero_services" ON aero_services FOR DELETE TO authenticated USING (true);

-- Per-model price overrides and availability
CREATE TABLE IF NOT EXISTS aero_service_prices (
  service_id uuid NOT NULL REFERENCES aero_services(id) ON DELETE CASCADE,
  aircraft_model_id uuid NOT NULL REFERENCES aircraft_models(id) ON DELETE CASCADE,
  fixed_price numeric(10,2) CHECK (fixed_price IS NULL OR fixed_price >= 0),
  is_enabled boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (service_id, aircraft_model_id)
);
CREATE INDEX IF NOT EXISTS idx_aero_service_prices_model ON aero_service_prices (aircraft_model_id);
ALTER TABLE aero_service_prices ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON aero_service_prices TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON aero_service_prices TO authenticated;
DROP POLICY IF EXISTS "select_aero_service_prices" ON aero_service_prices;
CREATE POLICY "select_aero_service_prices" ON aero_service_prices FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_aero_service_prices" ON aero_service_prices;
CREATE POLICY "insert_aero_service_prices" ON aero_service_prices FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_aero_service_prices" ON aero_service_prices;
CREATE POLICY "update_aero_service_prices" ON aero_service_prices FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_aero_service_prices" ON aero_service_prices;
CREATE POLICY "delete_aero_service_prices" ON aero_service_prices FOR DELETE TO authenticated USING (true);

-- Packages
CREATE TABLE IF NOT EXISTS aero_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  price_override numeric(10,2) CHECK (price_override IS NULL OR price_override >= 0),
  requires_inspection boolean NOT NULL DEFAULT false,
  is_active boolean NOT NULL DEFAULT true,
  display_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE aero_packages ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON aero_packages TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON aero_packages TO authenticated;
DROP POLICY IF EXISTS "select_aero_packages" ON aero_packages;
CREATE POLICY "select_aero_packages" ON aero_packages FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_aero_packages" ON aero_packages;
CREATE POLICY "insert_aero_packages" ON aero_packages FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "update_aero_packages" ON aero_packages;
CREATE POLICY "update_aero_packages" ON aero_packages FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "delete_aero_packages" ON aero_packages;
CREATE POLICY "delete_aero_packages" ON aero_packages FOR DELETE TO authenticated USING (true);

CREATE TABLE IF NOT EXISTS aero_package_services (
  package_id uuid NOT NULL REFERENCES aero_packages(id) ON DELETE CASCADE,
  service_id uuid NOT NULL REFERENCES aero_services(id) ON DELETE CASCADE,
  PRIMARY KEY (package_id, service_id)
);
ALTER TABLE aero_package_services ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON aero_package_services TO anon, authenticated;
GRANT INSERT, DELETE ON aero_package_services TO authenticated;
DROP POLICY IF EXISTS "select_aero_package_services" ON aero_package_services;
CREATE POLICY "select_aero_package_services" ON aero_package_services FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "insert_aero_package_services" ON aero_package_services;
CREATE POLICY "insert_aero_package_services" ON aero_package_services FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "delete_aero_package_services" ON aero_package_services;
CREATE POLICY "delete_aero_package_services" ON aero_package_services FOR DELETE TO authenticated USING (true);

-- Seed: aircraft services (base prices only where the business defined them)
INSERT INTO aero_services (code, name, description, category, base_price, custom_quote, display_order) VALUES
  ('maintenance_wash', 'Maintenance Wash', 'Lavagem exterior de manutenção', 'Exterior', 500, false, 1),
  ('exterior_dry_wash', 'Exterior Dry Wash', 'Lavagem exterior a seco', 'Exterior', NULL, false, 2),
  ('full_exterior_wash', 'Full Exterior Wash', 'Lavagem exterior completa', 'Exterior', NULL, false, 3),
  ('paint_decontamination', 'Paint Decontamination', 'Descontaminação da pintura', 'Pintura e proteção', 900, false, 4),
  ('one_step_polish', 'One Step Polish', 'Polimento em uma etapa', 'Pintura e proteção', 2000, true, 5),
  ('multi_step_paint_correction', 'Multi-Step Paint Correction', 'Correção de pintura em várias etapas', 'Pintura e proteção', NULL, true, 6),
  ('wax_application', 'Wax Application', 'Aplicação de cera', 'Pintura e proteção', 800, false, 7),
  ('fly_shiny_pro_ceramic_coating', 'Fly Shiny Pro Ceramic Coating', 'Revestimento cerâmico Fly Shiny Pro', 'Pintura e proteção', 3500, true, 8),
  ('polish_brightwork_de_ice_boots', 'Polish Brightwork / De-Ice Boots', 'Polimento de metais brilhantes e botas anti-gelo', 'Exterior', 1000, true, 9),
  ('clean_condition_leather', 'Clean & Condition Leather', 'Limpeza e hidratação de couro', 'Interior', 250, false, 10),
  ('extract_carpets', 'Extract Carpets', 'Extração de carpetes', 'Interior', 180, false, 11),
  ('interior_deep_cleaning', 'Interior Deep Cleaning', 'Limpeza profunda do interior', 'Interior', 600, false, 12),
  ('interior_maintenance_cleaning', 'Interior Maintenance Cleaning', 'Limpeza de manutenção do interior', 'Interior', NULL, false, 13),
  ('window_cleaning', 'Window Cleaning', 'Limpeza de janelas e transparências', 'Vidros e metais', 150, false, 14),
  ('metal_polishing', 'Metal Polishing', 'Polimento de metais', 'Vidros e metais', 400, true, 15),
  ('engine_exterior_cleaning', 'Engine Exterior Cleaning', 'Limpeza exterior do motor', 'Motor', 300, false, 16),
  ('cabin_disinfection', 'Cabin Disinfection', 'Desinfeção da cabine', 'Interior', NULL, false, 17),
  ('complete_interior_exterior_detail', 'Complete Interior & Exterior Detail', 'Detailing completo interior e exterior', 'Detailing completo', NULL, false, 18)
ON CONFLICT (code) DO NOTHING;

-- Seed: detailing packages (prices are calculated from included services unless overridden)
INSERT INTO aero_packages (code, name, description, requires_inspection, display_order) VALUES
  ('bronze', 'Bronze', 'Lavagem exterior e interior de manutenção.', false, 1),
  ('silver', 'Silver', 'Limpeza interior e exterior detalhada.', false, 2),
  ('gold', 'Gold', 'Limpeza completa, tratamento de superfícies e proteção básica.', false, 3),
  ('platinum', 'Platinum', 'Detailing premium com polimento, proteção e serviços adicionais elegíveis.', false, 4),
  ('ceramic_pro', 'Ceramic Pro', 'Preparação da superfície, descontaminação e aplicação de revestimento cerâmico, sujeitos a inspeção e compatibilidade dos materiais.', true, 5)
ON CONFLICT (code) DO NOTHING;

INSERT INTO aero_package_services (package_id, service_id)
SELECT p.id, s.id
FROM (VALUES
  ('bronze', 'maintenance_wash'), ('bronze', 'interior_maintenance_cleaning'),
  ('silver', 'full_exterior_wash'), ('silver', 'interior_deep_cleaning'), ('silver', 'window_cleaning'),
  ('gold', 'full_exterior_wash'), ('gold', 'paint_decontamination'), ('gold', 'interior_deep_cleaning'), ('gold', 'clean_condition_leather'), ('gold', 'extract_carpets'), ('gold', 'window_cleaning'), ('gold', 'wax_application'),
  ('platinum', 'paint_decontamination'), ('platinum', 'one_step_polish'), ('platinum', 'wax_application'), ('platinum', 'interior_deep_cleaning'), ('platinum', 'clean_condition_leather'), ('platinum', 'extract_carpets'), ('platinum', 'window_cleaning'), ('platinum', 'metal_polishing'),
  ('ceramic_pro', 'paint_decontamination'), ('ceramic_pro', 'one_step_polish'), ('ceramic_pro', 'fly_shiny_pro_ceramic_coating')
) AS v(package_code, service_code)
JOIN aero_packages p ON p.code = v.package_code
JOIN aero_services s ON s.code = v.service_code
ON CONFLICT DO NOTHING;

-- Seed: aircraft models (manufacturer, model, category, size class)
INSERT INTO aircraft_models (manufacturer, model, category, size_class, price_factor, estimated_hours, is_active, display_order)
SELECT v.manufacturer, v.model, v.category, v.size_class,
  (SELECT c.price_factor FROM aircraft_size_classes c WHERE c.code = v.size_class),
  0, true, 100
FROM (VALUES
  ('Gulfstream', 'G150', 'Midsize Jets', 'midsize_jet'),
  ('Gulfstream', 'G200', 'Midsize Jets', 'midsize_jet'),
  ('Gulfstream', 'G280', 'Super Midsize Jets', 'super_midsize'),
  ('Gulfstream', 'G400', 'Heavy Jets', 'heavy_jet'),
  ('Gulfstream', 'G450', 'Heavy Jets', 'heavy_jet'),
  ('Gulfstream', 'G500', 'Heavy Jets', 'heavy_jet'),
  ('Gulfstream', 'G550', 'Heavy Jets', 'heavy_jet'),
  ('Gulfstream', 'G600', 'Ultra Long Range Jets', 'long_range'),
  ('Gulfstream', 'G650', 'Ultra Long Range Jets', 'long_range'),
  ('Gulfstream', 'G650ER', 'Ultra Long Range Jets', 'long_range'),
  ('Gulfstream', 'G700', 'Ultra Long Range Jets', 'long_range'),
  ('Gulfstream', 'G800', 'Ultra Long Range Jets', 'long_range'),
  ('Bombardier', 'Learjet 40', 'Light Jets', 'light_jet'),
  ('Bombardier', 'Learjet 45', 'Light Jets', 'light_jet'),
  ('Bombardier', 'Learjet 60', 'Business Jets', 'midsize_jet'),
  ('Bombardier', 'Learjet 70', 'Business Jets', 'midsize_jet'),
  ('Bombardier', 'Learjet 75', 'Business Jets', 'midsize_jet'),
  ('Bombardier', 'Challenger 300', 'Midsize Jets', 'midsize_jet'),
  ('Bombardier', 'Challenger 350', 'Midsize Jets', 'midsize_jet'),
  ('Bombardier', 'Challenger 3500', 'Super Midsize Jets', 'super_midsize'),
  ('Bombardier', 'Challenger 604', 'Super Midsize Jets', 'super_midsize'),
  ('Bombardier', 'Challenger 605', 'Super Midsize Jets', 'super_midsize'),
  ('Bombardier', 'Challenger 650', 'Super Midsize Jets', 'super_midsize'),
  ('Bombardier', 'Global 5000', 'Heavy Jets', 'heavy_jet'),
  ('Bombardier', 'Global 5500', 'Heavy Jets', 'heavy_jet'),
  ('Bombardier', 'Global 6000', 'Ultra Long Range Jets', 'long_range'),
  ('Bombardier', 'Global 6500', 'Ultra Long Range Jets', 'long_range'),
  ('Bombardier', 'Global 7500', 'Ultra Long Range Jets', 'long_range'),
  ('Bombardier', 'Global 8000', 'Ultra Long Range Jets', 'long_range'),
  ('Dassault Falcon', 'Falcon 10', 'Light Jets', 'light_jet'),
  ('Dassault Falcon', 'Falcon 20', 'Midsize Jets', 'midsize_jet'),
  ('Dassault Falcon', 'Falcon 50', 'Heavy Jets', 'heavy_jet'),
  ('Dassault Falcon', 'Falcon 900', 'Heavy Jets', 'heavy_jet'),
  ('Dassault Falcon', 'Falcon 2000', 'Super Midsize Jets', 'super_midsize'),
  ('Dassault Falcon', 'Falcon 2000LXS', 'Super Midsize Jets', 'super_midsize'),
  ('Dassault Falcon', 'Falcon 6X', 'Ultra Long Range Jets', 'long_range'),
  ('Dassault Falcon', 'Falcon 7X', 'Ultra Long Range Jets', 'long_range'),
  ('Dassault Falcon', 'Falcon 8X', 'Ultra Long Range Jets', 'long_range'),
  ('Dassault Falcon', 'Falcon 10X', 'Ultra Long Range Jets', 'long_range'),
  ('Embraer', 'Phenom 100', 'Light Jets', 'light_jet'),
  ('Embraer', 'Phenom 100EV', 'Light Jets', 'light_jet'),
  ('Embraer', 'Phenom 300', 'Midsize Jets', 'midsize_jet'),
  ('Embraer', 'Phenom 300E', 'Midsize Jets', 'midsize_jet'),
  ('Embraer', 'Legacy 450', 'Midsize Jets', 'midsize_jet'),
  ('Embraer', 'Legacy 500', 'Midsize Jets', 'midsize_jet'),
  ('Embraer', 'Legacy 600', 'Super Midsize Jets', 'super_midsize'),
  ('Embraer', 'Legacy 650E', 'Super Midsize Jets', 'super_midsize'),
  ('Embraer', 'Praetor 500', 'Midsize Jets', 'midsize_jet'),
  ('Embraer', 'Praetor 600', 'Super Midsize Jets', 'super_midsize'),
  ('Embraer', 'Lineage 1000E', 'VIP Airliners', 'vip_large'),
  ('Cessna', 'Citation Mustang', 'Light Jets', 'light_jet'),
  ('Cessna', 'Citation M2', 'Light Jets', 'light_jet'),
  ('Cessna', 'Citation CJ1', 'Light Jets', 'light_jet'),
  ('Cessna', 'Citation CJ2', 'Light Jets', 'light_jet'),
  ('Cessna', 'Citation CJ3', 'Light Jets', 'light_jet'),
  ('Cessna', 'Citation CJ4', 'Light Jets', 'light_jet'),
  ('Cessna', 'Citation Excel', 'Business Jets', 'midsize_jet'),
  ('Cessna', 'Citation XLS', 'Business Jets', 'midsize_jet'),
  ('Cessna', 'Citation XLS+', 'Business Jets', 'midsize_jet'),
  ('Cessna', 'Citation Sovereign', 'Super Midsize Jets', 'super_midsize'),
  ('Cessna', 'Citation Latitude', 'Midsize Jets', 'midsize_jet'),
  ('Cessna', 'Citation Longitude', 'Super Midsize Jets', 'super_midsize'),
  ('Cessna', 'Citation X', 'Super Midsize Jets', 'super_midsize'),
  ('Cessna', 'Citation VII', 'Business Jets', 'midsize_jet'),
  ('Hawker Beechcraft', 'Beechjet 400A', 'Light Jets', 'light_jet'),
  ('Hawker Beechcraft', 'Premier I', 'Light Jets', 'light_jet'),
  ('Hawker Beechcraft', 'Premier IA', 'Light Jets', 'light_jet'),
  ('Hawker Beechcraft', 'Hawker 400XP', 'Light Jets', 'light_jet'),
  ('Hawker Beechcraft', 'Hawker 750', 'Business Jets', 'midsize_jet'),
  ('Hawker Beechcraft', 'Hawker 800XP', 'Midsize Jets', 'midsize_jet'),
  ('Hawker Beechcraft', 'Hawker 850XP', 'Midsize Jets', 'midsize_jet'),
  ('Hawker Beechcraft', 'Hawker 900XP', 'Super Midsize Jets', 'super_midsize'),
  ('Hawker Beechcraft', 'Hawker 1000', 'Super Midsize Jets', 'super_midsize'),
  ('Hawker Beechcraft', 'King Air 90', 'Turboprops', 'turboprop'),
  ('Hawker Beechcraft', 'King Air 200', 'Turboprops', 'turboprop'),
  ('Hawker Beechcraft', 'King Air 250', 'Turboprops', 'turboprop'),
  ('Hawker Beechcraft', 'King Air 260', 'Turboprops', 'turboprop'),
  ('Hawker Beechcraft', 'King Air 300', 'Turboprops', 'turboprop'),
  ('Hawker Beechcraft', 'King Air 350', 'Turboprops', 'turboprop'),
  ('Hawker Beechcraft', 'King Air 360', 'Turboprops', 'turboprop'),
  ('Honda Aircraft', 'HondaJet', 'Light Jets', 'light_jet'),
  ('Honda Aircraft', 'HondaJet Elite', 'Light Jets', 'light_jet'),
  ('Honda Aircraft', 'HondaJet Elite S', 'Light Jets', 'light_jet'),
  ('Honda Aircraft', 'HondaJet Elite II', 'Light Jets', 'light_jet'),
  ('Pilatus', 'PC-12', 'Turboprops', 'turboprop'),
  ('Pilatus', 'PC-12 NG', 'Turboprops', 'turboprop'),
  ('Pilatus', 'PC-12 NGX', 'Turboprops', 'turboprop'),
  ('Pilatus', 'PC-24', 'Light Jets', 'light_jet'),
  ('Cirrus', 'Vision Jet SF50', 'Light Jets', 'light_jet'),
  ('Cirrus', 'Vision Jet G2', 'Light Jets', 'light_jet'),
  ('Cirrus', 'Vision Jet G2+', 'Light Jets', 'light_jet'),
  ('Cirrus', 'Vision Jet G3', 'Light Jets', 'light_jet'),
  ('Cirrus', 'SR20', 'General Aviation', 'piston_light'),
  ('Cirrus', 'SR22', 'General Aviation', 'piston_light'),
  ('Cirrus', 'SR22T', 'General Aviation', 'piston_light'),
  ('Eclipse', 'Eclipse 500', 'Light Jets', 'light_jet'),
  ('Eclipse', 'Eclipse 550', 'Light Jets', 'light_jet'),
  ('Piaggio', 'P.180 Avanti', 'Turboprops', 'turboprop'),
  ('Piaggio', 'P.180 Avanti II', 'Turboprops', 'turboprop'),
  ('Piaggio', 'P.180 Avanti EVO', 'Turboprops', 'turboprop'),
  ('Daher', 'TBM 700', 'Turboprops', 'turboprop'),
  ('Daher', 'TBM 850', 'Turboprops', 'turboprop'),
  ('Daher', 'TBM 900', 'Turboprops', 'turboprop'),
  ('Daher', 'TBM 910', 'Turboprops', 'turboprop'),
  ('Daher', 'TBM 930', 'Turboprops', 'turboprop'),
  ('Daher', 'TBM 940', 'Turboprops', 'turboprop'),
  ('Daher', 'TBM 960', 'Turboprops', 'turboprop'),
  ('Piper', 'PA-28 Cherokee', 'General Aviation', 'piston_light'),
  ('Piper', 'PA-28 Archer', 'General Aviation', 'piston_light'),
  ('Piper', 'PA-28 Arrow', 'General Aviation', 'piston_light'),
  ('Piper', 'PA-32 Saratoga', 'General Aviation', 'piston_light'),
  ('Piper', 'PA-34 Seneca', 'General Aviation', 'piston_light'),
  ('Piper', 'PA-44 Seminole', 'General Aviation', 'piston_light'),
  ('Piper', 'PA-46 Malibu', 'General Aviation', 'piston_light'),
  ('Piper', 'PA-46 Meridian', 'General Aviation', 'piston_light'),
  ('Piper', 'PA-46 M350', 'General Aviation', 'piston_light'),
  ('Piper', 'PA-46 M500', 'General Aviation', 'piston_light'),
  ('Piper', 'PA-46 M600', 'General Aviation', 'piston_light'),
  ('Diamond', 'DA20', 'General Aviation', 'piston_light'),
  ('Diamond', 'DA40', 'General Aviation', 'piston_light'),
  ('Diamond', 'DA42', 'General Aviation', 'piston_light'),
  ('Diamond', 'DA50', 'General Aviation', 'piston_light'),
  ('Diamond', 'DA62', 'General Aviation', 'piston_light'),
  ('Mooney', 'M20J', 'General Aviation', 'piston_light'),
  ('Mooney', 'M20K', 'General Aviation', 'piston_light'),
  ('Mooney', 'M20R', 'General Aviation', 'piston_light'),
  ('Mooney', 'M20TN', 'General Aviation', 'piston_light'),
  ('Tecnam', 'P2002', 'General Aviation', 'piston_light'),
  ('Tecnam', 'P2006T', 'General Aviation', 'piston_light'),
  ('Tecnam', 'P2010', 'General Aviation', 'piston_light'),
  ('Tecnam', 'P2012 Traveller', 'General Aviation', 'piston_light'),
  ('Van''s Aircraft', 'RV-7', 'General Aviation', 'piston_light'),
  ('Van''s Aircraft', 'RV-8', 'General Aviation', 'piston_light'),
  ('Van''s Aircraft', 'RV-9', 'General Aviation', 'piston_light'),
  ('Van''s Aircraft', 'RV-10', 'General Aviation', 'piston_light'),
  ('Van''s Aircraft', 'RV-12', 'General Aviation', 'piston_light'),
  ('Airbus Helicopters', 'H120', 'Helicopters', 'helicopter_light'),
  ('Airbus Helicopters', 'H125', 'Helicopters', 'helicopter_light'),
  ('Airbus Helicopters', 'H130', 'Helicopters', 'helicopter_light'),
  ('Airbus Helicopters', 'H135', 'Helicopters', 'helicopter_medium'),
  ('Airbus Helicopters', 'H145', 'Helicopters', 'helicopter_medium'),
  ('Airbus Helicopters', 'H155', 'Helicopters', 'helicopter_medium'),
  ('Airbus Helicopters', 'H160', 'Helicopters', 'helicopter_medium'),
  ('Airbus Helicopters', 'H175', 'Helicopters', 'helicopter_heavy'),
  ('Airbus Helicopters', 'H225', 'Helicopters', 'helicopter_heavy'),
  ('Bell', '206', 'Helicopters', 'helicopter_light'),
  ('Bell', '407', 'Helicopters', 'helicopter_light'),
  ('Bell', '429', 'Helicopters', 'helicopter_medium'),
  ('Bell', '412', 'Helicopters', 'helicopter_medium'),
  ('Bell', '505', 'Helicopters', 'helicopter_light'),
  ('Bell', '525', 'Helicopters', 'helicopter_heavy'),
  ('Robinson', 'R22', 'Helicopters', 'helicopter_light'),
  ('Robinson', 'R44', 'Helicopters', 'helicopter_light'),
  ('Robinson', 'R66', 'Helicopters', 'helicopter_light'),
  ('Leonardo', 'AW109', 'Helicopters', 'helicopter_light'),
  ('Leonardo', 'AW119', 'Helicopters', 'helicopter_medium'),
  ('Leonardo', 'AW139', 'Helicopters', 'helicopter_medium'),
  ('Leonardo', 'AW169', 'Helicopters', 'helicopter_medium'),
  ('Leonardo', 'AW189', 'Helicopters', 'helicopter_heavy'),
  ('Sikorsky', 'S-76', 'Helicopters', 'helicopter_medium'),
  ('Sikorsky', 'S-92', 'Helicopters', 'helicopter_heavy'),
  ('MD Helicopters', 'MD 500', 'Helicopters', 'helicopter_light'),
  ('MD Helicopters', 'MD 520N', 'Helicopters', 'helicopter_light'),
  ('MD Helicopters', 'MD 530F', 'Helicopters', 'helicopter_light'),
  ('MD Helicopters', 'MD 600N', 'Helicopters', 'helicopter_light'),
  ('Enstrom', 'F-28', 'Helicopters', 'helicopter_light'),
  ('Enstrom', '480B', 'Helicopters', 'helicopter_light'),
  ('Schweizer', '300C', 'Helicopters', 'helicopter_light'),
  ('Schweizer', '300CBi', 'Helicopters', 'helicopter_light'),
  ('Airbus Corporate Jets', 'ACJ TwoTwenty', 'VIP Airliners', 'vip_large'),
  ('Airbus Corporate Jets', 'ACJ319neo', 'VIP Airliners', 'vip_large'),
  ('Airbus Corporate Jets', 'ACJ320neo', 'VIP Airliners', 'vip_large'),
  ('Airbus Corporate Jets', 'ACJ330neo', 'VIP Airliners', 'vip_large'),
  ('Airbus Corporate Jets', 'ACJ350', 'VIP Airliners', 'vip_large'),
  ('Boeing Business Jets', 'BBJ', 'VIP Airliners', 'vip_large'),
  ('Boeing Business Jets', 'BBJ 737', 'VIP Airliners', 'vip_large'),
  ('Boeing Business Jets', 'BBJ 787', 'VIP Airliners', 'vip_large'),
  ('Boeing Business Jets', 'BBJ 777', 'VIP Airliners', 'vip_large'),
  ('Airbus', 'A220', 'VIP Airliners', 'vip_large'),
  ('Airbus', 'A320', 'VIP Airliners', 'vip_large'),
  ('Airbus', 'A330', 'VIP Airliners', 'vip_large'),
  ('Airbus', 'A350', 'VIP Airliners', 'vip_large'),
  ('Boeing', '737', 'VIP Airliners', 'vip_large'),
  ('Boeing', '757', 'VIP Airliners', 'vip_large'),
  ('Boeing', '767', 'VIP Airliners', 'vip_large'),
  ('Boeing', '777', 'VIP Airliners', 'vip_large'),
  ('Boeing', '787', 'VIP Airliners', 'vip_large'),
  ('ATR', '42', 'VIP Airliners', 'turboprop'),
  ('ATR', '72', 'VIP Airliners', 'turboprop'),
  ('Embraer', 'E-Jets', 'VIP Airliners', 'heavy_jet')
) AS v(manufacturer, model, category, size_class)
ON CONFLICT (manufacturer, model) DO NOTHING;
