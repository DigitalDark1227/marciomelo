/*
# Create complete schema for Márcio Melo Aero & Marine Detailer website

1. New Tables
- `site_content` — editable page content (homepage, about, aero, marine, privacy, cookies) with PT/EN values and draft/published workflow
- `services` — service catalog (Aero/Marine categories) with bilingual titles, descriptions, benefits, images, active flag, display order
- `portfolio_items` — portfolio projects with bilingual content, multiple images, category, publish flag, display order
- `quote_requests` — quote form submissions with customer info, service details, status tracking, internal notes
- `site_settings` — global settings as key/value JSON pairs (brand, contact, appearance, SEO, form config)

2. Security
- RLS enabled on ALL tables
- Public (anon) can: read published content, read active services, read published portfolio, read site settings, submit quote requests
- Authenticated (admin) can: full CRUD on all tables
- quote_requests: anon can INSERT only (cannot read other people's submissions)
- All write operations for admin content require authentication

3. Important Notes
- Admin user is created via edge function `init-admin` using service role key
- Default admin email: admin@marciomelo.pt, password set by edge function
- Content uses draft/published workflow with is_published flag
- Bilingual content stored in _pt and _en suffix columns
*/

-- ============================================
-- site_content: editable page content
-- ============================================
CREATE TABLE IF NOT EXISTS site_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  section text NOT NULL,
  key text NOT NULL,
  value_pt jsonb DEFAULT '{}',
  value_en jsonb DEFAULT '{}',
  is_published boolean DEFAULT true,
  is_visible boolean DEFAULT true,
  display_order int DEFAULT 0,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(section, key)
);

ALTER TABLE site_content ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON site_content TO authenticated;
GRANT SELECT ON site_content TO anon;

DROP POLICY IF EXISTS "public_read_published_content" ON site_content;
CREATE POLICY "public_read_published_content"
ON site_content FOR SELECT
TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "admin_insert_content" ON site_content;
CREATE POLICY "admin_insert_content"
ON site_content FOR INSERT
TO authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_content" ON site_content;
CREATE POLICY "admin_update_content"
ON site_content FOR UPDATE
TO authenticated
USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_content" ON site_content;
CREATE POLICY "admin_delete_content"
ON site_content FOR DELETE
TO authenticated
USING (true);

-- ============================================
-- services: service catalog
-- ============================================
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL DEFAULT 'aero',
  title_pt text NOT NULL DEFAULT '',
  title_en text NOT NULL DEFAULT '',
  description_pt text DEFAULT '',
  description_en text DEFAULT '',
  benefits_pt jsonb DEFAULT '[]',
  benefits_en jsonb DEFAULT '[]',
  image_url text DEFAULT '',
  is_active boolean DEFAULT true,
  display_order int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE services ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON services TO authenticated;
GRANT SELECT ON services TO anon;

DROP POLICY IF EXISTS "public_read_services" ON services;
CREATE POLICY "public_read_services"
ON services FOR SELECT
TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "admin_insert_service" ON services;
CREATE POLICY "admin_insert_service"
ON services FOR INSERT
TO authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_service" ON services;
CREATE POLICY "admin_update_service"
ON services FOR UPDATE
TO authenticated
USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_service" ON services;
CREATE POLICY "admin_delete_service"
ON services FOR DELETE
TO authenticated
USING (true);

-- ============================================
-- portfolio_items: portfolio gallery
-- ============================================
CREATE TABLE IF NOT EXISTS portfolio_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title_pt text NOT NULL DEFAULT '',
  title_en text NOT NULL DEFAULT '',
  description_pt text DEFAULT '',
  description_en text DEFAULT '',
  category text DEFAULT 'aero',
  images jsonb DEFAULT '[]',
  is_published boolean DEFAULT true,
  display_order int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE portfolio_items ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON portfolio_items TO authenticated;
GRANT SELECT ON portfolio_items TO anon;

DROP POLICY IF EXISTS "public_read_portfolio" ON portfolio_items;
CREATE POLICY "public_read_portfolio"
ON portfolio_items FOR SELECT
TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "admin_insert_portfolio" ON portfolio_items;
CREATE POLICY "admin_insert_portfolio"
ON portfolio_items FOR INSERT
TO authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_portfolio" ON portfolio_items;
CREATE POLICY "admin_update_portfolio"
ON portfolio_items FOR UPDATE
TO authenticated
USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_portfolio" ON portfolio_items;
CREATE POLICY "admin_delete_portfolio"
ON portfolio_items FOR DELETE
TO authenticated
USING (true);

-- ============================================
-- quote_requests: quote form submissions
-- ============================================
CREATE TABLE IF NOT EXISTS quote_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT '',
  company text DEFAULT '',
  email text NOT NULL DEFAULT '',
  phone text DEFAULT '',
  service_type text DEFAULT '',
  equipment_type text DEFAULT '',
  location text DEFAULT '',
  description text DEFAULT '',
  language text DEFAULT 'pt',
  status text DEFAULT 'novo',
  attachments jsonb DEFAULT '[]',
  internal_notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE quote_requests ENABLE ROW LEVEL SECURITY;

GRANT INSERT ON quote_requests TO anon, authenticated;
GRANT SELECT, UPDATE, DELETE ON quote_requests TO authenticated;

DROP POLICY IF EXISTS "public_submit_quote" ON quote_requests;
CREATE POLICY "public_submit_quote"
ON quote_requests FOR INSERT
TO anon, authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "admin_read_quotes" ON quote_requests;
CREATE POLICY "admin_read_quotes"
ON quote_requests FOR SELECT
TO authenticated
USING (true);

DROP POLICY IF EXISTS "admin_update_quote" ON quote_requests;
CREATE POLICY "admin_update_quote"
ON quote_requests FOR UPDATE
TO authenticated
USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_quote" ON quote_requests;
CREATE POLICY "admin_delete_quote"
ON quote_requests FOR DELETE
TO authenticated
USING (true);

-- ============================================
-- site_settings: global key/value settings
-- ============================================
CREATE TABLE IF NOT EXISTS site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL DEFAULT '{}',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON site_settings TO authenticated;
GRANT SELECT ON site_settings TO anon;

DROP POLICY IF EXISTS "public_read_settings" ON site_settings;
CREATE POLICY "public_read_settings"
ON site_settings FOR SELECT
TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "admin_insert_settings" ON site_settings;
CREATE POLICY "admin_insert_settings"
ON site_settings FOR INSERT
TO authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_settings" ON site_settings;
CREATE POLICY "admin_update_settings"
ON site_settings FOR UPDATE
TO authenticated
USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_settings" ON site_settings;
CREATE POLICY "admin_delete_settings"
ON site_settings FOR DELETE
TO authenticated
USING (true);

-- ============================================
-- Indexes
-- ============================================
CREATE INDEX IF NOT EXISTS idx_site_content_section ON site_content(section);
CREATE INDEX IF NOT EXISTS idx_services_category ON services(category);
CREATE INDEX IF NOT EXISTS idx_services_order ON services(display_order);
CREATE INDEX IF NOT EXISTS idx_portfolio_category ON portfolio_items(category);
CREATE INDEX IF NOT EXISTS idx_portfolio_published ON portfolio_items(is_published);
CREATE INDEX IF NOT EXISTS idx_quotes_status ON quote_requests(status);
CREATE INDEX IF NOT EXISTS idx_quotes_created ON quote_requests(created_at DESC);

-- ============================================
-- Seed: site_settings
-- ============================================
INSERT INTO site_settings (key, value) VALUES
('brand', '{"name":"Márcio Melo","tagline_pt":"Aero & Marine Detailer","tagline_en":"Aero & Marine Detailer","description_pt":"Especialistas em detailing de alta precisão para aeronaves e embarcações. Cuidamos de cada detalhe com produtos premium e técnicas avançadas.","description_en":"High-precision detailing specialists for aircraft and vessels. We care for every detail with premium products and advanced techniques.","logo_url":"","favicon_url":""}'),
('contact', '{"whatsapp":"+351912345678","email":"geral@marciomelo.pt","phone":"+351912345678","location_pt":"Cascais, Portugal","location_en":"Cascais, Portugal","area_pt":"Lisboa, Cascais, Sintra e Algarve","area_en":"Lisbon, Cascais, Sintra and Algarve","hours_pt":"Seg–Sáb: 09h–19h","hours_en":"Mon–Sat: 9am–7pm","instagram":"https://instagram.com/marciomelo","facebook":"","linkedin":"","whatsapp_msg_pt":"Olá! Gostaria de solicitar um orçamento para detailing.","whatsapp_msg_en":"Hello! I would like to request a quote for detailing."}'),
('appearance', '{"primary_color":"#0a1929","accent_color":"#c9a227","bg_color":"#0f1f35","text_color":"#e8eef5","card_style":"rounded","button_style":"solid","card_radius":12}'),
('seo', '{"home_pt":{"title":"Márcio Melo — Aero & Marine Detailer | Detailing de Aeronaves e Embarcações","description":"Detailing profissional para aeronaves e embarcações em Portugal. Polimento, proteção e cuidados premium.","og_image":""},"home_en":{"title":"Márcio Melo — Aero & Marine Detailer | Aircraft & Vessel Detailing","description":"Professional detailing for aircraft and vessels in Portugal. Polishing, protection and premium care.","og_image":""},"services_pt":{"title":"Serviços | Márcio Melo Aero & Marine Detailer","description":"Serviços de detailing para aeronaves e embarcações.","og_image":""},"services_en":{"title":"Services | Márcio Melo Aero & Marine Detailer","description":"Detailing services for aircraft and vessels.","og_image":""}}'),
('form_config', '{"required_fields":["name","email","service_type"],"categories_pt":["Aero Detailing","Marine Detailing","Consultoria"],"categories_en":["Aero Detailing","Marine Detailing","Consulting"],"success_msg_pt":"Pedido enviado com sucesso! Entraremos em contacto em breve.","success_msg_en":"Request sent successfully! We will contact you soon.","error_msg_pt":"Ocorreu um erro. Tente novamente ou contacte-nos diretamente.","error_msg_en":"An error occurred. Please try again or contact us directly.","allow_attachments":true,"notification_email":"geral@marciomelo.pt"}')
ON CONFLICT (key) DO NOTHING;

-- ============================================
-- Seed: site_content
-- ============================================
INSERT INTO site_content (section, key, value_pt, value_en, is_published, is_visible, display_order) VALUES
('homepage', 'hero', '{"title":"Márcio Melo","subtitle":"Aero & Marine Detailer","description":"Detailing de alta precisão para aeronaves e embarcações. Elevamos o cuidado ao nível da perfeição.","primary_btn":"Solicitar orçamento","secondary_btn":"Ver serviços","image_url":"https://images.pexels.com/photos/20425755/pexels-photo-20425755.jpeg?auto=compress&cs=tinysrgb&w=1920"}', '{"title":"Márcio Melo","subtitle":"Aero & Marine Detailer","description":"High-precision detailing for aircraft and vessels. We elevate care to the level of perfection.","primary_btn":"Request a quote","secondary_btn":"View services","image_url":"https://images.pexels.com/photos/20425755/pexels-photo-20425755.jpeg?auto=compress&cs=tinysrgb&w=1920"}', true, true, 1),
('homepage', 'aero_card', '{"title":"Aero Detailing","description":"Detailing profissional para aeronaves — polimento, proteção e cuidados de interior.","image_url":"https://images.pexels.com/photos/2245276/pexels-photo-2245276.jpeg?auto=compress&cs=tinysrgb&w=800"}', '{"title":"Aero Detailing","description":"Professional detailing for aircraft — polishing, protection and interior care.","image_url":"https://images.pexels.com/photos/2245276/pexels-photo-2245276.jpeg?auto=compress&cs=tinysrgb&w=800"}', true, true, 2),
('homepage', 'marine_card', '{"title":"Marine Detailing","description":"Detailing profissional para embarcações — polimento de casco, proteção e restauração.","image_url":"https://images.pexels.com/photos/38495693/pexels-photo-38495693.jpeg?auto=compress&cs=tinysrgb&w=800"}', '{"title":"Marine Detailing","description":"Professional detailing for vessels — hull polishing, protection and restoration.","image_url":"https://images.pexels.com/photos/38495693/pexels-photo-38495693.jpeg?auto=compress&cs=tinysrgb&w=800"}', true, true, 3),
('homepage', 'differentials', '{"title":"Porquê escolher-nos","items":[{"icon":"shield","title_pt":"Produtos Premium","title_en":"Premium Products","desc_pt":"Utilizamos apenas produtos de alta qualidade, testados e aprovados para superfícies aeronáuticas e marítimas.","desc_en":"We use only high-quality products, tested and approved for aviation and marine surfaces."},{"icon":"sparkles","title_pt":"Técnicas Avançadas","title_en":"Advanced Techniques","desc_pt":"Técnicas de polimento e proteção desenvolvidas para garantir resultados duradouros.","desc_en":"Polishing and protection techniques developed to ensure long-lasting results."},{"icon":"award","title_pt":"Experiência","title_en":"Experience","desc_pt":"Anos de experiência no detailing de aeronaves e embarcações de luxo.","desc_en":"Years of experience detailing luxury aircraft and vessels."},{"icon":"clock","title_pt":"Pontualidade","title_en":"Punctuality","desc_pt":"Respeitamos prazos e agendas. O seu tempo é valioso.","desc_en":"We respect deadlines and schedules. Your time is valuable."}]}', '{"title":"Why choose us","items":[{"icon":"shield","title_pt":"Produtos Premium","title_en":"Premium Products","desc_pt":"Utilizamos apenas produtos de alta qualidade, testados e aprovados para superfícies aeronáuticas e marítimas.","desc_en":"We use only high-quality products, tested and approved for aviation and marine surfaces."},{"icon":"sparkles","title_pt":"Técnicas Avançadas","title_en":"Advanced Techniques","desc_pt":"Técnicas de polimento e proteção desenvolvidas para garantir resultados duradouros.","desc_en":"Polishing and protection techniques developed to ensure long-lasting results."},{"icon":"award","title_pt":"Experiência","title_en":"Experience","desc_pt":"Anos de experiência no detailing de aeronaves e embarcações de luxo.","desc_en":"Years of experience detailing luxury aircraft and vessels."},{"icon":"clock","title_pt":"Pontualidade","title_en":"Punctuality","desc_pt":"Respeitamos prazos e agendas. O seu tempo é valioso.","desc_en":"We respect deadlines and schedules. Your time is valuable."}]}', true, true, 4),
('homepage', 'portfolio_preview', '{"title":"Trabalhos em destaque","subtitle":"Alguns dos nossos projetos recentes","btn_label":"Ver portfólio completo"}', '{"title":"Featured work","subtitle":"Some of our recent projects","btn_label":"View full portfolio"}', true, true, 5),
('homepage', 'cta', '{"title":"Pronto para elevar o seu património?","description":"Solicite um orçamento personalizado e descubra como podemos cuidar da sua aeronave ou embarcação.","btn_label":"Solicitar orçamento"}', '{"title":"Ready to elevate your assets?","description":"Request a personalized quote and discover how we can care for your aircraft or vessel.","btn_label":"Request a quote"}', true, true, 6),
('homepage', 'about_summary', '{"title":"Sobre a empresa","description":"A Márcio Melo Aero & Marine Detailer nasceu da paixão pelo detalhe. Especializados no cuidado de aeronaves e embarcações, combinamos técnicas tradicionais com produtos de última geração para entregar resultados que falam por si.","btn_label":"Saber mais"}', '{"title":"About the company","description":"Márcio Melo Aero & Marine Detailer was born from a passion for detail. Specializing in aircraft and vessel care, we combine traditional techniques with cutting-edge products to deliver results that speak for themselves.","btn_label":"Learn more"}', true, true, 7),
('about', 'main', '{"title":"Sobre a Márcio Melo","subtitle":"Aero & Marine Detailer","content":"A Márcio Melo Aero & Marine Detailer é uma empresa portuguesa dedicada ao detailing de alta precisão para aeronaves e embarcações. Com anos de experiência no setor, desenvolvemos métodos próprios que garantem resultados excecionais em cada intervenção.\n\nA nossa filosofia é simples: cada detalhe importa. Desde a preparação inicial até ao toque final, utilizamos produtos premium e técnicas avançadas para proteger e realçar a beleza natural da sua aeronave ou embarcação.\n\nTrabalhamos com proprietários privados, empresas de aviação, marinários e estaleiros em todo o país, oferecendo um serviço personalizado e discreto.","content_en":"Márcio Melo Aero & Marine Detailer is a Portuguese company dedicated to high-precision detailing for aircraft and vessels. With years of experience in the sector, we have developed our own methods that guarantee exceptional results in every intervention.\n\nOur philosophy is simple: every detail matters. From initial preparation to the final touch, we use premium products and advanced techniques to protect and enhance the natural beauty of your aircraft or vessel.\n\nWe work with private owners, aviation companies, marinas and shipyards across the country, offering a personalized and discreet service."}', '{"title":"About Márcio Melo","subtitle":"Aero & Marine Detailer","content":"Márcio Melo Aero & Marine Detailer is a Portuguese company dedicated to high-precision detailing for aircraft and vessels. With years of experience in the sector, we have developed our own methods that guarantee exceptional results in every intervention.\n\nOur philosophy is simple: every detail matters. From initial preparation to the final touch, we use premium products and advanced techniques to protect and enhance the natural beauty of your aircraft or vessel.\n\nWe work with private owners, aviation companies, marinas and shipyards across the country, offering a personalized and discreet service.","content_en":"Márcio Melo Aero & Marine Detailer is a Portuguese company dedicated to high-precision detailing for aircraft and vessels. With years of experience in the sector, we have developed our own methods that guarantee exceptional results in every intervention.\n\nOur philosophy is simple: every detail matters. From initial preparation to the final touch, we use premium products and advanced techniques to protect and enhance the natural beauty of your aircraft or vessel.\n\nWe work with private owners, aviation companies, marinas and shipyards across the country, offering a personalized and discreet service."}', true, true, 1),
('aero', 'main', '{"title":"Aero Detailing","subtitle":"Detailing profissional para aeronaves","content":"O nosso serviço de Aero Detailing foi desenvolvido especificamente para aeronaves, tendo em conta as exigências únicas das superfícies aeronáuticas. Desde o polimento da fuselagem à proteção de transparências, cada intervenção é executada com precisão e cuidado.","content_en":"Our Aero Detailing service was developed specifically for aircraft, taking into account the unique demands of aviation surfaces. From fuselage polishing to transparency protection, every intervention is executed with precision and care."}', '{"title":"Aero Detailing","subtitle":"Professional detailing for aircraft","content":"Our Aero Detailing service was developed specifically for aircraft, taking into account the unique demands of aviation surfaces. From fuselage polishing to transparency protection, every intervention is executed with precision and care.","content_en":"Our Aero Detailing service was developed specifically for aircraft, taking into account the unique demands of aviation surfaces. From fuselage polishing to transparency protection, every intervention is executed with precision and care."}', true, true, 1),
('marine', 'main', '{"title":"Marine Detailing","subtitle":"Detailing profissional para embarcações","content":"O nosso serviço de Marine Detailing é especializado no cuidado de embarcações, desde velas de luxo a iates motorizados. Polimento de casco, proteção de gelcoat, restauração de isótopos e cuidados de interior — tudo com produtos premium adaptados ao ambiente marítimo.","content_en":"Our Marine Detailing service is specialized in vessel care, from luxury sailboats to motor yachts. Hull polishing, gelcoat protection, isinglass restoration and interior care — all with premium products adapted to the marine environment."}', '{"title":"Marine Detailing","subtitle":"Professional detailing for vessels","content":"Our Marine Detailing service is specialized in vessel care, from luxury sailboats to motor yachts. Hull polishing, gelcoat protection, isinglass restoration and interior care — all with premium products adapted to the marine environment.","content_en":"Our Marine Detailing service is specialized in vessel care, from luxury sailboats to motor yachts. Hull polishing, gelcoat protection, isinglass restoration and interior care — all with premium products adapted to the marine environment."}', true, true, 1),
('privacy', 'main', '{"title":"Política de Privacidade","content":"A Márcio Melo Aero & Marine Detailer respeita a privacidade dos seus visitantes e clientes. Esta política descreve como recolhemos, utilizamos e protegemos os seus dados pessoais.\n\n1. Dados recolhidos: Nome, e-mail, telefone e informações fornecidas no formulário de orçamento.\n\n2. Utilização dos dados: Os dados são utilizados exclusivamente para responder aos pedidos de orçamento e prestar os serviços solicitados.\n\n3. Partilha de dados: Não partilhamos os seus dados com terceiros sem o seu consentimento.\n\n4. Armazenamento: Os dados são armazenados de forma segura e mantidos apenas pelo tempo necessário.\n\n5. Direitos: Pode solicitar acesso, retificação ou eliminação dos seus dados a qualquer momento através do e-mail geral@marciomelo.pt."}', '{"title":"Privacy Policy","content":"Márcio Melo Aero & Marine Detailer respects the privacy of its visitors and customers. This policy describes how we collect, use and protect your personal data.\n\n1. Data collected: Name, email, phone and information provided in the quote form.\n\n2. Data usage: Data is used exclusively to respond to quote requests and provide the requested services.\n\n3. Data sharing: We do not share your data with third parties without your consent.\n\n4. Storage: Data is stored securely and kept only for as long as necessary.\n\n5. Rights: You may request access, rectification or deletion of your data at any time via email at geral@marciomelo.pt."}', true, true, 1),
('cookies', 'main', '{"title":"Política de Cookies","content":"Este website utiliza cookies para melhorar a sua experiência de navegação.\n\n1. Cookies essenciais: Necessários para o funcionamento básico do site.\n\n2. Cookies analíticos: Ajuda-nos a compreender como os visitantes utilizam o site.\n\n3. Gestão: Pode gerir ou desativar os cookies através das definições do seu navegador."}', '{"title":"Cookies Policy","content":"This website uses cookies to improve your browsing experience.\n\n1. Essential cookies: Necessary for the basic functioning of the site.\n\n2. Analytical cookies: Helps us understand how visitors use the site.\n\n3. Management: You can manage or disable cookies through your browser settings."}', true, true, 1)
ON CONFLICT (section, key) DO NOTHING;

-- ============================================
-- Seed: services
-- ============================================
INSERT INTO services (category, title_pt, title_en, description_pt, description_en, benefits_pt, benefits_en, image_url, is_active, display_order) VALUES
('aero', 'Polimento de Fuselagem', 'Fuselage Polishing', 'Polimento profissional da fuselagem para restaurar o brilho e proteger a superfície.', 'Professional fuselage polishing to restore shine and protect the surface.',
'["Restaura o brilho original","Remove oxidação e marcas leves","Proteção duradoura","Produtos aprovados para aviação"]',
'["Restores original shine","Removes oxidation and light marks","Long-lasting protection","Aviation-approved products"]',
'https://images.pexels.com/photos/20425755/pexels-photo-20425755.jpeg?auto=compress&cs=tinysrgb&w=800', true, 1),
('aero', 'Proteção de Transparências', 'Transparency Protection', 'Tratamento e proteção das transparências da cabine para clareza e durabilidade.', 'Treatment and protection of cabin transparencies for clarity and durability.',
'["Melhora a visibilidade","Reduz riscos microscópicos","Proteção contra UV","Aplicação de selantes especializados"]',
'["Improves visibility","Reduces microscopic scratches","UV protection","Application of specialized sealants"]',
'https://images.pexels.com/photos/20562278/pexels-photo-20562278.jpeg?auto=compress&cs=tinysrgb&w=800', true, 2),
('aero', 'Detailing de Interior', 'Interior Detailing', 'Limpeza e cuidado completo do interior da aeronave — couro, tecidos e superfícies.', 'Complete interior cleaning and care for the aircraft — leather, fabrics and surfaces.',
'["Limpeza profunda de couro","Higienização de superfícies","Cuidado de tapizados","Produto neutralizador de odores"]',
'["Deep leather cleaning","Surface sanitization","Upholstery care","Odor neutralizer treatment"]',
'https://images.pexels.com/photos/20562279/pexels-photo-20562279.jpeg?auto=compress&cs=tinysrgb&w=800', true, 3),
('marine', 'Polimento de Casco', 'Hull Polishing', 'Polimento e restauração do casco para remover oxidação e devolver o brilho.', 'Polishing and restoration of the hull to remove oxidation and restore shine.',
'["Remove oxidação do gelcoat","Restaura o brilho profundo","Proteção contra água salgada","Acabamento espelho"]',
'["Removes gelcoat oxidation","Restores deep shine","Salt water protection","Mirror finish"]',
'https://images.pexels.com/photos/38495693/pexels-photo-38495693.jpeg?auto=compress&cs=tinysrgb&w=800', true, 1),
('marine', 'Proteção e Selagem', 'Protection and Sealing', 'Aplicação de selantes cerâmicos para proteção de longa duração da embarcação.', 'Application of ceramic sealants for long-lasting vessel protection.',
'["Proteção cerâmica premium","Resistência a sal e UV","Facilita a limpeza","Durabilidade até 24 meses"]',
'["Premium ceramic protection","Salt and UV resistance","Easier cleaning","Durability up to 24 months"]',
'https://images.pexels.com/photos/42091/pexels-photo-42091.jpeg?auto=compress&cs=tinysrgb&w=800', true, 2),
('marine', 'Restauração de Isótopos', 'Isinglass Restoration', 'Restauração e polimento de isótopos e transparentes da embarcação.', 'Restoration and polishing of vessel isinglass and transparent panels.',
'["Remove amarelecimento","Restaura a transparência","Proteção contra riscos","Prolonga a vida útil"]',
'["Removes yellowing","Restores transparency","Scratch protection","Extends lifespan"]',
'https://images.pexels.com/photos/997615/pexels-photo-997615.jpeg?auto=compress&cs=tinysrgb&w=800', true, 3)
ON CONFLICT DO NOTHING;

-- ============================================
-- Seed: portfolio_items
-- ============================================
INSERT INTO portfolio_items (title_pt, title_en, description_pt, description_en, category, images, is_published, display_order) VALUES
('Polimento de jato privado', 'Private jet polishing', 'Polimento completo da fuselagem de um jato privado', 'Complete fuselage polishing of a private jet',
'aero',
'[{"url":"https://images.pexels.com/photos/20425755/pexels-photo-20425755.jpeg?auto=compress&cs=tinysrgb&w=1200","alt_pt":"Jato privado após polimento","alt_en":"Private jet after polishing"},{"url":"https://images.pexels.com/photos/2245276/pexels-photo-2245276.jpeg?auto=compress&cs=tinysrgb&w=1200","alt_pt":"Jatos privados no hangar","alt_en":"Private jets in hangar"}]',
true, 1),
('Restauração de iate', 'Yacht restoration', 'Polimento de casco e proteção cerâmica de um iate de luxo', 'Hull polishing and ceramic protection of a luxury yacht',
'marine',
'[{"url":"https://images.pexels.com/photos/38495693/pexels-photo-38495693.jpeg?auto=compress&cs=tinysrgb&w=1200","alt_pt":"Iate de luxo após detailing","alt_en":"Luxury yacht after detailing"},{"url":"https://images.pexels.com/photos/42091/pexels-photo-42091.jpeg?auto=compress&cs=tinysrgb&w=1200","alt_pt":"Iates na marina","alt_en":"Yachts at marina"}]',
true, 2),
('Detailing de interior aeronáutico', 'Aircraft interior detailing', 'Renovação completa do interior de uma aeronave executiva', 'Complete interior renovation of an executive aircraft',
'aero',
'[{"url":"https://images.pexels.com/photos/20562278/pexels-photo-20562278.jpeg?auto=compress&cs=tinysrgb&w=1200","alt_pt":"Interior de jato privado","alt_en":"Private jet interior"},{"url":"https://images.pexels.com/photos/20562279/pexels-photo-20562279.jpeg?auto=compress&cs=tinysrgb&w=1200","alt_pt":"Detalhe do interior de aeronave","alt_en":"Aircraft interior detail"}]',
true, 3),
('Polimento de velheiro', 'Sailboat polishing', 'Polimento e proteção de um velheiro de luxo', 'Polishing and protection of a luxury sailboat',
'marine',
'[{"url":"https://images.pexels.com/photos/997615/pexels-photo-997615.jpeg?auto=compress&cs=tinysrgb&w=1200","alt_pt":"Convés de velheiro","alt_en":"Sailboat deck"},{"url":"https://images.pexels.com/photos/565501/pexels-photo-565501.jpeg?auto=compress&cs=tinysrgb&w=1200","alt_pt":"Proa de velheiro no mar","alt_en":"Sailboat bow at sea"}]',
true, 4)
ON CONFLICT DO NOTHING;