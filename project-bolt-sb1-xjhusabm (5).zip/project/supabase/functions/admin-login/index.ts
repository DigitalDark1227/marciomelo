import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const ADMIN_PASSWORD = "M1234";
const ADMIN_EMAIL = "contato@marciomelo.com";
const WRONG_PASSWORD_DELAY_MS = 1500;

function json(body: unknown, status: number) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body = await req.json().catch(() => null);
    const password = body?.password;
    if (typeof password !== "string") {
      return json({ error: "Senha obrigatória." }, 400);
    }

    if (password !== ADMIN_PASSWORD) {
      await new Promise((resolve) => setTimeout(resolve, WRONG_PASSWORD_DELAY_MS));
      return json({ error: "Senha incorreta." }, 401);
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const sessionPassword = `${crypto.randomUUID()}${crypto.randomUUID()}`;

    const { data: list, error: listError } = await admin.auth.admin.listUsers();
    if (listError) throw listError;

    const existing = list.users.find((u) => u.email === ADMIN_EMAIL);
    if (existing) {
      const { error } = await admin.auth.admin.updateUserById(existing.id, {
        password: sessionPassword,
      });
      if (error) throw error;
    } else {
      const { error } = await admin.auth.admin.createUser({
        email: ADMIN_EMAIL,
        password: sessionPassword,
        email_confirm: true,
        user_metadata: { role: "admin", name: "Administrador" },
      });
      if (error) throw error;
    }

    const anon = createClient(supabaseUrl, anonKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
    const { data: signed, error: signInError } = await anon.auth.signInWithPassword({
      email: ADMIN_EMAIL,
      password: sessionPassword,
    });
    if (signInError || !signed.session) {
      throw signInError ?? new Error("Sessão não criada");
    }

    return json(
      {
        access_token: signed.session.access_token,
        refresh_token: signed.session.refresh_token,
      },
      200,
    );
  } catch (err) {
    console.error("admin-login failed:", err);
    return json({ error: "Não foi possível entrar. Tente novamente." }, 500);
  }
});
